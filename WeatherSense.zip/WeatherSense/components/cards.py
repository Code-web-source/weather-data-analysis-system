"""KPI Metric and Summary Cards UI Components."""
import streamlit as st
from typing import Dict, Any, Optional

def render_kpi_card(title: str, value: str, subtitle: Optional[str] = None, icon: str = "🌡️"):
    """Renders a modern dark aesthetic KPI Metric Card."""
    st.markdown(
        f"""
        <div class="kpi-card">
            <div class="kpi-title">{icon} {title}</div>
            <div class="kpi-value">{value}</div>
            {f'<div class="kpi-subtitle">{subtitle}</div>' if subtitle else ''}
        </div>
        """,
        unsafe_allow_html=True
    )

def render_hero_weather_card(city: str, country: str, current: Dict[str, Any]):
    """Renders primary weather showcase hero card."""
    temp = current.get("temperature", "N/A")
    feels_like = current.get("feels_like", "N/A")
    desc = current.get("weather_desc", "Clear")
    icon = current.get("weather_icon", "☀️")

    st.markdown(
        f"""
        <div class="hero-card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span style="color: #94A3B8; font-size: 0.9rem; text-transform: uppercase; font-weight: 600;">Current Weather</span>
                    <h2 style="margin: 0; color: #FFFFFF; font-size: 1.8rem; font-weight: 700;">{city}, {country}</h2>
                </div>
                <span style="font-size: 3.5rem;">{icon}</span>
            </div>
            <div style="display: flex; align-items: baseline; gap: 15px; margin-top: 15px;">
                <div class="hero-temp">{temp}°C</div>
                <div>
                    <div class="hero-condition">{desc}</div>
                    <div style="color: #94A3B8; font-size: 0.85rem;">Feels like {feels_like}°C</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

def render_intelligence_cards(comfort: Dict[str, Any], risk: Dict[str, Any], rec: Dict[str, Any]):
    """Renders 3 side-by-side weather intelligence summary cards."""
    col1, col2, col3 = st.columns(3)

    with col1:
        score = comfort.get("score", 0)
        cat = comfort.get("category", "N/A")
        st.markdown(
            f"""
            <div class="weather-card">
                <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-weight: 700;">🎯 Weather Comfort Score</div>
                <div style="font-size: 2.2rem; font-weight: 800; color: #38BDF8; margin: 5px 0;">{score}<span style="font-size: 1rem; color:#94A3B8;">/100</span></div>
                <div class="badge badge-success">{cat}</div>
                <p style="font-size: 0.7rem; color: #64748B; margin-top: 10px;">{comfort.get('disclaimer', '')}</p>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col2:
        level = risk.get("level", "LOW")
        color = risk.get("color", "#22C55E")
        reasons = risk.get("reasons", ["No environmental hazards"])
        st.markdown(
            f"""
            <div class="weather-card">
                <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-weight: 700;">⚠️ Weather Risk Indicator</div>
                <div style="font-size: 1.8rem; font-weight: 800; color: {color}; margin: 5px 0;">{level}</div>
                <p style="font-size: 0.8rem; color: #F8FAFC; margin: 0;">{reasons[0]}</p>
                <p style="font-size: 0.7rem; color: #64748B; margin-top: 10px;">{risk.get('disclaimer', '')}</p>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col3:
        verdict = rec.get("verdict", "")
        factors = rec.get("factors", [])
        st.markdown(
            f"""
            <div class="weather-card">
                <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-weight: 700;">🏃 Outdoor Recommendation</div>
                <div style="font-size: 0.95rem; font-weight: 700; color: #22D3EE; margin: 8px 0;">{verdict}</div>
                <p style="font-size: 0.8rem; color: #94A3B8; margin: 0;">• {factors[0] if factors else 'Conditions normal'}</p>
                <p style="font-size: 0.7rem; color: #64748B; margin-top: 10px;">{rec.get('disclaimer', '')}</p>
            </div>
            """,
            unsafe_allow_html=True
        )
