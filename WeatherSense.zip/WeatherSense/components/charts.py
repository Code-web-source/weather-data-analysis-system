"""Interactive Plotly Visualization Builders for WeatherSense."""
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional
from config.config import Config

# Plotly Layout Dark Theme Preset
PLOTLY_DARK_LAYOUT = dict(
    paper_bgcolor="#111827",
    plot_bgcolor="#111827",
    font=dict(color="#F8FAFC", family="Inter, sans-serif"),
    xaxis=dict(
        gridcolor="#1F2937",
        zerolinecolor="#1F2937",
        showline=True,
        linecolor="#374151"
    ),
    yaxis=dict(
        gridcolor="#1F2937",
        zerolinecolor="#1F2937",
        showline=True,
        linecolor="#374151"
    ),
    margin=dict(l=40, r=20, t=40, b=40)
)

def build_hourly_temp_chart(df: pd.DataFrame) -> go.Figure:
    """Build 24-hour temperature forecast line chart."""
    fig = go.Figure()

    if not df.empty and "temperature" in df.columns:
        fig.add_trace(go.Scatter(
            x=df["time"],
            y=df["temperature"],
            mode="lines+markers",
            name="Temperature (°C)",
            line=dict(color="#38BDF8", width=3),
            marker=dict(size=6, color="#22D3EE"),
            hovertemplate="<b>%{x|%I:%M %p}</b><br>Temp: %{y:.1f}°C<extra></extra>"
        ))

        if "feels_like" in df.columns:
            fig.add_trace(go.Scatter(
                x=df["time"],
                y=df["feels_like"],
                mode="lines",
                name="Feels Like (°C)",
                line=dict(color="#94A3B8", width=2, dash="dash"),
                hovertemplate="Feels Like: %{y:.1f}°C<extra></extra>"
            ))

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        title="24-Hour Temperature Forecast Trend",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig

def build_precipitation_prob_chart(df: pd.DataFrame) -> go.Figure:
    """Build 24-hour precipitation probability bar chart."""
    fig = go.Figure()
    if not df.empty and "precipitation_probability" in df.columns:
        fig.add_trace(go.Bar(
            x=df["time"],
            y=df["precipitation_probability"],
            name="Rain Prob (%)",
            marker_color="#2563EB",
            opacity=0.85,
            hovertemplate="Rain Probability: %{y}%<extra></extra>"
        ))

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        title="Precipitation Probability (%) Next 24 Hours"
    )
    fig.update_yaxes(range=[0, 100], gridcolor="#1F2937")
    return fig

def build_daily_min_max_chart(df: pd.DataFrame) -> go.Figure:
    """Build 7-day Min/Max Temperature range chart."""
    fig = go.Figure()
    if not df.empty and "temperature_2m_max" in df.columns:
        dates = pd.to_datetime(df["time"]).dt.strftime("%a, %b %d")

        fig.add_trace(go.Scatter(
            x=dates,
            y=df["temperature_2m_max"],
            mode="lines+markers",
            name="Max Temp (°C)",
            line=dict(color="#EF4444", width=3)
        ))

        fig.add_trace(go.Scatter(
            x=dates,
            y=df["temperature_2m_min"],
            mode="lines+markers",
            name="Min Temp (°C)",
            line=dict(color="#38BDF8", width=3)
        ))

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        title="7-Day Temperature Range (Min / Max)",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig

def build_correlation_heatmap(corr_df: pd.DataFrame) -> go.Figure:
    """Build Plotly correlation heatmap."""
    fig = go.Figure()
    if not corr_df.empty:
        fig.add_trace(go.Heatmap(
            z=corr_df.values,
            x=corr_df.columns,
            y=corr_df.index,
            colorscale="Viridis",
            zmin=-1, zmax=1,
            text=np.round(corr_df.values, 2),
            texttemplate="%{text}",
            textfont={"size": 12, "color": "white"}
        ))

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        title="Weather Variable Pearson Correlation Heatmap"
    )
    return fig

def build_anomaly_chart(df: pd.DataFrame, col: str = "temperature") -> go.Figure:
    """Build line chart displaying statistical anomalies highlighted in red."""
    fig = go.Figure()
    if not df.empty and col in df.columns:
        fig.add_trace(go.Scatter(
            x=df["time"] if "time" in df.columns else df.index,
            y=df[col],
            mode="lines",
            name=col.capitalize(),
            line=dict(color="#38BDF8", width=2)
        ))

        # Highlight anomalies
        anomalies = df[df.get("is_anomaly", False)]
        if not anomalies.empty:
            fig.add_trace(go.Scatter(
                x=anomalies["time"] if "time" in anomalies.columns else anomalies.index,
                y=anomalies[col],
                mode="markers",
                name="Statistical Anomaly",
                marker=dict(color="#EF4444", size=10, symbol="diamond"),
                hovertemplate="Anomaly Detected: %{y:.1f}<extra></extra>"
            ))

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        title=f"Statistical Anomaly Detection ({col.capitalize()})"
    )
    return fig

def build_comfort_gauge(score: int) -> go.Figure:
    """Build Plotly indicator gauge chart for Weather Comfort Score (0-100)."""
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=score,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "Comfort Score", 'font': {'size': 18, 'color': '#F8FAFC'}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#94A3B8"},
            'bar': {'color': "#38BDF8"},
            'bgcolor': "#111827",
            'bordercolor': "#1F2937",
            'steps': [
                {'range': [0, 40], 'color': 'rgba(239, 68, 68, 0.4)'},
                {'range': [40, 70], 'color': 'rgba(245, 158, 11, 0.4)'},
                {'range': [70, 100], 'color': 'rgba(34, 197, 94, 0.4)'}
            ]
        }
    ))
    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        height=240
    )
    return fig

def build_feature_importance_chart(df: pd.DataFrame) -> go.Figure:
    """Build horizontal bar chart for Random Forest feature importance."""
    fig = go.Figure()
    if not df.empty:
        fig.add_trace(go.Bar(
            y=df["Feature"],
            x=df["Importance"],
            orientation="h",
            marker=dict(color="#22D3EE")
        ))
    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        title="ML Random Forest Model Feature Importance"
    )
    fig.update_yaxes(autorange="reversed")
    return fig

def build_actual_vs_predicted_chart(y_true: np.ndarray, y_pred: np.ndarray) -> go.Figure:
    """Build Actual vs Predicted scatter plot comparison."""
    fig = go.Figure()
    if len(y_true) > 0:
        fig.add_trace(go.Scatter(
            x=y_true,
            y=y_pred,
            mode="markers",
            name="Test Observations",
            marker=dict(color="#38BDF8", size=8, opacity=0.8)
        ))

        # Add 1:1 perfect prediction reference line
        min_val = min(min(y_true), min(y_pred))
        max_val = max(max(y_true), max(y_pred))
        fig.add_trace(go.Scatter(
            x=[min_val, max_val],
            y=[min_val, max_val],
            mode="lines",
            name="Ideal Prediction (1:1)",
            line=dict(color="#EF4444", dash="dash")
        ))

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        title="ML Temperature Prediction: Actual vs Predicted",
        xaxis_title="Actual Temperature (°C)",
        yaxis_title="Predicted Temperature (°C)"
    )
    return fig
