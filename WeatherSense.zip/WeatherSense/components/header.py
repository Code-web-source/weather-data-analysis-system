"""Header component with logo, title, and search input box."""
import streamlit as st
from typing import Tuple, Optional
from config.config import Config

def render_header() -> Tuple[str, bool]:
    """
    Renders top application header and location search bar.
    Returns (search_query, is_submitted).
    """
    col1, col2 = st.columns([3, 2])

    with col1:
        st.markdown(
            f"""
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 2.2rem;">🌤️</span>
                <div>
                    <h1 style="margin:0; font-size: 1.8rem; font-weight: 800; color: #F8FAFC;">
                        {Config.APP_NAME}
                    </h1>
                    <p style="margin:0; font-size: 0.85rem; color: #38BDF8; font-weight: 500;">
                        {Config.APP_SUBTITLE}
                    </p>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col2:
        with st.form(key="search_form", clear_on_submit=False):
            search_cols = st.columns([3, 1])
            with search_cols[0]:
                query = st.text_input(
                    "Search Location",
                    value=st.session_state.get("selected_city", "Bangalore"),
                    placeholder="Enter city (e.g., Bangalore, London)",
                    label_visibility="collapsed"
                )
            with search_cols[1]:
                submit = st.form_submit_button("🔍 Search", use_container_width=True)

    return query, submit
