"""Sidebar navigation component for WeatherSense with professional spacing & layout."""
import streamlit as st
from typing import List
from database.database import DatabaseManager

PAGES = [
    "🏠   Dashboard",
    "🌡️   Live Weather",
    "📊   Historical Analysis",
    "📅   Forecast",
    "🆚   City Comparison",
    "🤖   Prediction",
    "🗺️   Weather Map",
    "⚠️   Alerts & Insights",
    "📄   Reports",
    "⭐   Favorites",
    "⚙️   Settings"
]

def render_sidebar(db: DatabaseManager) -> str:
    """
    Renders left sidebar navigation menu with professional framed items, clear gaps, and brand card.
    Returns selected page title.
    """
    with st.sidebar:
        # Brand Card Header
        st.markdown(
            """
            <div style="background: linear-gradient(135deg, rgba(15, 23, 42, 0.9) 0%, rgba(30, 41, 59, 0.7) 100%); padding: 14px 16px; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.08); margin-bottom: 18px; text-align: center; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);">
                <span style="font-size: 2.2rem;">🌤️</span>
                <h2 style="color: #38BDF8; margin: 4px 0 0 0; font-weight: 800; font-size: 1.4rem; letter-spacing: 0.02em;">WeatherSense</h2>
                <p style="color: #94A3B8; font-size: 0.72rem; margin: 2px 0 0 0; text-transform: uppercase; letter-spacing: 0.05em; font-weight: 600;">Weather Intelligence Platform</p>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown("<p style='font-size:0.75rem; font-weight:700; color:#38BDF8; text-transform:uppercase; letter-spacing:0.08em; margin: 0 0 10px 4px;'>NAVIGATION MENU</p>", unsafe_allow_html=True)

        # Radio navigation menu (Circles hidden via CSS, styled into spacious button cards)
        selected_page = st.radio(
            label="NAVIGATION MENU",
            options=PAGES,
            index=0,
            label_visibility="collapsed"
        )

        st.markdown("<hr style='border-color: rgba(255, 255, 255, 0.08); margin: 20px 0 16px 0;'>", unsafe_allow_html=True)

        # Quick Favorites section
        st.markdown("<p style='font-size:0.75rem; font-weight:700; color:#38BDF8; text-transform:uppercase; letter-spacing:0.08em; margin: 0 0 10px 4px;'>⭐ FAVORITE LOCATIONS</p>", unsafe_allow_html=True)
        favs = db.get_favorites()
        if favs:
            for fav in favs[:5]:
                if st.button(f"📍 {fav}", key=f"side_fav_{fav}", use_container_width=True):
                    st.session_state["selected_city"] = fav
                    st.rerun()
        else:
            st.markdown("<p style='font-size:0.75rem; color:#64748B; margin-left: 4px;'>No saved favorites.</p>", unsafe_allow_html=True)

        # Active location indicator at bottom
        st.markdown("<hr style='border-color: rgba(255, 255, 255, 0.08); margin: 20px 0 16px 0;'>", unsafe_allow_html=True)
        current_loc = st.session_state.get("selected_city", "Bangalore")
        st.markdown(
            f"""
            <div style="background: linear-gradient(135deg, rgba(17, 24, 39, 0.9) 0%, rgba(30, 41, 59, 0.8) 100%); padding: 12px; border-radius: 10px; border: 1px solid #38BDF8; text-align: center; box-shadow: 0 4px 12px rgba(56, 189, 248, 0.15);">
                <p style="margin: 0; font-size: 0.68rem; color: #94A3B8; text-transform: uppercase; font-weight: 600;">ACTIVE LOCATION</p>
                <p style="margin: 2px 0 0 0; font-size: 0.95rem; font-weight: 800; color: #38BDF8;">📍 {current_loc}</p>
            </div>
            """,
            unsafe_allow_html=True
        )

    # Normalize returned title string (stripping extra padding spaces for routing)
    clean_title = selected_page.replace("   ", " ")
    return clean_title
