"""Centralized CSS styles module for WeatherSense Streamlit Dashboard."""
import streamlit as st

def apply_custom_styles():
    """Inject custom CSS rules for professional UI and spacious framed sidebar navigation."""
    css = """
    <style>
    /* Dark Theme Core Variables */
    :root {
        --bg-main: #0B1220;
        --bg-card: #111827;
        --bg-card-hover: #1E293B;
        --border-color: #1F2937;
        --accent-primary: #38BDF8;
        --accent-secondary: #2563EB;
        --accent-cyan: #22D3EE;
        --text-main: #F8FAFC;
        --text-muted: #94A3B8;
        --success: #22C55E;
        --warning: #F59E0B;
        --danger: #EF4444;
    }

    /* Main App Background */
    .stApp {
        background-color: var(--bg-main) !important;
        color: var(--text-main) !important;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    /* Sidebar Background */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #09111E 0%, #070D18 100%) !important;
        border-right: 1px solid rgba(255, 255, 255, 0.08) !important;
        padding-top: 15px !important;
    }

    /* Hide standard radio header label */
    div[data-testid="stSidebar"] div[role="radiogroup"] > p {
        display: none !important;
    }

    /* Professional Navigation Radio Container with Generous Gaps */
    div[data-testid="stSidebar"] div[role="radiogroup"] {
        display: flex !important;
        flex-direction: column !important;
        gap: 10px !important;
    }

    /* HIDE ALL RADIO CIRCLES COMPLETELY */
    div[data-testid="stSidebar"] div[role="radiogroup"] label input[type="radio"],
    div[data-testid="stSidebar"] div[role="radiogroup"] label [data-baseweb="radio"],
    div[data-testid="stSidebar"] div[role="radiogroup"] label > div:first-child,
    div[data-testid="stSidebar"] div[role="radiogroup"] label svg {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        opacity: 0 !important;
    }

    /* Professional Framed Navigation Option Cards */
    div[data-testid="stSidebar"] div[role="radiogroup"] label {
        background: linear-gradient(135deg, rgba(17, 24, 39, 0.8) 0%, rgba(30, 41, 59, 0.5) 100%) !important;
        border: 1px solid rgba(255, 255, 255, 0.08) !important;
        border-radius: 10px !important;
        padding: 12px 16px !important;
        margin-bottom: 2px !important;
        cursor: pointer !important;
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
        width: 100% !important;
        display: flex !important;
        align-items: center !important;
        color: #CBD5E1 !important;
        font-size: 0.95rem !important;
        font-weight: 500 !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25) !important;
    }

    div[data-testid="stSidebar"] div[role="radiogroup"] label p,
    div[data-testid="stSidebar"] div[role="radiogroup"] label div[data-testid="stMarkdownContainer"] {
        color: inherit !important;
        font-size: 0.95rem !important;
        font-weight: inherit !important;
        margin: 0 !important;
    }

    /* Smooth Micro-Animation on Hover */
    div[data-testid="stSidebar"] div[role="radiogroup"] label:hover {
        background: linear-gradient(135deg, rgba(37, 99, 235, 0.25) 0%, rgba(56, 189, 248, 0.15) 100%) !important;
        border-color: #38BDF8 !important;
        color: #F8FAFC !important;
        transform: translateX(4px) !important;
        box-shadow: 0 4px 14px rgba(56, 189, 248, 0.25) !important;
    }

    /* Active / Selected Navigation Frame */
    div[data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked),
    div[data-testid="stSidebar"] div[role="radiogroup"] label[aria-checked="true"] {
        background: linear-gradient(135deg, rgba(37, 99, 235, 0.45) 0%, rgba(56, 189, 248, 0.3) 100%) !important;
        border: 1.5px solid #38BDF8 !important;
        color: #FFFFFF !important;
        font-weight: 700 !important;
        transform: translateX(4px) !important;
        box-shadow: 0 0 16px rgba(56, 189, 248, 0.35) !important;
    }

    /* Sidebar Favorite Buttons Styling */
    div[data-testid="stSidebar"] .stButton > button {
        background: linear-gradient(135deg, rgba(17, 24, 39, 0.8) 0%, rgba(30, 41, 59, 0.5) 100%) !important;
        border: 1px solid rgba(255, 255, 255, 0.08) !important;
        border-radius: 8px !important;
        padding: 8px 12px !important;
        color: #94A3B8 !important;
        font-size: 0.85rem !important;
        transition: all 0.2s ease !important;
        margin-bottom: 4px !important;
    }

    div[data-testid="stSidebar"] .stButton > button:hover {
        background: rgba(56, 189, 248, 0.15) !important;
        border-color: #38BDF8 !important;
        color: #38BDF8 !important;
        transform: translateX(2px) !important;
    }

    /* Main App Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%) !important;
        color: #F8FAFC !important;
        border: 1px solid #374151 !important;
        border-radius: 8px !important;
        padding: 8px 16px !important;
        font-weight: 600 !important;
        transition: all 0.25s ease-in-out !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3) !important;
    }

    .stButton > button:hover {
        background: linear-gradient(135deg, #2563EB 0%, #38BDF8 100%) !important;
        color: #FFFFFF !important;
        border-color: #38BDF8 !important;
        transform: translateY(-2px) scale(1.02) !important;
        box-shadow: 0 6px 20px rgba(56, 189, 248, 0.4) !important;
    }

    /* Card Containers */
    .weather-card {
        background-color: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 16px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        transition: transform 0.2s ease, border-color 0.2s ease;
    }

    .weather-card:hover {
        border-color: var(--accent-primary);
    }

    /* KPI Metric Card */
    .kpi-card {
        background: linear-gradient(135deg, rgba(17, 24, 39, 0.9), rgba(30, 41, 59, 0.7));
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 16px;
        text-align: center;
        margin-bottom: 12px;
    }

    .kpi-title {
        font-size: 0.85rem;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
    }

    .kpi-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: var(--accent-primary);
        line-height: 1.2;
    }

    .kpi-subtitle {
        font-size: 0.75rem;
        color: var(--text-muted);
        margin-top: 4px;
    }

    /* Hero Weather Card */
    .hero-card {
        background: linear-gradient(135deg, #1E1B4B 0%, #0F172A 100%);
        border: 1px solid #312E81;
        border-radius: 16px;
        padding: 24px;
        margin-bottom: 20px;
    }

    .hero-temp {
        font-size: 3.5rem;
        font-weight: 800;
        color: #FFFFFF;
    }

    .hero-condition {
        font-size: 1.2rem;
        color: var(--accent-cyan);
        margin-top: -8px;
    }

    /* Badge Tags */
    .badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
    }

    .badge-success { background: rgba(34, 197, 94, 0.15); color: #4ADE80; border: 1px solid #22C55E; }
    .badge-warning { background: rgba(245, 158, 11, 0.15); color: #FBBF24; border: 1px solid #F59E0B; }
    .badge-danger { background: rgba(239, 68, 68, 0.15); color: #FCA5A5; border: 1px solid #EF4444; }

    /* Hide Streamlit Default Elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
