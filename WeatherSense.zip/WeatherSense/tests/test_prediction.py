"""Pytest test cases for ML feature preprocessing, training, and inference."""
import pytest
import pandas as pd
import numpy as np
from ml.preprocessing import MLDataPreprocessor
from ml.train_model import WeatherModelTrainer
from ml.prediction import TemperaturePredictor

def test_feature_preprocessing():
    """Test feature engineering lag generation."""
    dates = pd.date_range(start="2026-01-01", periods=15, freq="D")
    df = pd.DataFrame({
        "time": dates,
        "temperature": np.random.uniform(20, 30, size=15),
        "humidity": np.random.uniform(40, 80, size=15),
        "pressure": np.random.uniform(1005, 1015, size=15),
        "wind_speed": np.random.uniform(5, 20, size=15),
        "precipitation": np.random.uniform(0, 5, size=15)
    })

    processed = MLDataPreprocessor.create_features(df)
    assert not processed.empty
    assert "temp_lag1" in processed.columns
    assert "target_next_day_temp" in processed.columns

def test_model_training_and_eval():
    """Test Random Forest training pipeline."""
    dates = pd.date_range(start="2026-01-01", periods=40, freq="D")
    df = pd.DataFrame({
        "time": dates,
        "temperature": np.linspace(20, 30, 40) + np.random.normal(0, 1, 40),
        "humidity": np.random.uniform(40, 80, size=40),
        "pressure": np.random.uniform(1005, 1015, size=40),
        "wind_speed": np.random.uniform(5, 20, size=40),
        "precipitation": np.random.uniform(0, 5, size=40)
    })

    trainer = WeatherModelTrainer()
    model, metrics, importance, y_test, y_pred = trainer.train_and_evaluate(df)

    assert model is not None
    assert "mae" in metrics
    assert "rmse" in metrics
    assert "r2" in metrics
    assert not importance.empty

def test_temperature_predictor_inference():
    """Test predictor inference output dictionary."""
    predictor = TemperaturePredictor()
    current = {
        "temperature": 25.0,
        "humidity": 60.0,
        "pressure": 1012.0,
        "wind_speed": 10.0,
        "precipitation": 0.0
    }
    res = predictor.predict_next_day(current)
    assert "predicted_temp" in res
    assert "lower_bound" in res
    assert "upper_bound" in res
    assert isinstance(res["predicted_temp"], float)
