"""Pytest test cases for statistics, anomaly detection, and comfort scores."""
import pytest
import pandas as pd
import numpy as np
from analysis.statistics import WeatherStatistics
from analysis.anomaly import WeatherAnomalyDetector
from analysis.weather_score import WeatherIntelligence

def test_summary_statistics():
    """Test summary statistics calculation."""
    df = pd.DataFrame({"temperature": [20.0, 22.0, 24.0, 26.0, 28.0]})
    stats = WeatherStatistics.calculate_summary_stats(df, "temperature")
    assert stats["mean"] == 24.0
    assert stats["min"] == 20.0
    assert stats["max"] == 28.0
    assert stats["median"] == 24.0
    assert stats["range"] == 8.0

def test_anomaly_detection_zscore():
    """Test Z-score anomaly detection logic."""
    temps = [25.0] * 20 + [50.0]  # 50.0 is an extreme outlier
    df = pd.DataFrame({"temperature": temps})
    res_df = WeatherAnomalyDetector.detect_zscore_anomalies(df, "temperature", threshold=2.0)
    assert "is_anomaly" in res_df.columns
    assert res_df["is_anomaly"].iloc[-1] == True

def test_comfort_score_calculation():
    """Test Weather Comfort Score logic."""
    res = WeatherIntelligence.calculate_comfort_score(
        temperature=22.0,
        humidity=50.0,
        wind_speed=10.0,
        precipitation_prob=0.0,
        uv_index=3.0
    )
    assert "score" in res
    assert res["score"] >= 80  # Ideal parameters should yield high comfort score
    assert "category" in res

def test_risk_indicator_high():
    """Test Weather Risk Indicator with severe weather values."""
    risk = WeatherIntelligence.calculate_risk_indicator(
        temperature=42.0,
        precipitation=15.0,
        wind_speed=55.0,
        uv_index=11.0,
        humidity=95.0
    )
    assert risk["level"] == "SEVERE"
    assert len(risk["reasons"]) > 0
