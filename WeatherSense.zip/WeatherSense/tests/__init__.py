"""Test package for WeatherSense."""
