"""Pytest test cases for SQLite Database operations."""
import pytest
import pandas as pd
from database.database import DatabaseManager

@pytest.fixture
def temp_db(tmp_path):
    """Fixture providing in-memory SQLite database instance."""
    db_file = tmp_path / "test_weather.db"
    db_url = f"sqlite:///{db_file}"
    return DatabaseManager(db_url=db_url)

def test_favorites_crud(temp_db):
    """Test adding, retrieving, checking, and removing favorites."""
    assert temp_db.add_favorite("Bangalore") == True
    assert temp_db.is_favorite("Bangalore") == True
    favs = temp_db.get_favorites()
    assert "Bangalore" in favs

    assert temp_db.remove_favorite("Bangalore") == True
    assert temp_db.is_favorite("Bangalore") == False

def test_search_history(temp_db):
    """Test search history recording and query."""
    temp_db.add_search_history("Delhi")
    temp_db.add_search_history("Delhi")
    history = temp_db.get_search_history()
    assert len(history) > 0
    delhi_entry = next((h for h in history if h["location"] == "Delhi"), None)
    assert delhi_entry is not None
    assert delhi_entry["visit_count"] == 2

def test_save_location_and_weather(temp_db):
    """Test saving location entity and weather records."""
    loc_id = temp_db.save_location("Mumbai", "India", 19.076, 72.8777)
    assert loc_id > 0

    now_df = pd.DataFrame([{
        "time": pd.Timestamp.now(),
        "temperature": 28.5,
        "feels_like": 30.0,
        "humidity": 75.0,
        "pressure": 1010.0,
        "precipitation": 0.0,
        "rain": 0.0,
        "wind_speed": 12.0,
        "wind_direction": 180.0,
        "cloud_cover": 20.0,
        "visibility": 10.0,
        "uv_index": 5.0,
        "weather_code": 1
    }])

    temp_db.save_weather_data(loc_id, now_df)
    hist = temp_db.get_weather_history(loc_id)
    assert not hist.empty
    assert len(hist) == 1
    assert hist["temperature"].iloc[0] == 28.5
