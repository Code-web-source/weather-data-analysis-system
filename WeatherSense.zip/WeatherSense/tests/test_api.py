"""Pytest test cases for Geocoding and Weather APIs."""
import pytest
from api.geocoding_api import GeocodingAPI
from api.weather_api import WeatherAPI

def test_geocoding_search_valid():
    """Test geocoding API with valid city name."""
    geo = GeocodingAPI()
    results = geo.search_location("Bangalore")
    assert isinstance(results, list)
    if results:
        first = results[0]
        assert "city" in first
        assert "latitude" in first
        assert "longitude" in first
        assert isinstance(first["latitude"], float)

def test_geocoding_search_invalid():
    """Test geocoding API with empty or non-existent city name."""
    geo = GeocodingAPI()
    results = geo.search_location("NonExistentCityXYZ12345")
    assert isinstance(results, list)
    assert len(results) == 0

def test_weather_api_structure():
    """Test weather API response dictionary structure for valid coordinates."""
    w_api = WeatherAPI()
    data = w_api.get_full_weather_data(12.9716, 77.5946)
    assert "current" in data
    assert "hourly" in data
    assert "daily" in data

    curr = data["current"]
    assert "temperature" in curr
    assert "humidity" in curr
    assert "wind_speed" in curr
