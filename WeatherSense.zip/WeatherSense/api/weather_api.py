"""Weather API module interacting with Open-Meteo Weather APIs."""
import requests
import pandas as pd
from datetime import date, datetime
from typing import Dict, Any, Optional
from config.config import Config
from utils.helpers import get_logger, degrees_to_cardinal
from utils.weather_codes import get_weather_description, get_weather_icon

logger = get_logger("weather_api")

class WeatherAPI:
    """Client for retrieving current, forecast, and historical weather from Open-Meteo."""

    def __init__(self):
        self.forecast_url = Config.OPEN_METEO_WEATHER_URL
        self.historical_url = Config.OPEN_METEO_HISTORICAL_URL

    def get_full_weather_data(self, lat: float, lon: float) -> Dict[str, Any]:
        """
        Fetch real-time current weather, 24h hourly forecast, and 7-day daily forecast in a single API call.
        """
        params = {
            "latitude": lat,
            "longitude": lon,
            "current": [
                "temperature_2m", "relative_humidity_2m", "apparent_temperature",
                "is_day", "precipitation", "rain", "showers", "snowfall",
                "weather_code", "cloud_cover", "pressure_msl", "surface_pressure",
                "wind_speed_10m", "wind_direction_10m", "uv_index"
            ],
            "hourly": [
                "temperature_2m", "relative_humidity_2m", "apparent_temperature",
                "precipitation_probability", "precipitation", "rain", "weather_code",
                "surface_pressure", "visibility", "wind_speed_10m", "wind_direction_10m", "uv_index"
            ],
            "daily": [
                "weather_code", "temperature_2m_max", "temperature_2m_min",
                "apparent_temperature_max", "apparent_temperature_min",
                "sunrise", "sunset", "uv_index_max", "precipitation_sum",
                "rain_sum", "precipitation_probability_max", "wind_speed_10m_max"
            ],
            "timezone": "auto"
        }

        try:
            response = requests.get(self.forecast_url, params=params, timeout=12)
            response.raise_for_status()
            data = response.json()

            current = data.get("current", {})
            current_code = current.get("weather_code", 0)

            parsed_current = {
                "time": current.get("time"),
                "temperature": current.get("temperature_2m"),
                "feels_like": current.get("apparent_temperature"),
                "humidity": current.get("relative_humidity_2m"),
                "precipitation": current.get("precipitation", 0.0),
                "rain": current.get("rain", 0.0),
                "snowfall": current.get("snowfall", 0.0),
                "weather_code": current_code,
                "weather_desc": get_weather_description(current_code),
                "weather_icon": get_weather_icon(current_code),
                "cloud_cover": current.get("cloud_cover"),
                "pressure": current.get("pressure_msl") or current.get("surface_pressure"),
                "wind_speed": current.get("wind_speed_10m"),
                "wind_direction": current.get("wind_direction_10m"),
                "wind_cardinal": degrees_to_cardinal(current.get("wind_direction_10m")),
                "uv_index": current.get("uv_index", 0.0),
                "visibility": 10.0,  # Default fallback if not available in current block
                "is_day": current.get("is_day", 1)
            }

            # Parse hourly forecast into DataFrame
            hourly_raw = data.get("hourly", {})
            hourly_df = pd.DataFrame(hourly_raw)
            if not hourly_df.empty and "time" in hourly_df.columns:
                hourly_df["time"] = pd.to_datetime(hourly_df["time"])
                hourly_df["weather_desc"] = hourly_df["weather_code"].apply(get_weather_description)
                hourly_df["weather_icon"] = hourly_df["weather_code"].apply(get_weather_icon)
                # Ensure visibility is in km if in meters
                if "visibility" in hourly_df.columns:
                    hourly_df["visibility_km"] = hourly_df["visibility"] / 1000.0
                    parsed_current["visibility"] = hourly_df["visibility_km"].iloc[0] if len(hourly_df) > 0 else 10.0

            # Parse daily forecast into DataFrame
            daily_raw = data.get("daily", {})
            daily_df = pd.DataFrame(daily_raw)
            if not daily_df.empty and "time" in daily_df.columns:
                daily_df["time"] = pd.to_datetime(daily_df["time"])
                daily_df["weather_desc"] = daily_df["weather_code"].apply(get_weather_description)
                daily_df["weather_icon"] = daily_df["weather_code"].apply(get_weather_icon)
                if "sunrise" in daily_df.columns and len(daily_df["sunrise"]) > 0:
                    parsed_current["sunrise"] = daily_df["sunrise"].iloc[0]
                    parsed_current["sunset"] = daily_df["sunset"].iloc[0]

            return {
                "current": parsed_current,
                "hourly": hourly_df,
                "daily": daily_df,
                "timezone": data.get("timezone", "UTC"),
                "elevation": data.get("elevation", 0.0)
            }

        except requests.RequestException as e:
            logger.error(f"Weather API request failed: {e}")
            raise RuntimeError(f"Unable to fetch real-time weather data. Please check your network connection.") from e

    def get_historical_weather(self, lat: float, lon: float, start_date: str, end_date: str) -> pd.DataFrame:
        """
        Fetch historical hourly & daily weather data from Open-Meteo Archive API.
        """
        params = {
            "latitude": lat,
            "longitude": lon,
            "start_date": start_date,
            "end_date": end_date,
            "hourly": [
                "temperature_2m", "relative_humidity_2m", "dew_point_2m",
                "apparent_temperature", "precipitation", "rain",
                "surface_pressure", "cloud_cover", "wind_speed_10m", "wind_direction_10m"
            ],
            "daily": [
                "weather_code", "temperature_2m_max", "temperature_2m_min",
                "temperature_2m_mean", "apparent_temperature_max", "apparent_temperature_min",
                "precipitation_sum", "rain_sum", "wind_speed_10m_max"
            ],
            "timezone": "auto"
        }

        try:
            response = requests.get(self.historical_url, params=params, timeout=15)
            response.raise_for_status()
            data = response.json()

            hourly_raw = data.get("hourly", {})
            df = pd.DataFrame(hourly_raw)
            if not df.empty:
                df["time"] = pd.to_datetime(df["time"])
                df.rename(columns={
                    "temperature_2m": "temperature",
                    "relative_humidity_2m": "humidity",
                    "apparent_temperature": "feels_like",
                    "surface_pressure": "pressure",
                    "wind_speed_10m": "wind_speed",
                    "wind_direction_10m": "wind_direction"
                }, inplace=True)
            return df
        except requests.RequestException as e:
            logger.error(f"Historical Weather API request failed: {e}")
            raise RuntimeError(f"Failed to retrieve historical weather archive for date range {start_date} to {end_date}.") from e
