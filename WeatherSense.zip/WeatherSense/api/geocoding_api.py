"""Geocoding API module using Open-Meteo Geocoding API."""
import requests
from typing import List, Dict, Any, Optional
from config.config import Config
from utils.helpers import get_logger

logger = get_logger("geocoding_api")

class GeocodingAPI:
    """Client for resolving location names into geographic coordinates."""

    def __init__(self):
        self.url = Config.OPEN_METEO_GEOCODING_URL

    def search_location(self, query: str, count: int = 5) -> List[Dict[str, Any]]:
        """
        Search for locations matching the given query string.
        Returns a list of location dicts: [{name, country, latitude, longitude, timezone, state}].
        """
        if not query or not query.strip():
            return []

        params = {
            "name": query.strip(),
            "count": count,
            "language": "en",
            "format": "json"
        }

        try:
            response = requests.get(self.url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            results = data.get("results", [])
            locations = []
            for item in results:
                locations.append({
                    "city": item.get("name", ""),
                    "country": item.get("country", ""),
                    "state": item.get("admin1", ""),
                    "latitude": float(item.get("latitude")),
                    "longitude": float(item.get("longitude")),
                    "timezone": item.get("timezone", "UTC"),
                    "elevation": item.get("elevation", 0.0),
                    "display_name": f"{item.get('name')}, {item.get('admin1') + ', ' if item.get('admin1') else ''}{item.get('country', '')}"
                })
            return locations
        except requests.RequestException as e:
            logger.error(f"Geocoding API request failed for query '{query}': {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error in geocoding for query '{query}': {e}")
            return []
