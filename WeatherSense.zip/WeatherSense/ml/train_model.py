"""Model training module using RandomForestRegressor."""
import joblib
import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple
from sklearn.ensemble import RandomForestRegressor
from config.config import Config
from ml.preprocessing import MLDataPreprocessor, FEATURE_COLUMNS
from ml.model_evaluation import ModelEvaluator
from utils.helpers import get_logger

logger = get_logger("train_model")

class WeatherModelTrainer:
    """Trains, evaluates, and persists Random Forest model for temperature forecasting."""

    def __init__(self, n_estimators: int = 100, random_state: int = 42):
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.model = RandomForestRegressor(
            n_estimators=self.n_estimators,
            random_state=self.random_state,
            max_depth=10,
            n_jobs=-1
        )
        self.feature_names = FEATURE_COLUMNS

    def train_and_evaluate(self, historical_df: pd.DataFrame) -> Tuple[Any, Dict[str, float], pd.DataFrame, np.ndarray, np.ndarray]:
        """
        Complete training pipeline: preprocessing -> train-test split -> fitting -> metric evaluation.
        """
        X_train, X_test, y_train, y_test, feature_names = MLDataPreprocessor.prepare_train_test_data(historical_df)

        logger.info(f"Training RandomForestRegressor on {len(X_train)} samples...")
        self.model.fit(X_train, y_train)

        y_pred = self.model.predict(X_test)
        metrics = ModelEvaluator.evaluate_predictions(y_test, y_pred)
        feature_importance = ModelEvaluator.extract_feature_importance(self.model, feature_names)

        # Save model checkpoint
        Config.ensure_directories()
        joblib.dump({
            "model": self.model,
            "feature_names": feature_names,
            "metrics": metrics
        }, Config.MODEL_FILE)

        logger.info(f"Model saved to {Config.MODEL_FILE}. Evaluation metrics: R2={metrics['r2']:.4f}, MAE={metrics['mae']:.2f}°C, RMSE={metrics['rmse']:.2f}°C")

        return self.model, metrics, feature_importance, y_test, y_pred
