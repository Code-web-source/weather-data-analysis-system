"""Data preprocessing and feature engineering for ML temperature forecasting."""
import pandas as pd
import numpy as np
from typing import Tuple, List

FEATURE_COLUMNS = [
    "temp_lag1",
    "humidity_lag1",
    "pressure_lag1",
    "wind_speed_lag1",
    "precipitation_lag1",
    "temp_rolling_mean_3",
    "humidity",
    "pressure",
    "wind_speed"
]

TARGET_COLUMN = "target_next_day_temp"

class MLDataPreprocessor:
    """Prepares time-series weather datasets into feature matrices and targets for ML training."""

    @staticmethod
    def create_features(df: pd.DataFrame) -> pd.DataFrame:
        """
        Engineers lag features, rolling statistics, and temporal targets for machine learning.
        """
        if df.empty or "temperature" not in df.columns:
            return pd.DataFrame()

        data = df.copy()
        if "time" in data.columns:
            data["time"] = pd.to_datetime(data["time"])
            data = data.sort_values("time").reset_index(drop=True)

        # Create daily aggregation if hourly data is passed
        if len(data) > 30 and "time" in data.columns and (data["time"].iloc[1] - data["time"].iloc[0]).total_seconds() < 86400:
            data["date"] = data["time"].dt.date
            daily = data.groupby("date").agg({
                "temperature": "mean",
                "humidity": "mean",
                "pressure": "mean",
                "wind_speed": "mean",
                "precipitation": "sum"
            }).reset_index()
            data = daily

        # Create lag features (previous day values)
        data["temp_lag1"] = data["temperature"].shift(1)
        data["humidity_lag1"] = data["humidity"].shift(1)
        data["pressure_lag1"] = data["pressure"].shift(1)
        data["wind_speed_lag1"] = data["wind_speed"].shift(1)
        data["precipitation_lag1"] = data["precipitation"].shift(1)

        # Rolling 3-day mean temperature
        data["temp_rolling_mean_3"] = data["temperature"].shift(1).rolling(window=3, min_periods=1).mean()

        # Target variable: next day temperature
        data[TARGET_COLUMN] = data["temperature"].shift(-1)

        # Drop NaNs resulting from shifts
        clean_df = data.dropna().reset_index(drop=True)
        return clean_df

    @staticmethod
    def prepare_train_test_data(df: pd.DataFrame, test_size: float = 0.2) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str]]:
        """
        Split preprocessed feature dataframe into X_train, X_test, y_train, y_test.
        """
        processed = MLDataPreprocessor.create_features(df)
        if processed.empty or len(processed) < 10:
            raise ValueError("Insufficient data to train ML model. At least 10 valid daily observations required.")

        X = processed[FEATURE_COLUMNS].values
        y = processed[TARGET_COLUMN].values

        split_idx = int(len(X) * (1 - test_size))
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]

        return X_train, X_test, y_train, y_test, FEATURE_COLUMNS
