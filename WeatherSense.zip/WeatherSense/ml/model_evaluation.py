"""Evaluation metrics and visualization tools for trained ML models."""
import numpy as np
import pandas as pd
from typing import Dict, Any, List
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

class ModelEvaluator:
    """Calculates MAE, RMSE, R-squared and feature importances."""

    @staticmethod
    def evaluate_predictions(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """
        Calculate Mean Absolute Error (MAE), Root Mean Squared Error (RMSE), and R² coefficient.
        """
        if len(y_true) == 0 or len(y_pred) == 0:
            return {"mae": 0.0, "rmse": 0.0, "r2": 0.0}

        mae = float(mean_absolute_error(y_true, y_pred))
        mse = mean_squared_error(y_true, y_pred)
        rmse = float(np.sqrt(mse))
        r2 = float(r2_score(y_true, y_pred))

        return {
            "mae": mae,
            "rmse": rmse,
            "r2": r2
        }

    @staticmethod
    def extract_feature_importance(model: Any, feature_names: List[str]) -> pd.DataFrame:
        """
        Extract feature importances from trained RandomForestRegressor model.
        """
        if not hasattr(model, "feature_importances_"):
            return pd.DataFrame()

        importances = model.feature_importances_
        df = pd.DataFrame({
            "Feature": feature_names,
            "Importance": importances
        }).sort_values(by="Importance", ascending=False).reset_index(drop=True)

        return df
