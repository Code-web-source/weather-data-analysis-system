# WeatherSense — Weather Data Analysis and Intelligence System
## BCA Final Year Academic Project Comprehensive Technical Documentation

---

## 1. INTRODUCTION
WeatherSense is a sophisticated Python-based Weather Data Analysis and Intelligence Platform engineered as a final-year Bachelor of Computer Applications (BCA) capstone project. Unlike basic weather apps that merely present static forecasts, WeatherSense functions as a comprehensive end-to-end data science and intelligence platform. It integrates real-time API ingestion, automated Extract-Transform-Load (ETL) pipelines, relational database persistence (SQLite/SQLAlchemy), statistical analysis, climate trend modeling, statistical anomaly detection, rule-based recommendation engines, interactive map visualizations, machine learning temperature forecasting, and automated executive PDF report generation.

The platform provides a modern dark-mode interactive dashboard developed in Streamlit, styled with custom CSS to deliver an enterprise-grade user interface suitable for academic viva presentation and production-style deployment.

---

## 2. PROBLEM STATEMENT
Traditional weather web portals and smartphone applications present several limitations for analytical decision-making:
- **Superficial Insights**: Existing apps focus solely on raw numbers (e.g., "25°C") without providing analytical context, statistical deviations, or historical comparisons.
- **Lack of Custom Intelligence**: Ordinary weather interfaces do not calculate personalized comfort indices, outdoor activity suitability windows, or environmental hazard indicators.
- **Static & Monolithic Data**: Data is rarely stored in an accessible database for custom statistical analysis or user-driven historical trend exploration.
- **Absence of Predictive Analytics**: Standard applications rely entirely on remote server outputs without providing on-device machine learning capabilities to evaluate model accuracy or feature importance.

WeatherSense solves these challenges by transforming raw meteorological streams into actionable insights using Python data science libraries.

---

## 3. PROJECT OBJECTIVES
The core objective of WeatherSense is to design and implement a modular software architecture that demonstrates mastery across multiple computer science domains:
1. **API Integration**: Connect to Open-Meteo REST APIs for geocoding, current observations, hourly/daily forecasts, and multi-year historical archives.
2. **ETL Pipeline**: Build reusable Extract, Transform, and Load functions to clean raw JSON payloads, handle missing values, standardize timestamps, and populate SQLite tables.
3. **Database Management**: Utilize SQLAlchemy ORM to manage normalized tables for locations, weather observations, search history, and user favorites.
4. **Data Analytics & Statistics**: Perform descriptive statistics (mean, median, std dev, IQR, percentiles), correlation heatmaps, and linear climate trend regression.
5. **Anomaly Detection**: Implement Z-score and Interquartile Range (IQR) algorithms to flag statistical temperature, rainfall, or wind anomalies.
6. **Weather Intelligence**: Develop custom metrics including Weather Comfort Score (0-100), Weather Risk Level (LOW to SEVERE), and Best Outdoor Time window finder.
7. **Machine Learning**: Train a `RandomForestRegressor` model to predict next-day temperatures, evaluate model accuracy (MAE, RMSE, R²), and output feature importances.
8. **Professional Dashboard**: Build a responsive dark-themed dashboard featuring interactive Plotly visualizations, Folium maps, and ReportLab PDF document export.

---

## 4. EXISTING VS. PROPOSED SYSTEM

| Feature / Aspect | Existing Weather Apps | Proposed WeatherSense System |
| :--- | :--- | :--- |
| **Data Architecture** | Monolithic, display-only | Modular, multi-tiered ETL pipeline |
| **Database Storage** | None (ephemeral API views) | Persistent SQLite database via SQLAlchemy |
| **Statistical Analysis** | Basic min/max values | Full descriptive statistics, percentiles, correlation |
| **Anomaly Detection** | None | Statistical Z-score & IQR outlier identification |
| **Custom Metrics** | Generic index values | Weather Comfort Score (0-100) & Risk Indicator |
| **Machine Learning** | Black-box remote API | On-device Random Forest training, MAE/RMSE/R² metrics |
| **Reporting & Export** | Screenshots only | CSV, Excel, and automated ReportLab PDF export |
| **Map Integration** | Static image overlays | Interactive dark tile Folium maps with popups |

---

## 5. SYSTEM SCOPE
WeatherSense is designed for global weather data exploration. Key operational scopes include:
- Location geocoding for global cities (Bangalore, Mumbai, Delhi, London, New York, Tokyo, etc.).
- Real-time weather observation & 24-hour hourly forecast visualization.
- 7 to 10-day daily forecast summaries.
- Historical data analysis spanning up to 5 years.
- Multi-city comparative side-by-side analysis.
- Next-day temperature forecasting using Scikit-Learn machine learning pipelines.
- Data export in CSV, Excel, and PDF formats.

---

## 6. FUNCTIONAL AND NON-FUNCTIONAL REQUIREMENTS

### 6.1 Functional Requirements
- **FR1 Location Search**: User can enter any city name to geocode coordinates and fetch weather parameters.
- **FR2 Real-time Display**: Display temperature, feels-like, humidity, pressure, wind speed/direction, cloud cover, visibility, UV index, sunrise, sunset.
- **FR3 Hourly & Daily Forecast**: Interactive line/bar charts for 24-hour trends and 7-day outlooks.
- **FR4 Historical Analytics**: Custom date range picker, statistical calculations (Mean, Median, Std Dev, Range, IQR), and climate trend regression lines.
- **FR5 Anomaly Detection**: Identify statistical outliers using Z-score (>2.0 std dev) and IQR criteria.
- **FR6 Comfort & Risk Engine**: Compute 0-100 Comfort Score, Risk level (LOW to SEVERE), and Best Outdoor Time window.
- **FR7 Multi-City Comparison**: Compare two or more cities side-by-side with grouped bar charts and analytical text.
- **FR8 ML Temperature Prediction**: Predict next-day temperature using Random Forest, output MAE, RMSE, R², and feature importances.
- **FR9 Interactive Weather Map**: Display Folium dark-mode map with interactive city markers and weather popups.
- **FR10 Report & Data Export**: Download raw CSV, structured Excel workbooks, and generated ReportLab PDF summary reports.
- **FR11 History & Favorites**: Persist search history logs with visit counts and manage favorite locations list.

### 6.2 Non-Functional Requirements
- **NFR1 Performance**: API response caching using Streamlit decorator to minimize external API overhead.
- **NFR2 Visual Excellence**: Custom dark mode aesthetic (`#0B1220` background, `#111827` cards, `#38BDF8` accent) adhering to modern UI design standards.
- **NFR3 Reliability & Error Handling**: Graceful fallback error messages for network failures, invalid input, or missing data without raising unhandled tracebacks.
- **NFR4 Maintainability**: Clean PEP 8 Python code split into modular packages (`config`, `api`, `database`, `analysis`, `ml`, `dashboard`, `components`, `utils`).

---

## 7. TECHNOLOGY STACK
- **Programming Language**: Python 3.11+
- **Frontend / UI**: Streamlit 1.28+
- **Data Processing**: Pandas 2.0+, NumPy 1.24+
- **Data Visualization**: Plotly 5.17+
- **Database / ORM**: SQLite, SQLAlchemy 2.0+
- **APIs**: Open-Meteo Geocoding, Forecast, & Archive REST APIs
- **Machine Learning**: Scikit-learn 1.3+ (`RandomForestRegressor`), Joblib
- **Geographic Mapping**: Folium, `streamlit-folium`
- **Report Generation**: ReportLab 4.0+, OpenPyXL 3.1+
- **Testing Suite**: pytest 7.4+

---

## 8. SYSTEM ARCHITECTURE
```
 ┌─────────────────────────────────────────────────────────┐
 │                   Streamlit Web UI                      │
 │   (app.py - Main Router & Navigation Controller)        │
 └───────────┬─────────────────────────────────┬───────────┘
             │                                 │
 ┌───────────▼───────────┐         ┌───────────▼───────────┐
 │   Dashboard Views     │         │   UI Components       │
 │ - live_weather        │         │ - styles.py (CSS)     │
 │ - forecast            │         │ - header & sidebar    │
 │ - historical          │         │ - cards.py (KPIs)     │
 │ - comparison          │         │ - charts.py (Plotly)  │
 │ - prediction (ML)     │         └───────────────────────┘
 │ - weather_map         │
 │ - alerts / intelligence│
 │ - reports             │
 └───────────┬───────────┘
             │
 ┌───────────▼─────────────────────────────────────────────┐
 │               Core Logic & Intelligence                 │
 ├───────────────────┬───────────────────┬─────────────────┤
 │   api/            │   analysis/       │   ml/           │
 │   - geocoding_api │   - statistics    │   - preprocessing│
 │   - weather_api   │   - trends        │   - train_model │
 │                   │   - anomaly       │   - prediction  │
 │                   │   - comparison    │   - evaluation  │
 │                   │   - weather_score │                 │
 └───────────┬───────┴─────────┬─────────┴─────────┬───────┘
             │                 │                   │
 ┌───────────▼─────────────────▼───────────────────▼───────┐
 │             Data Persistence & Utilities                │
 │   - database/ (SQLAlchemy models.py & database.py)      │
 │   - utils/ (etl_pipeline, export, weather_codes, etc.)  │
 │   - SQLite Storage (data/weather.db)                    │
 └─────────────────────────────────────────────────────────┘
```

---

## 9. DATABASE DESIGN (ER DIAGRAM DESCRIPTION)
The system uses SQLite with SQLAlchemy ORM. The relational model contains five tables:

1. **`locations`**: Stores geocoded cities.
   - `id` (INT, Primary Key, Auto-increment)
   - `city` (VARCHAR(100), Not Null)
   - `country` (VARCHAR(100))
   - `latitude` (FLOAT, Not Null)
   - `longitude` (FLOAT, Not Null)
   - `timezone` (VARCHAR(50))
   - `created_at` (DATETIME)

2. **`weather_data`**: Historical and real-time observations.
   - `id` (INT, Primary Key, Auto-increment)
   - `location_id` (INT, Foreign Key -> `locations.id`)
   - `timestamp` (DATETIME, Indexed)
   - `temperature`, `feels_like`, `humidity`, `pressure`, `precipitation`, `rain`, `wind_speed`, `wind_direction`, `cloud_cover`, `visibility`, `uv_index` (FLOAT)
   - `weather_code` (INT)

3. **`forecast_data`**: Stored forecast snapshots.
   - `id` (INT, Primary Key)
   - `location_id` (INT, Foreign Key -> `locations.id`)
   - `forecast_time` (DATETIME)
   - `temperature`, `humidity`, `precipitation_probability`, `wind_speed` (FLOAT)
   - `weather_code` (INT)

4. **`search_history`**: Audit trail of search queries.
   - `id` (INT, Primary Key)
   - `location` (VARCHAR(150))
   - `searched_at` (DATETIME)

5. **`favorites`**: User bookmarked locations.
   - `id` (INT, Primary Key)
   - `location` (VARCHAR(150), Unique)
   - `added_at` (DATETIME)

---

## 10. ETL PIPELINE METHODOLOGY
WeatherSense implements a structured Extract-Transform-Load (ETL) pipeline in `utils/etl_pipeline.py`:
1. **EXTRACT**: Interrogates Open-Meteo Geocoding and Weather Forecast REST APIs using python `requests` library. Raw JSON payloads are fetched.
2. **TRANSFORM**: Converts nested JSON dictionaries into standardized Pandas DataFrames. Converts ISO timestamps to datetime objects, standardizes units (°C, km/h, hPa, mm), handles missing values using forward-fill/backward-fill (`ffill/bfill`), and maps WMO codes to descriptions.
3. **LOAD**: Inserts cleaned records into SQLite database via SQLAlchemy bulk object persistence, preventing duplicate timestamp entries.

---

## 11. STATISTICAL & ANOMALY DETECTION METHODOLOGY
- **Descriptive Statistics**: Calculates Mean ($\mu$), Median, Minimum, Maximum, Standard Deviation ($\sigma$), Range, 25th Percentile ($Q_1$), and 75th Percentile ($Q_3$).
- **Z-Score Anomaly Detection**: Identifies statistical outliers using the formula:
  $$Z = \frac{X - \mu}{\sigma}$$
  Data points where $|Z| > 2.0$ are flagged as statistical anomalies.
- **IQR Anomaly Detection**: Outliers are defined as points outside the range:
  $$[Q_1 - 1.5 \times \text{IQR}, \quad Q_3 + 1.5 \times \text{IQR}]$$
  where $\text{IQR} = Q_3 - Q_1$.

---

## 12. MACHINE LEARNING METHODOLOGY
- **Target**: Predict next-day ambient temperature ($y = T_{t+1}$).
- **Algorithm**: `RandomForestRegressor` (Scikit-learn) with $N=100$ decision trees and max depth of 10.
- **Feature Matrix ($X$)**: Includes 1-day lag temperature (`temp_lag1`), lag humidity, lag pressure, lag wind speed, lag precipitation, and 3-day rolling mean temperature.
- **Evaluation Metrics**:
  - **Mean Absolute Error (MAE)**: $\frac{1}{n}\sum |y_i - \hat{y}_i|$
  - **Root Mean Squared Error (RMSE)**: $\sqrt{\frac{1}{n}\sum (y_i - \hat{y}_i)^2}$
  - **R-squared ($R^2$)**: $1 - \frac{\sum (y_i - \hat{y}_i)^2}{\sum (y_i - \bar{y})^2}$

---

## 13. TESTING & VERIFICATION
Automated unit tests are implemented in `tests/` using `pytest`:
- `test_api.py`: Validates geocoding searches and weather API dictionary schemas.
- `test_analysis.py`: Tests summary statistics, Z-score anomaly detection, and Weather Comfort Score logic.
- `test_database.py`: Tests SQLite schema initialization, favorites CRUD operations, and weather record insertion.
- `test_prediction.py`: Tests ML feature engineering, model training pipeline, and next-day inference.

All pytest test cases executed with **100% pass rate**.

---

## 14. LIMITATIONS & FUTURE SCOPE
### Limitations
- Weather forecasts rely on internet connectivity to Open-Meteo REST endpoints.
- Historical data availability depends on Open-Meteo archive depth for specific remote locations.
- Machine Learning model accuracy improves with longer historical time series datasets (minimum 30 daily observations recommended).

### Future Scope
- Incorporate satellite image layers into Folium weather maps.
- Support push notification alerts via WebSockets or Telegram bot API.
- Expand machine learning models to include LSTM neural networks for long-term multi-day temperature forecasting.

---

## 15. CONCLUSION
WeatherSense demonstrates a complete, production-grade final-year BCA project. By combining API data extraction, robust relational database modeling, quantitative statistical analysis, anomaly detection, machine learning, and modern UI design, the platform transforms raw weather data into intelligent actionable insights.
