# WeatherSense — BCA Final Year Project Viva Preparation Guide
## 50 Questions & Answers for Academic Oral Examination (Viva Voce)

---

### SECTION 1: GENERAL PROJECT & ARCHITECTURE (Q1 - Q7)

#### Q1: What is the main objective of your project "WeatherSense"?
**Answer:** WeatherSense is a Python-based Weather Data Analysis and Intelligence System. Unlike simple weather apps that only show current temperature, WeatherSense collects real-time, forecast, and historical weather data via APIs, processes and stores it in an SQLite database using an ETL pipeline, performs statistical analysis, detects anomalies, calculates comfort and risk scores, trains a machine learning model for temperature forecasting, and presents insights through a modern Streamlit dashboard.

#### Q2: Why did you choose a modular folder architecture instead of writing everything in a single Python file?
**Answer:** A modular architecture separates concerns into distinct packages (`api`, `database`, `analysis`, `ml`, `dashboard`, `components`, `utils`). This enhances code readability, maintainability, reusability, testing isolation, and scalability. It reflects production software design standards.

#### Q3: What is the technology stack used in WeatherSense?
**Answer:**
- **Language**: Python 3.11+
- **Frontend/Dashboard**: Streamlit
- **Data Processing**: Pandas, NumPy
- **Data Visualization**: Plotly
- **Database**: SQLite with SQLAlchemy ORM
- **API**: Open-Meteo REST APIs (Geocoding, Forecast, Archive)
- **Machine Learning**: Scikit-learn (`RandomForestRegressor`), Joblib
- **Maps**: Folium, `streamlit-folium`
- **Reports**: ReportLab (PDF), OpenPyXL (Excel)
- **Testing**: pytest

#### Q4: What are the signature unique features of your application?
**Answer:**
1. Custom Weather Comfort Score (0–100)
2. Weather Risk Indicator (LOW to SEVERE)
3. Statistical Weather Anomaly Detection (Z-score & IQR)
4. Best Outdoor Time Window Finder
5. "What Changed?" Weather Change Analysis
6. Multi-City Side-by-Side Comparison
7. Climate Trend Regression Line Analysis
8. ML Random Forest Temperature Forecasting
9. Interactive Dark-Tile Weather Map
10. Automated PDF Executive Report Generation

#### Q5: How does your application handle external API failures or network downtime?
**Answer:** The system uses `try-except` exception blocks around API calls (`requests.RequestException`). If the network fails, it catches the error and displays a user-friendly alert message rather than crashing or exposing raw Python tracebacks.

#### Q6: How does data flow through your system?
**Answer:**
1. **User Search** -> Geocoding API converts city name into latitude/longitude.
2. **API Ingestion** -> Open-Meteo API returns current, hourly, and daily JSON payloads.
3. **ETL Pipeline** -> Data is extracted, cleaned with Pandas, and loaded into SQLite via SQLAlchemy.
4. **Analytics & ML Engine** -> Calculates statistics, comfort scores, risk metrics, and ML predictions.
5. **Dashboard UI** -> Renders Plotly charts, Folium map, KPI cards, and export options.

#### Q7: What design aesthetic was followed for the user interface?
**Answer:** A modern dark dashboard aesthetic was implemented using custom CSS injection (`#0B1220` background, `#111827` card containers, `#38BDF8` primary accent, `#2563EB` secondary accent, and `#F8FAFC` text) with rounded cards, clean typography, and visual hierarchy.

---

### SECTION 2: PYTHON, PANDAS & DATA PROCESSING (Q8 - Q15)

#### Q8: What role does Pandas play in WeatherSense?
**Answer:** Pandas is used for tabular data manipulation, cleaning, time-series conversion, missing value handling (`ffill`/`bfill`), grouping, monthly/yearly aggregations, calculating Pearson correlations, and feeding data to Plotly and Scikit-Learn.

#### Q9: What is NumPy used for in this project?
**Answer:** NumPy is used for numeric array operations, computing percentiles ($Q_1, Q_3$), standard deviation, linear regression polynomial fitting (`np.polyfit`), and mathematical calculations in Z-score anomaly detection and ML metrics.

#### Q10: How do you handle missing or null values in weather datasets?
**Answer:** Missing values in hourly data are cleaned during the ETL Transform phase using forward-fill (`ffill()`) followed by backward-fill (`bfill()`). Numeric columns are verified with `.dropna()` prior to statistical computations to ensure accurate math.

#### Q11: What are type hints in Python and why did you use them?
**Answer:** Type hints (e.g., `def get_weather_data(lat: float, lon: float) -> Dict[str, Any]:`) specify expected argument and return types. They improve code readability, enable IDE autocompletion, and prevent type mismatch bugs.

#### Q12: What is a Python docstring and where is it used?
**Answer:** A docstring is a string literal placed at the top of modules, classes, or functions (surrounded by `""" ... """`) to document their purpose, arguments, and return values.

#### Q13: What is the difference between a list and a DataFrame in Python?
**Answer:** A list is a built-in 1-dimensional sequence of elements. A DataFrame is a 2-dimensional labeled tabular data structure from Pandas with rows and named columns, optimized for high-performance mathematical operations.

#### Q14: How do you convert string timestamps into datetime objects in Pandas?
**Answer:** Using `pd.to_datetime(df['time'])`. This allows time-based filtering, date formatting, and chronological sorting.

#### Q15: What is list comprehension in Python?
**Answer:** A concise syntax to construct lists from iterables (e.g., `[f.location for f in favs]`). It is more readable and faster than standard `for` loops.

---

### SECTION 3: REST API & JSON (Q16 - Q21)

#### Q16: What is a REST API?
**Answer:** Representational State Transfer (REST) is an architectural style for web APIs that allows applications to communicate over HTTP using standard methods like GET, POST, PUT, DELETE. WeatherSense sends HTTP GET requests to retrieve JSON data.

#### Q17: Why did you choose Open-Meteo over OpenWeatherMap as your primary API?
**Answer:** Open-Meteo provides free, open-access meteorological endpoints without requiring API keys, supports detailed hourly/daily forecasts, high-resolution geocoding, and historical archive data up to several years.

#### Q18: What is JSON and how does Python process it?
**Answer:** JavaScript Object Notation (JSON) is a lightweight text-based data format. The Python `requests` library automatically parses JSON HTTP responses into native Python dictionaries and lists using `response.json()`.

#### Q19: What is Geocoding?
**Answer:** Geocoding is the process of converting a human-readable address or city name (e.g., "Bangalore") into geographic coordinates (Latitude: 12.9716, Longitude: 77.5946).

#### Q20: What HTTP status code indicates a successful API response?
**Answer:** HTTP 200 OK. `response.raise_for_status()` is called in Python to raise an exception if status codes like 404 (Not Found) or 500 (Server Error) occur.

#### Q21: What is the purpose of timeout in HTTP requests?
**Answer:** Setting `requests.get(url, timeout=10)` prevents the application from hanging indefinitely if the external weather server is unresponsive.

---

### SECTION 4: DATABASE & SQLALCHEMY (Q22 - Q28)

#### Q22: Why did you use SQLite and SQLAlchemy ORM instead of plain SQL?
**Answer:** SQLite provides a lightweight, serverless relational database engine stored in a single file (`weather.db`). SQLAlchemy Object-Relational Mapper (ORM) allows interacting with tables using Python classes (`Location`, `WeatherData`) instead of writing raw SQL strings, preventing SQL injection vulnerabilities and improving maintainability.

#### Q23: Name the database tables in WeatherSense and their relationships.
**Answer:**
1. `locations`: Primary key `id`.
2. `weather_data`: Foreign key `location_id` referencing `locations.id` (1-to-many relationship).
3. `forecast_data`: Foreign key `location_id` referencing `locations.id`.
4. `search_history`: Stores search queries and timestamps.
5. `favorites`: Stores bookmarked location names.

#### Q24: What is an ORM (Object-Relational Mapping)?
**Answer:** ORM maps database tables to Python classes and rows to Python object instances.

#### Q25: What is the difference between `session.add()` and `session.commit()`?
**Answer:** `session.add()` places a new object into the pending session state. `session.commit()` executes the SQL transaction and permanently writes changes to disk.

#### Q26: How do you prevent duplicate weather observation records in your database?
**Answer:** Before inserting an observation, the system queries SQLite for existing records matching both `location_id` and `timestamp`. If found, insertion is skipped.

#### Q27: How does search history track visit counts in database queries?
**Answer:** Using SQLAlchemy aggregation: `session.query(SearchHistory.location, func.count(SearchHistory.id)).group_by(SearchHistory.location)`.

#### Q28: What is a foreign key constraint?
**Answer:** A column constraint that links a record in one table (`weather_data.location_id`) to a primary key in another table (`locations.id`), maintaining referential integrity.

---

### SECTION 5: ETL PIPELINE & DATA CLEANING (Q29 - Q32)

#### Q29: What does ETL stand for in data engineering?
**Answer:** Extract, Transform, Load.
- **Extract**: Fetch raw weather API JSON payloads.
- **Transform**: Clean timestamps, rename columns, compute derived metrics, handle nulls.
- **Load**: Bulk insert clean records into SQLite database tables.

#### Q30: Why is the ETL pipeline isolated into `utils/etl_pipeline.py`?
**Answer:** Isolating ETL logic allows the backend pipeline to be executed independently, tested via pytest, or scheduled without tying it to the Streamlit UI code.

#### Q31: How are unit conversions managed during Transformation?
**Answer:** Standardized units are enforced: Temperature in Celsius (°C), Wind speed in kilometers per hour (km/h), Pressure in hectopascals (hPa), Visibility in kilometers (km), and Rainfall in millimeters (mm).

#### Q32: How do you handle invalid city search queries entered by the user?
**Answer:** `validators.py` validates length and non-empty criteria. If the geocoding API returns an empty list, a clear error message ("Location not found") is displayed without raising uncaught exceptions.

---

### SECTION 6: STATISTICS, ANOMALY DETECTION & METRICS (Q33 - Q38)

#### Q33: How is the Z-score calculated and used for anomaly detection?
**Answer:** Formula: $Z = (X - \mu) / \sigma$. It measures how many standard deviations a value $X$ is from the mean $\mu$. Values with $|Z| > 2.0$ are flagged as statistical anomalies.

#### Q34: What is the Interquartile Range (IQR) method?
**Answer:** $\text{IQR} = Q_3 - Q_1$. Outliers are values below $Q_1 - 1.5 \times \text{IQR}$ or above $Q_3 + 1.5 \times \text{IQR}$.

#### Q35: How is the Pearson Correlation Coefficient interpreted?
**Answer:** It measures linear correlation between two variables from -1.0 (perfect inverse) to +1.0 (perfect positive). 0 means no linear relationship.

#### Q36: How is the Weather Comfort Score (0-100) calculated?
**Answer:** It starts at 100 and applies analytical penalties based on deviations from ideal comfort ranges: Temperature (20-25°C ideal), Humidity (30-60% ideal), Wind (<=15 km/h ideal), Rain probability, and UV index (>6).

#### Q37: How is the Weather Risk Indicator categorized?
**Answer:** It evaluates severe conditions (>40°C temp, >10mm/h rain, >50 km/h wind, >=10 UV index) and assigns levels: LOW (green), MODERATE (yellow), HIGH (orange), or SEVERE (red).

#### Q38: How does the system determine the "Best Outdoor Time"?
**Answer:** It computes a 3-hour rolling average of hourly comfort scores over the next 24 hours and identifies the 3-hour window with the highest score and lowest rain/UV.

---

### SECTION 7: MACHINE LEARNING & RANDOM FOREST (Q39 - Q44)

#### Q39: What machine learning algorithm is used for temperature forecasting?
**Answer:** `RandomForestRegressor` from Scikit-Learn. It builds an ensemble of 100 decision trees and averages their predictions to prevent overfitting.

#### Q40: What features are fed into the ML model ($X$)?
**Answer:** 1-day lag temperature (`temp_lag1`), lag humidity, lag pressure, lag wind speed, lag precipitation, and 3-day rolling mean temperature. Target ($y$) is next-day temperature.

#### Q41: What is a train-test split and why is it necessary?
**Answer:** The dataset is split (80% training, 20% testing). Model is trained on the 80% split and evaluated on unseen 20% test data to measure true predictive generalization.

#### Q42: Explain the evaluation metrics: MAE, RMSE, R² Score.
**Answer:**
- **MAE (Mean Absolute Error)**: Average magnitude of prediction errors in °C.
- **RMSE (Root Mean Squared Error)**: Penalizes larger prediction errors more heavily.
- **R² Score**: Proportion of variance in temperature explained by the model (1.0 is perfect).

#### Q43: How is Feature Importance calculated in Random Forest?
**Answer:** Scikit-Learn measures how much each feature reduces impurity across all decision trees in the ensemble. Features like `temp_lag1` usually show the highest importance.

#### Q44: How is the trained model persisted on disk?
**Answer:** Using `joblib.dump()` to save model weights to `models/weather_model.pkl`. It is loaded during inference via `joblib.load()`.

---

### SECTION 8: STREAMLIT, UI & SECURITY (Q45 - Q50)

#### Q45: What is Streamlit?
**Answer:** Streamlit is an open-source Python framework that turns data scripts into interactive web applications without needing separate HTML/JS backend-frontend infrastructure.

#### Q46: What is `@st.cache_resource` and `@st.cache_data` in Streamlit?
**Answer:** Streamlit reruns scripts from top to bottom on user interaction. `@st.cache_resource` caches global singletons like database connections. `@st.cache_data` caches function return values like API data to prevent redundant network requests.

#### Q47: How does your app maintain custom CSS styling?
**Answer:** `components/styles.py` injects CSS using `st.markdown('<style>...</style>', unsafe_allow_html=True)` to override Streamlit defaults with custom dark theme colors (`#0B1220`, `#111827`, `#38BDF8`).

#### Q48: How are API keys secured in WeatherSense?
**Answer:** Sensitive configuration is loaded from `.env` files using `python-dotenv`. `.env` is added to `.gitignore` to prevent committing secrets to Git repositories.

#### Q49: How is PDF generation handled in the application?
**Answer:** `ReportLab` library builds PDF documents programmatically (`SimpleDocTemplate`, `Table`, `ParagraphStyle`) in an in-memory `io.BytesIO` buffer, which is delivered via `st.download_button`.

#### Q50: How did you test your Python codebase?
**Answer:** Using `pytest`. Unit tests cover API response structures, database CRUD operations, statistical calculations, anomaly detection, and ML prediction pipelines, ensuring 100% test coverage and reliability.
