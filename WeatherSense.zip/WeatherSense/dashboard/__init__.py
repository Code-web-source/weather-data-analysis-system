"""Dashboard package for WeatherSense."""
from .dashboard import render_main_dashboard
from .live_weather import render_live_weather_page
from .forecast import render_forecast_page
from .historical import render_historical_page
from .comparison import render_comparison_page
from .prediction import render_prediction_page
from .weather_map import render_weather_map_page
from .alerts import render_alerts_page
from .reports import render_reports_page
from .settings import render_settings_page

__all__ = [
    "render_main_dashboard",
    "render_live_weather_page",
    "render_forecast_page",
    "render_historical_page",
    "render_comparison_page",
    "render_prediction_page",
    "render_weather_map_page",
    "render_alerts_page",
    "render_reports_page",
    "render_settings_page",
]
