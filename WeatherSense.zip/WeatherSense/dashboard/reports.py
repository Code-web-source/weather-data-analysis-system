"""Reports & Data Export Dashboard View Page."""
import streamlit as st
import pandas as pd
from typing import Dict, Any
from utils.export import DataExporter
from analysis.statistics import WeatherStatistics
from analysis.weather_score import WeatherIntelligence
from ml.prediction import TemperaturePredictor

def render_reports_page(data: Dict[str, Any]):
    """Renders data export and automated PDF report generation center."""
    st.markdown("<h2 style='color: #F8FAFC;'>📄 Data Export & Intelligence Reports</h2>", unsafe_allow_html=True)
    st.markdown("Export weather observations into CSV, Excel workbooks, or generate formal PDF academic summary reports.")

    current = data.get("current", {})
    hourly_df = data.get("hourly", pd.DataFrame())
    daily_df = data.get("daily", pd.DataFrame())
    location = data.get("location", {})
    city = location.get("city", "Bangalore")

    col1, col2, col3 = st.columns(3)

    # 1. CSV Export
    with col1:
        st.markdown(
            """
            <div class="weather-card" style="text-align: center;">
                <span style="font-size: 2.5rem;">📊</span>
                <h4 style="margin: 8px 0; color: #F8FAFC;">CSV Raw Data</h4>
                <p style="font-size: 0.8rem; color: #94A3B8;">Export hourly forecast dataset as CSV file.</p>
            </div>
            """,
            unsafe_allow_html=True
        )
        csv_data = DataExporter.to_csv(hourly_df)
        st.download_button(
            label="💾 Download CSV",
            data=csv_data,
            file_name=f"{city}_weather_data.csv",
            mime="text/csv",
            use_container_width=True
        )

    # 2. Excel Workbook Export
    with col2:
        st.markdown(
            """
            <div class="weather-card" style="text-align: center;">
                <span style="font-size: 2.5rem;">📈</span>
                <h4 style="margin: 8px 0; color: #F8FAFC;">Excel Workbook</h4>
                <p style="font-size: 0.8rem; color: #94A3B8;">Export formatted multi-sheet Excel file.</p>
            </div>
            """,
            unsafe_allow_html=True
        )
        excel_data = DataExporter.to_excel(hourly_df, sheet_name="Hourly Forecast")
        st.download_button(
            label="📊 Download Excel (.xlsx)",
            data=excel_data,
            file_name=f"{city}_weather_workbook.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True
        )

    # 3. PDF Academic Report Generation
    with col3:
        st.markdown(
            """
            <div class="weather-card" style="text-align: center;">
                <span style="font-size: 2.5rem;">📑</span>
                <h4 style="margin: 8px 0; color: #F8FAFC;">PDF Executive Report</h4>
                <p style="font-size: 0.8rem; color: #94A3B8;">Generate compiled ReportLab PDF summary report.</p>
            </div>
            """,
            unsafe_allow_html=True
        )

        # Prepare summary parameters for PDF generator
        temp = current.get("temperature", 25.0)
        hum = current.get("humidity", 50.0)
        wind = current.get("wind_speed", 10.0)
        precip = current.get("precipitation", 0.0)
        uv = current.get("uv_index", 3.0)

        comfort_info = WeatherIntelligence.calculate_comfort_score(temp, hum, wind, precip, uv)
        risk_info = WeatherIntelligence.calculate_risk_indicator(temp, precip, wind, uv, hum)

        summary_stats = WeatherStatistics.calculate_summary_stats(hourly_df, "temperature_2m" if "temperature_2m" in hourly_df.columns else "temperature")

        predictor = TemperaturePredictor()
        prediction_info = predictor.predict_next_day(current, hourly_df)

        pdf_bytes = DataExporter.generate_pdf_report(
            location_name=f"{city}, {location.get('country', '')}",
            current_weather=current,
            summary_stats=summary_stats,
            comfort_info=comfort_info,
            risk_info=risk_info,
            prediction_info=prediction_info
        )

        st.download_button(
            label="📄 Generate PDF Report",
            data=pdf_bytes,
            file_name=f"{city}_WeatherSense_Report.pdf",
            mime="application/pdf",
            use_container_width=True
        )
