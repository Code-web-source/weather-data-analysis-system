"""Detailed Live Weather View Page."""
import streamlit as st
import pandas as pd
from typing import Dict, Any
from components.cards import render_hero_weather_card, render_kpi_card
from utils.formatting import format_temp, format_wind, format_humidity, format_pressure, format_uv

def render_live_weather_page(data: Dict[str, Any]):
    """Renders comprehensive real-time weather metrics view."""
    st.markdown("<h2 style='color: #F8FAFC;'>🌡 Live Weather Observations</h2>", unsafe_allow_html=True)

    current = data.get("current", {})
    location = data.get("location", {})
    city = location.get("city", "Bangalore")
    country = location.get("country", "India")

    # Header Control Bar
    top_col1, top_col2 = st.columns([3, 1])
    with top_col1:
        st.caption(f"Last updated: {pd.Timestamp.now().strftime('%b %d, %Y %I:%M:%S %p')} ({data.get('timezone', 'UTC')})")
    with top_col2:
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.cache_data.clear()
            st.rerun()

    # Hero Weather Card
    render_hero_weather_card(city, country, current)

    st.markdown("<h3 style='color: #38BDF8; font-size: 1.2rem;'>Detailed Meteorological Variables</h3>", unsafe_allow_html=True)

    # 4x3 Metric Card Grid
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        render_kpi_card("Temperature", format_temp(current.get("temperature")), f"Feels like {format_temp(current.get('feels_like'))}", "🌡️")
        render_kpi_card("Precipitation", f"{current.get('precipitation', 0.0):.1f} mm", "Rainfall volume", "🌧️")

    with col2:
        render_kpi_card("Relative Humidity", format_humidity(current.get("humidity")), "Atmospheric moisture", "💧")
        render_kpi_card("Cloud Cover", f"{current.get('cloud_cover', 0)}%", "Sky cloud coverage", "☁️")

    with col3:
        render_kpi_card("Wind Speed", format_wind(current.get("wind_speed")), f"Direction: {current.get('wind_cardinal', 'N/A')}", "💨")
        render_kpi_card("Visibility", f"{current.get('visibility', 10.0):.1f} km", "Visual range", "👁️")

    with col4:
        render_kpi_card("Pressure", format_pressure(current.get("pressure")), "Surface pressure MSL", "⏲️")
        render_kpi_card("UV Index", format_uv(current.get("uv_index")), "Solar radiation level", "☀️")

    # Astronomical Data (Sunrise / Sunset)
    st.markdown("<h3 style='color: #38BDF8; font-size: 1.2rem; margin-top: 20px;'>🌅 Astronomical Cycle</h3>", unsafe_allow_html=True)
    astro_cols = st.columns(2)
    with astro_cols[0]:
        st.info(f"**Sunrise:** {current.get('sunrise', 'N/A')}")
    with astro_cols[1]:
        st.warning(f"**Sunset:** {current.get('sunset', 'N/A')}")
