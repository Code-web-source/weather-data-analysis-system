"""Main Dashboard Overview Page."""
import streamlit as st
import pandas as pd
from typing import Dict, Any
from components.cards import (
    render_hero_weather_card,
    render_kpi_card,
    render_intelligence_cards
)
from components.charts import (
    build_hourly_temp_chart,
    build_precipitation_prob_chart
)
from analysis.weather_score import WeatherIntelligence
from utils.formatting import format_temp, format_humidity, format_wind, format_pressure, format_uv
from utils.weather_codes import get_weather_icon

def render_main_dashboard(data: Dict[str, Any]):
    """Renders main executive dashboard view."""
    current = data.get("current", {})
    location = data.get("location", {})
    hourly_df = data.get("hourly", pd.DataFrame())
    daily_df = data.get("daily", pd.DataFrame())

    city = location.get("city", "Bangalore")
    country = location.get("country", "India")

    # 1. Hero Weather Showcase Card
    render_hero_weather_card(city, country, current)

    # 2. Modern KPI Metric Cards Grid
    kcol1, kcol2, kcol3, kcol4, kcol5, kcol6 = st.columns(6)
    with kcol1:
        render_kpi_card("Temperature", format_temp(current.get("temperature")), "Real-time", "🌡️")
    with kcol2:
        render_kpi_card("Humidity", format_humidity(current.get("humidity")), "Relative", "💧")
    with kcol3:
        render_kpi_card("Wind", format_wind(current.get("wind_speed")), f"{current.get('wind_cardinal', 'N/A')}", "💨")
    with kcol4:
        render_kpi_card("Pressure", format_pressure(current.get("pressure")), "Surface MSL", "⏲️")
    with kcol5:
        render_kpi_card("Visibility", f"{current.get('visibility', 10.0):.1f} km", "Visual range", "👁️")
    with kcol6:
        render_kpi_card("UV Index", format_uv(current.get("uv_index")), "Solar level", "☀️")

    st.markdown("<hr style='border-color: #1F2937; margin: 15px 0;'>", unsafe_allow_html=True)

    # 3. 24-Hour Interactive Hourly Forecast Line Chart
    st.markdown("<h3 style='color: #38BDF8; font-size: 1.2rem;'>⏱ 24-Hour Temperature & Rain Outlook</h3>", unsafe_allow_html=True)
    if not hourly_df.empty:
        h24 = hourly_df.head(24)
        c_chart1, c_chart2 = st.columns([2, 1])
        with c_chart1:
            fig_hourly = build_hourly_temp_chart(h24)
            st.plotly_chart(fig_hourly, use_container_width=True)
        with c_chart2:
            fig_precip = build_precipitation_prob_chart(h24)
            st.plotly_chart(fig_precip, use_container_width=True)
    else:
        st.warning("Hourly forecast chart unavailable.")

    # 4. 7-Day Forecast Cards Overview
    st.markdown("<h3 style='color: #38BDF8; font-size: 1.2rem; margin-top: 15px;'>🗓 7-Day Forecast Overview</h3>", unsafe_allow_html=True)
    if not daily_df.empty:
        d_cols = st.columns(min(len(daily_df), 7))
        for idx, row in daily_df.head(7).iterrows():
            with d_cols[idx % 7]:
                dt_str = pd.to_datetime(row["time"]).strftime("%a %d")
                code = row.get("weather_code", 0)
                icon = get_weather_icon(code)
                max_t = row.get("temperature_2m_max", 0.0)
                min_t = row.get("temperature_2m_min", 0.0)

                st.markdown(
                    f"""
                    <div class="kpi-card" style="padding: 10px;">
                        <div style="font-size: 0.75rem; color: #94A3B8;">{dt_str}</div>
                        <div style="font-size: 1.8rem; margin: 4px 0;">{icon}</div>
                        <div style="font-size: 0.95rem; font-weight: 700; color: #FFFFFF;">{max_t:.1f}°C</div>
                        <div style="font-size: 0.75rem; color: #38BDF8;">{min_t:.1f}°C</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

    st.markdown("<hr style='border-color: #1F2937; margin: 15px 0;'>", unsafe_allow_html=True)

    # 5. Weather Intelligence Cards (Comfort, Risk, Outdoor Recommendation)
    st.markdown("<h3 style='color: #38BDF8; font-size: 1.2rem;'>🧠 Weather Intelligence Suite</h3>", unsafe_allow_html=True)

    temp = current.get("temperature", 25.0)
    hum = current.get("humidity", 50.0)
    wind = current.get("wind_speed", 10.0)
    precip = current.get("precipitation", 0.0)
    uv = current.get("uv_index", 3.0)

    comfort = WeatherIntelligence.calculate_comfort_score(temp, hum, wind, precip, uv)
    risk = WeatherIntelligence.calculate_risk_indicator(temp, precip, wind, uv, hum)
    outdoor = WeatherIntelligence.get_outdoor_recommendation(temp, precip, uv, hum, wind)

    render_intelligence_cards(comfort, risk, outdoor)
