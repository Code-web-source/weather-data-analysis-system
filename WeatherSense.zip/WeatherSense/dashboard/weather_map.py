"""Interactive Folium Weather Map View Page."""
import streamlit as st
import folium
from streamlit_folium import st_folium
from typing import Dict, Any, List
from api.geocoding_api import GeocodingAPI
from api.weather_api import WeatherAPI

def render_weather_map_page(data: Dict[str, Any], geocoding_api: GeocodingAPI, weather_api: WeatherAPI):
    """Renders interactive Folium map displaying location markers with weather metrics."""
    st.markdown("<h2 style='color: #F8FAFC;'>🗺️ Interactive Weather Map</h2>", unsafe_allow_html=True)
    st.markdown("Explore real-time weather observations overlaid on interactive geographical maps.")

    location = data.get("location", {})
    curr = data.get("current", {})
    lat = location.get("latitude", 12.9716)
    lon = location.get("longitude", 77.5946)
    city = location.get("city", "Bangalore")

    # Multi-location map display support
    st.markdown("#### Map Display Configuration")
    additional_cities = st.multiselect(
        "Add Overlay Cities to Map",
        options=["Mumbai", "Delhi", "Chennai", "Kolkata", "London", "New York", "Tokyo"],
        default=["Mumbai", "Delhi"]
    )

    # Initialize Folium Map centered on active location
    m = folium.Map(
        location=[lat, lon],
        zoom_start=5,
        tiles="CartoDB dark_matter"  # Dark aesthetic map tiles matching theme!
    )

    # Add active city marker (Highlighted in Cyan)
    popup_html = f"""
    <div style="font-family: sans-serif; color: #111827;">
        <h4>{city}, {location.get('country', '')}</h4>
        <p><b>Temp:</b> {curr.get('temperature')}°C (Feels {curr.get('feels_like')}°C)</p>
        <p><b>Condition:</b> {curr.get('weather_desc')}</p>
        <p><b>Humidity:</b> {curr.get('humidity')}% | <b>Wind:</b> {curr.get('wind_speed')} km/h</p>
    </div>
    """
    folium.Marker(
        location=[lat, lon],
        popup=folium.Popup(popup_html, max_width=250),
        tooltip=f"{city}: {curr.get('temperature')}°C",
        icon=folium.Icon(color="blue", icon="cloud", prefix="fa")
    ).add_to(m)

    # Fetch and add overlay markers for additional cities
    for add_city in additional_cities:
        if add_city != city:
            locs = geocoding_api.search_location(add_city, count=1)
            if locs:
                l = locs[0]
                try:
                    w = weather_api.get_full_weather_data(l["latitude"], l["longitude"])
                    c = w["current"]
                    p_html = f"""
                    <div style="font-family: sans-serif; color: #111827;">
                        <h4>{l['city']}, {l.get('country', '')}</h4>
                        <p><b>Temp:</b> {c.get('temperature')}°C</p>
                        <p><b>Condition:</b> {c.get('weather_desc')}</p>
                        <p><b>Humidity:</b> {c.get('humidity')}%</p>
                    </div>
                    """
                    folium.Marker(
                        location=[l["latitude"], l["longitude"]],
                        popup=folium.Popup(p_html, max_width=250),
                        tooltip=f"{l['city']}: {c.get('temperature')}°C",
                        icon=folium.Icon(color="cyan", icon="info-sign")
                    ).add_to(m)
                except Exception:
                    pass

    # Render map in Streamlit
    st_folium(m, width=900, height=500)
