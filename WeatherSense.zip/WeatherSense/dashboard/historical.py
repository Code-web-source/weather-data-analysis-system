"""Historical Weather Analysis & Climate Statistics Page."""
import streamlit as st
import pandas as pd
from datetime import date, timedelta
from typing import Dict, Any
from api.weather_api import WeatherAPI
from analysis.statistics import WeatherStatistics
from analysis.trends import ClimateTrendAnalysis
from components.charts import build_correlation_heatmap, PLOTLY_DARK_LAYOUT
from utils.validators import validate_date_range
import plotly.express as px
import plotly.graph_objects as go

def render_historical_page(data: Dict[str, Any], weather_api: WeatherAPI):
    """Renders historical analysis view with statistical metrics and interactive charts."""
    st.markdown("<h2 style='color: #F8FAFC;'>📊 Historical Weather & Statistical Analysis</h2>", unsafe_allow_html=True)

    location = data.get("location", {})
    lat = location.get("latitude", 12.9716)
    lon = location.get("longitude", 77.5946)

    # Date Range Selection Controls
    st.markdown("### Select Analysis Parameters")
    c1, c2, c3 = st.columns([2, 2, 1])
    with c1:
        start_date = st.date_input("Start Date", value=date.today() - timedelta(days=90))
    with c2:
        end_date = st.date_input("End Date", value=date.today() - timedelta(days=1))
    with c3:
        st.markdown("<div style='margin-top:28px;'></div>", unsafe_allow_html=True)
        fetch_btn = st.button("📈 Fetch History", use_container_width=True)

    # Validate inputs
    is_valid, err_msg = validate_date_range(start_date, end_date)
    if not is_valid:
        st.error(f"⚠️ {err_msg}")
        return

    # Fetch or use session cached historical data
    cache_key = f"hist_{location.get('city')}_{start_date}_{end_date}"
    if fetch_btn or cache_key not in st.session_state:
        with st.spinner("Fetching historical archives from Open-Meteo..."):
            try:
                hist_df = weather_api.get_historical_weather(lat, lon, start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"))
                st.session_state[cache_key] = hist_df
            except Exception as e:
                st.error(f"Error retrieving historical data: {e}")
                return

    hist_df = st.session_state.get(cache_key, pd.DataFrame())

    if hist_df.empty:
        st.warning("No historical observations found for the selected timeframe.")
        return

    st.success(f"Loaded {len(hist_df)} historical records from {start_date} to {end_date}.")

    # --- 1. Statistical Summary Table ---
    st.markdown("### 1. Descriptive Statistical Summary")
    stats_rows = []
    metrics_to_calc = [
        ("temperature", "Temperature (°C)"),
        ("humidity", "Humidity (%)"),
        ("wind_speed", "Wind Speed (km/h)"),
        ("pressure", "Pressure (hPa)"),
        ("precipitation", "Precipitation (mm)")
    ]

    for col_key, col_name in metrics_to_calc:
        if col_key in hist_df.columns:
            s = WeatherStatistics.calculate_summary_stats(hist_df, col_key)
            stats_rows.append({
                "Metric": col_name,
                "Mean": f"{s['mean']:.2f}",
                "Median": f"{s['median']:.2f}",
                "Min": f"{s['min']:.1f}",
                "Max": f"{s['max']:.1f}",
                "Std Dev": f"{s['std']:.2f}",
                "Range": f"{s['range']:.2f}",
                "P25": f"{s['p25']:.1f}",
                "P75": f"{s['p75']:.1f}"
            })

    st.dataframe(pd.DataFrame(stats_rows), use_container_width=True)

    # --- 2. Interactive Charts & Climate Trends ---
    st.markdown("### 2. Meteorological Trends & Climate Analysis")

    tab1, tab2, tab3, tab4 = st.tabs(["🌡️ Temperature & Trend", "🌧️ Rainfall & Humidity", "💨 Wind & Pressure", "🔥 Correlation Heatmap"])

    with tab1:
        # Linear Trend Fit
        trend_info = ClimateTrendAnalysis.analyze_temperature_trend(hist_df, "time", "temperature")

        fig_temp = go.Figure()
        fig_temp.add_trace(go.Scatter(x=hist_df["time"], y=hist_df["temperature"], mode="lines", name="Observed Temp", line=dict(color="#38BDF8", width=1.5)))

        if trend_info.get("fitted_values"):
            fig_temp.add_trace(go.Scatter(x=hist_df["time"], y=trend_info["fitted_values"], mode="lines", name=f"Linear Trend ({trend_info['direction']})", line=dict(color="#EF4444", width=3, dash="dash")))

        fig_temp.update_layout(**PLOTLY_DARK_LAYOUT, title=f"Historical Temperature & Climate Trend Analysis ({trend_info['direction']})")
        st.plotly_chart(fig_temp, use_container_width=True)

        st.info(f"**Trend Analysis Insight:** {trend_info.get('summary', '')} (R² = {trend_info.get('r_squared', 0.0):.4f})")

    with tab2:
        c1, c2 = st.columns(2)
        with c1:
            fig_precip = px.line(hist_df, x="time", y="precipitation", title="Rainfall / Precipitation Trend (mm)", color_discrete_sequence=["#2563EB"])
            fig_precip.update_layout(**PLOTLY_DARK_LAYOUT)
            st.plotly_chart(fig_precip, use_container_width=True)
        with c2:
            fig_hum = px.line(hist_df, x="time", y="humidity", title="Relative Humidity Trend (%)", color_discrete_sequence=["#22D3EE"])
            fig_hum.update_layout(**PLOTLY_DARK_LAYOUT)
            st.plotly_chart(fig_hum, use_container_width=True)

    with tab3:
        c1, c2 = st.columns(2)
        with c1:
            fig_wind = px.line(hist_df, x="time", y="wind_speed", title="Wind Speed Trend (km/h)", color_discrete_sequence=["#F59E0B"])
            fig_wind.update_layout(**PLOTLY_DARK_LAYOUT)
            st.plotly_chart(fig_wind, use_container_width=True)
        with c2:
            fig_press = px.line(hist_df, x="time", y="pressure", title="Atmospheric Pressure Trend (hPa)", color_discrete_sequence=["#A855F7"])
            fig_press.update_layout(**PLOTLY_DARK_LAYOUT)
            st.plotly_chart(fig_press, use_container_width=True)

    with tab4:
        cols_for_corr = ["temperature", "humidity", "precipitation", "wind_speed", "pressure"]
        corr_matrix = WeatherStatistics.compute_correlation_matrix(hist_df, cols_for_corr)
        fig_corr = build_correlation_heatmap(corr_matrix)
        st.plotly_chart(fig_corr, use_container_width=True)

        # Automatic interpretation
        if not corr_matrix.empty and "temperature" in corr_matrix.columns and "humidity" in corr_matrix.columns:
            temp_hum_corr = corr_matrix.loc["temperature", "humidity"]
            rel_str = "inverse (negative)" if temp_hum_corr < 0 else "positive"
            st.markdown(f"**Correlation Insight:** Temperature and humidity exhibit a **{rel_str} correlation ({temp_hum_corr:.2f})** in the selected historical dataset.")
