"""Settings, Favorites, and Search History Persistence Page."""
import streamlit as st
import pandas as pd
from database.database import DatabaseManager

def render_settings_page(db: DatabaseManager):
    """Renders user preferences, favorites manager, and search log audit trail."""
    st.markdown("<h2 style='color: #F8FAFC;'>⚙️ Settings & Persistent Storage</h2>", unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["⭐ Favorite Locations", "📜 Search Log History", "🛠️ Database Maintenance"])

    # --- Tab 1: Favorites Manager ---
    with tab1:
        st.markdown("### Manage Saved Favorite Locations")
        curr_loc = st.session_state.get("selected_city", "Bangalore")

        is_fav = db.is_favorite(curr_loc)
        col_btn1, col_btn2 = st.columns([2, 3])

        with col_btn1:
            if is_fav:
                if st.button(f"❌ Remove '{curr_loc}' from Favorites", use_container_width=True):
                    db.remove_favorite(curr_loc)
                    st.success(f"Removed {curr_loc} from favorites.")
                    st.rerun()
            else:
                if st.button(f"⭐ Add '{curr_loc}' to Favorites", use_container_width=True):
                    db.add_favorite(curr_loc)
                    st.success(f"Saved {curr_loc} to favorites!")
                    st.rerun()

        st.markdown("#### Saved Favorites List")
        favs = db.get_favorites()
        if favs:
            for fav in favs:
                fc1, fc2 = st.columns([3, 1])
                with fc1:
                    st.write(f"⭐ **{fav}**")
                with fc2:
                    if st.button("Load", key=f"load_fav_{fav}"):
                        st.session_state["selected_city"] = fav
                        st.rerun()
        else:
            st.info("No favorite locations added yet.")

    # --- Tab 2: Search History ---
    with tab2:
        st.markdown("### Search History Audit Log")
        history = db.get_search_history(limit=20)
        if history:
            df_hist = pd.DataFrame(history)
            st.dataframe(df_hist, use_container_width=True)

            if st.button("🗑️ Clear Search History", use_container_width=True):
                db.clear_search_history()
                st.success("Search history cleared.")
                st.rerun()
        else:
            st.info("Search history log is empty.")

    # --- Tab 3: Database Maintenance ---
    with tab3:
        st.markdown("### Database Status & Cache Operations")
        st.markdown(f"**Database URL:** `{db.db_url}`")
        if st.button("🧹 Clear Streamlit Memory Cache", use_container_width=True):
            st.cache_data.clear()
            st.cache_resource.clear()
            st.success("Streamlit memory cache purged.")
