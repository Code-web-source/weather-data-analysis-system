"""Alerts, Anomaly Detection, Comfort Score & Risk Intelligence Page."""
import streamlit as st
import pandas as pd
from typing import Dict, Any
from analysis.anomaly import WeatherAnomalyDetector
from analysis.weather_score import WeatherIntelligence
from components.charts import build_comfort_gauge, build_anomaly_chart

def render_alerts_page(data: Dict[str, Any]):
    """Renders Weather Intelligence, Anomaly Detection, and Activity Recommendation View."""
    st.markdown("<h2 style='color: #F8FAFC;'>⚠️ Weather Alerts & Intelligence Engine</h2>", unsafe_allow_html=True)
    st.markdown("Advanced analytical suite calculating statistical anomalies, risk levels, comfort scores, and outdoor recommendations.")

    current = data.get("current", {})
    hourly_df = data.get("hourly", pd.DataFrame())

    # --- 1. Weather Comfort & Risk Section ---
    st.markdown("### 1. Environmental Risk & Comfort Indices")

    temp = current.get("temperature", 25.0)
    hum = current.get("humidity", 50.0)
    wind = current.get("wind_speed", 10.0)
    precip = current.get("precipitation", 0.0)
    uv = current.get("uv_index", 3.0)

    comfort = WeatherIntelligence.calculate_comfort_score(temp, hum, wind, precip, uv)
    risk = WeatherIntelligence.calculate_risk_indicator(temp, precip, wind, uv, hum)
    outdoor = WeatherIntelligence.get_outdoor_recommendation(temp, precip, uv, hum, wind)
    best_time = WeatherIntelligence.find_best_outdoor_window(hourly_df)

    col1, col2 = st.columns([1, 1])

    with col1:
        fig_gauge = build_comfort_gauge(comfort["score"])
        st.plotly_chart(fig_gauge, use_container_width=True)
        st.caption(f"ℹ️ {comfort['disclaimer']}")

    with col2:
        level = risk["level"]
        color = risk["color"]
        st.markdown(
            f"""
            <div class="weather-card" style="border-left: 6px solid {color}; padding: 20px;">
                <h4 style="margin: 0; color: #94A3B8;">ASSESSED RISK LEVEL</h4>
                <h2 style="color: {color}; font-weight: 800; font-size: 2.2rem; margin: 4px 0;">{level}</h2>
                <p style="font-size: 0.85rem; color: #F8FAFC;"><b>Primary Factors:</b></p>
                <ul>
                    {"".join([f"<li>{r}</li>" for r in risk['reasons']])}
                </ul>
                <p style="font-size: 0.7rem; color: #64748B; margin-top: 15px;">{risk['disclaimer']}</p>
            </div>
            """,
            unsafe_allow_html=True
        )

    # --- 2. Outdoor Activity & Best Outdoor Time ---
    st.markdown("### 2. Activity & Time Window Recommendations")
    a_col1, a_col2 = st.columns(2)

    with a_col1:
        st.markdown(
            f"""
            <div class="weather-card">
                <h4 style="margin: 0; color: #38BDF8;">🏃 General Outdoor Guidance</h4>
                <h3 style="color: #F8FAFC; margin: 8px 0;">{outdoor['verdict']}</h3>
                <p style="font-size: 0.85rem; color: #94A3B8;">Factors evaluated:</p>
                <ul>
                    {"".join([f"<li>{f}</li>" for f in outdoor['factors']])}
                </ul>
            </div>
            """,
            unsafe_allow_html=True
        )

    with a_col2:
        st.markdown(
            f"""
            <div class="weather-card" style="border: 1px solid #22D3EE;">
                <h4 style="margin: 0; color: #22D3EE;">⏰ Best Outdoor Time Window</h4>
                <h2 style="color: #FFFFFF; margin: 6px 0;">{best_time['window']}</h2>
                <p style="font-size: 0.85rem; color: #94A3B8;">• Comfort Index: <b>{best_time['comfort_score']}/100</b></p>
                <p style="font-size: 0.85rem; color: #94A3B8;">• Rain Probability: <b>{best_time['rain_probability']}%</b> | UV: <b>{best_time['uv_index']}</b></p>
                <p style="font-size: 0.75rem; color: #64748B; margin-top: 10px;">Calculated from 24-hour forecast rolling averages.</p>
            </div>
            """,
            unsafe_allow_html=True
        )

    # --- 3. Statistical Anomaly Detection ---
    st.markdown("### 3. Statistical Anomaly Detection (Z-Score & IQR)")
    if not hourly_df.empty:
        # Detect Z-score anomalies on hourly temperature
        anom_df = WeatherAnomalyDetector.detect_zscore_anomalies(hourly_df, "temperature_2m", threshold=2.0)
        fig_anom = build_anomaly_chart(anom_df, "temperature_2m")
        st.plotly_chart(fig_anom, use_container_width=True)

        st.caption("Note: Red diamond markers represent observations exceeding 2.0 standard deviations from the sample mean.")
    else:
        st.warning("Hourly dataset unavailable for anomaly calculation.")
