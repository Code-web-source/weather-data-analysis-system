"""Interactive Hourly and Daily Forecast View Page."""
import streamlit as st
import pandas as pd
from typing import Dict, Any
from components.charts import (
    build_hourly_temp_chart,
    build_precipitation_prob_chart,
    build_daily_min_max_chart
)
from utils.weather_codes import get_weather_icon, get_weather_description

def render_forecast_page(data: Dict[str, Any]):
    """Renders hourly and 7-day forecast visualizations."""
    st.markdown("<h2 style='color: #F8FAFC;'>📅 Weather Forecast Center</h2>", unsafe_allow_html=True)

    hourly_df = data.get("hourly", pd.DataFrame())
    daily_df = data.get("daily", pd.DataFrame())

    tab1, tab2 = st.tabs(["⏱️ 24-Hour Hourly Forecast", "🗓️ 7-Day Daily Forecast"])

    with tab1:
        st.markdown("### Next 24 Hours Meteorological Trends")

        if not hourly_df.empty:
            # First 24 hours slice
            h24 = hourly_df.head(24)

            # Chart 1: Temperature & Feels Like Line Chart
            fig_temp = build_hourly_temp_chart(h24)
            st.plotly_chart(fig_temp, use_container_width=True)

            # Chart 2: Rain Probability Bar Chart
            fig_rain = build_precipitation_prob_chart(h24)
            st.plotly_chart(fig_rain, use_container_width=True)

            # Interactive Data Table
            with st.expander("🔍 View Detailed Hourly Data Table"):
                display_cols = ["time", "temperature", "feels_like", "humidity", "wind_speed", "precipitation_probability", "weather_desc"]
                avail_cols = [c for c in display_cols if c in h24.columns]
                st.dataframe(h24[avail_cols], use_container_width=True)
        else:
            st.warning("Hourly forecast data is currently unavailable.")

    with tab2:
        st.markdown("### 7-Day Outlook & Daily Trends")

        if not daily_df.empty:
            # Plotly 7-day Min/Max Band Chart
            fig_daily = build_daily_min_max_chart(daily_df)
            st.plotly_chart(fig_daily, use_container_width=True)

            # Render Daily Forecast Cards Grid
            st.markdown("#### Daily Forecast Summaries")
            cols = st.columns(min(len(daily_df), 7))

            for idx, row in daily_df.head(7).iterrows():
                with cols[idx % 7]:
                    dt_str = pd.to_datetime(row["time"]).strftime("%a, %b %d")
                    code = row.get("weather_code", 0)
                    icon = get_weather_icon(code)
                    max_t = row.get("temperature_2m_max", 0.0)
                    min_t = row.get("temperature_2m_min", 0.0)
                    rain_p = row.get("precipitation_probability_max", 0)

                    st.markdown(
                        f"""
                        <div class="weather-card" style="text-align: center; padding: 12px;">
                            <div style="font-size: 0.8rem; font-weight: 700; color: #94A3B8;">{dt_str}</div>
                            <div style="font-size: 2.2rem; margin: 8px 0;">{icon}</div>
                            <div style="font-size: 1.1rem; font-weight: 800; color: #F8FAFC;">{max_t:.1f}°C</div>
                            <div style="font-size: 0.85rem; color: #38BDF8;">{min_t:.1f}°C</div>
                            <div style="font-size: 0.75rem; color: #64748B; margin-top: 6px;">☔ {int(rain_p)}% Rain</div>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )
        else:
            st.warning("Daily forecast data unavailable.")
