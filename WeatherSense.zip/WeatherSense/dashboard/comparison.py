"""Multi-City Comparative Weather Analytics Page."""
import streamlit as st
import pandas as pd
from typing import Dict, Any
from api.geocoding_api import GeocodingAPI
from api.weather_api import WeatherAPI
from analysis.comparison import CityComparison
from components.charts import PLOTLY_DARK_LAYOUT
import plotly.express as px
import plotly.graph_objects as go

def render_comparison_page(weather_api: WeatherAPI, geocoding_api: GeocodingAPI):
    """Renders side-by-side multi-city weather comparative dashboard."""
    st.markdown("<h2 style='color: #F8FAFC;'>🆚 Multi-City Weather Comparison</h2>", unsafe_allow_html=True)
    st.markdown("Compare real-time weather metrics and physical parameters across multiple global cities.")

    # Multi-select city input
    default_cities = ["Bangalore", "Mumbai", "Delhi"]
    selected_cities = st.multiselect(
        "Select Cities to Compare",
        options=["Bangalore", "Mumbai", "Delhi", "Chennai", "Kolkata", "London", "New York", "Tokyo", "Sydney", "Paris", "Dubai"],
        default=default_cities
    )

    if not selected_cities or len(selected_cities) < 2:
        st.warning("Please select at least 2 cities to perform comparative analysis.")
        return

    # Fetch weather data for each city
    cities_payload = []
    with st.spinner("Fetching multi-city meteorological payloads..."):
        for city in selected_cities:
            locs = geocoding_api.search_location(city, count=1)
            if locs:
                loc = locs[0]
                try:
                    w_data = weather_api.get_full_weather_data(loc["latitude"], loc["longitude"])
                    cities_payload.append({
                        "city": loc["city"],
                        "country": loc["country"],
                        "current": w_data["current"]
                    })
                except Exception as e:
                    st.error(f"Could not load data for {city}: {e}")

    if not cities_payload:
        return

    # Build Comparative Table & Insights
    df_comp = CityComparison.compare_current_weather(cities_payload)

    # 1. Comparative Metrics Data Table
    st.markdown("### 1. Cross-City Meteorological Metrics Table")
    st.dataframe(df_comp, use_container_width=True)

    # 2. Analytical Insights (Factual, no subjective value judgment)
    st.markdown("### 2. Factual Analytical Contrast")
    insights = CityComparison.generate_analytical_contrast(df_comp)
    for ins in insights:
        st.info(ins)

    # 3. Interactive Comparative Grouped Bar Charts
    st.markdown("### 3. Visual Comparative Analytics")

    col1, col2 = st.columns(2)
    with col1:
        fig_temp = px.bar(
            df_comp,
            x="City",
            y=["Temperature (°C)", "Feels Like (°C)"],
            barmode="group",
            title="Temperature & Feels Like Comparison (°C)",
            color_discrete_sequence=["#38BDF8", "#2563EB"]
        )
        fig_temp.update_layout(**PLOTLY_DARK_LAYOUT)
        st.plotly_chart(fig_temp, use_container_width=True)

    with col2:
        fig_hum_wind = px.bar(
            df_comp,
            x="City",
            y=["Humidity (%)", "Wind Speed (km/h)"],
            barmode="group",
            title="Humidity (%) & Wind Speed (km/h)",
            color_discrete_sequence=["#22D3EE", "#F59E0B"]
        )
        fig_hum_wind.update_layout(**PLOTLY_DARK_LAYOUT)
        st.plotly_chart(fig_hum_wind, use_container_width=True)
