// Local replacement for Canva's Data SDK. Saved locations are stored in browser localStorage.
(function () {
  const KEY = "weathersense_saved_locations_v1";
  let handler = null;
  function read() { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; } }
  function write(records) { localStorage.setItem(KEY, JSON.stringify(records)); if (handler) handler.onDataChanged(read()); }
  window.dataSdk = {
    async init(h) { handler = h; if (handler) handler.onDataChanged(read()); return { isOk: true }; },
    async create(record) { const records = read(); const item = { ...record, __backendId: crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()) }; records.push(item); write(records); return { isOk: true, item }; },
    async update(record) { const records = read(); const i = records.findIndex(r => r.__backendId === record.__backendId); if (i < 0) return { isOk: false, error: "Record not found" }; records[i] = { ...records[i], ...record }; write(records); return { isOk: true, item: records[i] }; }
  };
})();


    const state = {
      location: null,
      weather: null,
      comparisons: [],
      historyData: [],
      savedRecords: [],
      map: null,
      mapLayer: null,
      dataReady: false
    };

    const weatherCodes = {
      0: ["Clear sky", "☀"], 1: ["Mainly clear", "🌤"], 2: ["Partly cloudy", "⛅"],
      3: ["Overcast", "☁"], 45: ["Fog", "🌫"], 48: ["Rime fog", "🌫"],
      51: ["Light drizzle", "🌦"], 53: ["Drizzle", "🌦"], 55: ["Dense drizzle", "🌧"],
      61: ["Slight rain", "🌦"], 63: ["Moderate rain", "🌧"], 65: ["Heavy rain", "🌧"],
      71: ["Light snow", "🌨"], 73: ["Snowfall", "🌨"], 75: ["Heavy snow", "❄"],
      80: ["Rain showers", "🌦"], 81: ["Rain showers", "🌧"], 82: ["Violent showers", "⛈"],
      95: ["Thunderstorm", "⛈"], 96: ["Thunderstorm with hail", "⛈"], 99: ["Severe thunderstorm", "⛈"]
    };

    const chartLayout = (title = "") => ({
      title: { text: title, font: { color: "#f8fafc", size: 14 }, x: 0 },
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(15,23,42,.35)",
      font: { color: "#94a3b8", family: "DM Sans" },
      margin: { l: 48, r: 20, t: 38, b: 42 },
      xaxis: { gridcolor: "rgba(148,163,184,.12)", zerolinecolor: "rgba(148,163,184,.12)" },
      yaxis: { gridcolor: "rgba(148,163,184,.12)", zerolinecolor: "rgba(148,163,184,.12)" },
      legend: { orientation: "h", y: 1.13 }
    });

    function weatherInfo(code) {
      return weatherCodes[code] || ["Unknown conditions", "◌"];
    }

    function setError(message) {
      const box = document.getElementById("error-box");
      box.textContent = message;
      box.style.display = "block";
    }

    function clearError() {
      document.getElementById("error-box").style.display = "none";
    }

    function number(value, digits = 0) {
      return Number.isFinite(value) ? Number(value).toFixed(digits) : "--";
    }

    function formatTime(value) {
      if (!value) return "--";
      return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(new Date(value));
    }

    function isoToShort(value) {
      return new Intl.DateTimeFormat(undefined, { weekday: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
    }

    function formatDate(value) {
      return new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(new Date(value + "T12:00:00"));
    }

    async function fetchJson(url) {
      const response = await fetch(url);
      if (!response.ok) throw new Error("Weather service could not complete the request.");
      return response.json();
    }

    function loadDemoDataset() {
      const location = { name: "Bengaluru", country: "India", latitude: 12.9716, longitude: 77.5946, timezone: "Asia/Kolkata" };
      const now = new Date();
      const currentTime = new Date(now); currentTime.setMinutes(0, 0, 0);
      const hours = Array.from({length: 48}, (_, i) => {
        const time = new Date(currentTime.getTime() + i * 3600000);
        const hour = time.getHours();
        return { time: time.toISOString().slice(0, 16), temperature: 24 + 5 * Math.sin((hour - 6) * Math.PI / 12) + Math.sin(i / 4), humidity: 68 - Math.round(12 * Math.sin((hour - 6) * Math.PI / 12)), feels: 25 + 5 * Math.sin((hour - 6) * Math.PI / 12), rainChance: i % 9 < 2 ? 55 : 12, precipitation: i % 9 < 2 ? 0.8 : 0, code: i % 9 < 2 ? 61 : hour > 7 && hour < 17 ? 2 : 0, wind: 8 + Math.round(4 * Math.sin(i / 5)), uv: Math.max(0, 8 * Math.sin((hour - 6) * Math.PI / 12)) };
      });
      const days = Array.from({length: 10}, (_, i) => {
        const date = new Date(now); date.setDate(date.getDate() + i);
        return { date: date.toISOString().slice(0, 10), code: i % 3 === 1 ? 61 : 2, max: 31 + (i % 3), min: 21 + (i % 2), rain: i % 3 === 1 ? 65 : 15, rainSum: i % 3 === 1 ? 4.2 : 0.2, wind: 16 + i % 5, uv: 8, sunrise: `${date.toISOString().slice(0, 10)}T06:10`, sunset: `${date.toISOString().slice(0, 10)}T18:05` };
      });
      const current = hours[0];
      state.location = location;
      state.weather = {
        timezone_abbreviation: "IST", current: { time: current.time, temperature_2m: current.temperature, relative_humidity_2m: current.humidity, apparent_temperature: current.feels, precipitation: current.precipitation, weather_code: current.code, cloud_cover: 35, pressure_msl: 1012, surface_pressure: 1008, wind_speed_10m: current.wind, wind_direction_10m: 120, visibility: 10000 },
        hourly: { time: hours.map(h=>h.time), temperature_2m: hours.map(h=>h.temperature), relative_humidity_2m: hours.map(h=>h.humidity), apparent_temperature: hours.map(h=>h.feels), precipitation_probability: hours.map(h=>h.rainChance), precipitation: hours.map(h=>h.precipitation), weather_code: hours.map(h=>h.code), wind_speed_10m: hours.map(h=>h.wind), uv_index: hours.map(h=>h.uv) },
        daily: { time: days.map(d=>d.date), weather_code: days.map(d=>d.code), temperature_2m_max: days.map(d=>d.max), temperature_2m_min: days.map(d=>d.min), precipitation_probability_max: days.map(d=>d.rain), precipitation_sum: days.map(d=>d.rainSum), wind_speed_10m_max: days.map(d=>d.wind), sunrise: days.map(d=>d.sunrise), sunset: days.map(d=>d.sunset), uv_index_max: days.map(d=>d.uv) }
      };
      updateDashboard(); renderForecast(); renderForecastCharts(); updateMap(); addCurrentToComparisons();
      setError("DEMO DATASET — Showing sample Bengaluru weather. Search or refresh to try live weather data.");
    }

    async function searchLocation(query) {
      const cleanQuery = query.trim();
      if (!cleanQuery) {
        setError("Enter a city or location before searching.");
        return;
      }
      clearError();
      setLoading(true);
      try {
        const endpoint = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cleanQuery)}&count=8&language=en&format=json`;
        const geo = await fetchJson(endpoint);
        if (!geo.results || !geo.results.length) {
          throw new Error("No matching location was found. Try a city name such as Bengaluru, Mumbai, London, or New York.");
        }
        const match = geo.results[0];
        const location = {
          name: match.name,
          country: match.country || "Unknown country",
          latitude: match.latitude,
          longitude: match.longitude,
          timezone: match.timezone || "auto"
        };
        await loadWeather(location);
        await saveSearch(location);
      } catch (error) {
        setError(error.message || "Unable to retrieve weather data. Check your connection and try again.");
      } finally {
        setLoading(false);
      }
    }

    async function loadWeather(location) {
      const params = new URLSearchParams({
        latitude: location.latitude,
        longitude: location.longitude,
        current: "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,visibility",
        hourly: "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,wind_speed_10m,uv_index",
        daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max,sunrise,sunset,uv_index_max",
        timezone: "auto",
        forecast_days: "10"
      });
      const data = await fetchJson(`https://api.open-meteo.com/v1/forecast?${params}`);
      state.location = location;
      state.weather = data;
      updateDashboard();
      renderForecast();
      renderForecastCharts();
      updateMap();
      addCurrentToComparisons();
    }

    function updateDashboard() {
      const current = state.weather.current;
      const daily = state.weather.daily;
      const info = weatherInfo(current.weather_code);
      const location = state.location;

      document.getElementById("location-name").textContent = `${location.name}, ${location.country}`;
      document.getElementById("current-temp").textContent = `${number(current.temperature_2m, 1)}°`;
      document.getElementById("weather-condition").textContent = info[0];
      document.getElementById("weather-orb").textContent = info[1];
      document.getElementById("feels-temp").textContent = `${number(current.apparent_temperature, 1)}°`;
      document.getElementById("updated-time").textContent = `Updated ${formatTime(current.time)}`;
      document.getElementById("timezone").textContent = state.weather.timezone_abbreviation || location.timezone;
      document.getElementById("latitude").textContent = `${number(location.latitude, 3)}°`;
      document.getElementById("longitude").textContent = `${number(location.longitude, 3)}°`;
      document.getElementById("sunrise").textContent = formatTime(daily.sunrise[0]);
      document.getElementById("sunset").textContent = formatTime(daily.sunset[0]);
      document.getElementById("humidity-value").textContent = `${number(current.relative_humidity_2m)}%`;
      document.getElementById("wind-value").textContent = `${number(current.wind_speed_10m)} km/h`;
      document.getElementById("pressure-value").textContent = `${number(current.pressure_msl)} hPa`;
      document.getElementById("visibility-value").textContent = `${number(current.visibility / 1000, 1)} km`;
      document.getElementById("uv-value").textContent = `${number(state.weather.hourly.uv_index[new Date().getHours()], 1)}`;
      document.getElementById("precip-value").textContent = `${number(current.precipitation, 1)} mm`;
      document.getElementById("hourly-summary").textContent = `Updated ${formatTime(current.time)}`;

      renderSignals();
    }

    function renderSignals() {
      const current = state.weather.current;
      const hourly = state.weather.hourly;
      const currentHour = new Date().getHours();
      const rainProbability = hourly.precipitation_probability[currentHour] || 0;
      const uv = hourly.uv_index[currentHour] || 0;
      const temp = current.temperature_2m;
      const humidity = current.relative_humidity_2m;
      const wind = current.wind_speed_10m;

      let comfort = 100;
      comfort -= Math.min(35, Math.abs(temp - 23) * 2.4);
      comfort -= Math.min(20, Math.max(0, humidity - 60) * .45);
      comfort -= Math.min(22, rainProbability * .30);
      comfort -= Math.min(15, Math.max(0, wind - 14) * .65);
      comfort -= Math.min(12, Math.max(0, uv - 5) * 2.0);
      comfort = Math.round(Math.max(0, Math.min(100, comfort)));

      let risk = "LOW";
      let riskNote = "Conditions are within typical activity thresholds.";
      let riskColor = "#22c55e";
      const riskPoints = (temp >= 38 ? 3 : temp >= 33 ? 1 : 0) + (rainProbability >= 75 ? 2 : rainProbability >= 45 ? 1 : 0) + (wind >= 45 ? 2 : wind >= 30 ? 1 : 0) + (uv >= 9 ? 2 : uv >= 7 ? 1 : 0);
      if (riskPoints >= 5) { risk = "SEVERE"; riskNote = "Multiple elevated weather factors are active."; riskColor = "#ef4444"; }
      else if (riskPoints >= 3) { risk = "HIGH"; riskNote = "Use additional caution with outdoor plans."; riskColor = "#f97316"; }
      else if (riskPoints >= 1) { risk = "MODERATE"; riskNote = "One or more conditions may affect outdoor activity."; riskColor = "#f59e0b"; }

      document.getElementById("comfort-score").textContent = `${comfort}/100`;
      document.getElementById("comfort-score").style.color = comfort >= 70 ? "#22c55e" : comfort >= 45 ? "#f59e0b" : "#ef4444";
      document.getElementById("comfort-note").textContent = `Project-defined score using temperature, humidity, rain chance, wind and UV.`;
      document.getElementById("risk-level").innerHTML = `<span class="status-dot" style="background:${riskColor}"></span>${risk}`;
      document.getElementById("risk-note").textContent = `${riskNote} This is an analytical indicator, not an official warning.`;

      const influential = [];
      if (rainProbability >= 40) influential.push(`rain probability is ${rainProbability}%`);
      if (uv >= 7) influential.push(`UV is elevated (${number(uv, 1)})`);
      if (wind >= 25) influential.push(`wind is ${number(wind)} km/h`);
      if (temp >= 33 || temp <= 10) influential.push(`temperature is ${number(temp, 1)}°C`);
      document.getElementById("outdoor-note").textContent = influential.length
        ? `Outdoor conditions may be less favorable because ${influential.join(", ")}.`
        : "Outdoor activity conditions are favorable based on the measured temperature, wind, rain probability, humidity and UV.";
    }

    function currentHourlyIndices() {
      const now = new Date();
      const time = state.weather.hourly.time;
      let start = time.findIndex(t => new Date(t) >= now);
      return { start: start < 0 ? 0 : start, end: Math.min((start < 0 ? 0 : start) + 24, time.length) };
    }

    function renderForecast() {
      const { daily } = state.weather;
      const holder = document.getElementById("daily-forecast");
      holder.innerHTML = "";
      daily.time.forEach((date, index) => {
        const node = document.getElementById("forecast-day-template").content.cloneNode(true);
        const condition = weatherInfo(daily.weather_code[index]);
        node.querySelector(".forecast-date").textContent = formatDate(date);
        node.querySelector(".weather-icon").textContent = condition[1];
        node.querySelector(".forecast-condition").textContent = condition[0];
        node.querySelector(".forecast-temp").textContent = `${number(daily.temperature_2m_min[index])}° / ${number(daily.temperature_2m_max[index])}°`;
        node.querySelector(".forecast-rain").textContent = `${number(daily.precipitation_probability_max[index])}% rain`;
        holder.appendChild(node);
      });

      const { start, end } = currentHourlyIndices();
      const body = document.getElementById("hourly-table-body");
      body.innerHTML = "";
      for (let i = start; i < end; i++) {
        const tr = document.createElement("tr");
        tr.className = "table-row";
        const condition = weatherInfo(state.weather.hourly.weather_code[i]);
        tr.innerHTML = `<td class="px-5 py-3 text-slate-300">${isoToShort(state.weather.hourly.time[i])}</td>
          <td class="px-5 py-3">${condition[1]} <span class="ml-1 text-slate-400">${condition[0]}</span></td>
          <td class="px-5 py-3 font-semibold">${number(state.weather.hourly.temperature_2m[i], 1)}°C</td>
          <td class="px-5 py-3 text-slate-300">${number(state.weather.hourly.apparent_temperature[i], 1)}°C</td>
          <td class="px-5 py-3 text-cyan-300">${number(state.weather.hourly.precipitation_probability[i])}%</td>
          <td class="px-5 py-3">${number(state.weather.hourly.relative_humidity_2m[i])}%</td>
          <td class="px-5 py-3">${number(state.weather.hourly.wind_speed_10m[i])} km/h</td>`;
        body.appendChild(tr);
      }
    }

    function renderForecastCharts() {
      const hourly = state.weather.hourly;
      const { start, end } = currentHourlyIndices();
      const times = hourly.time.slice(start, end).map(isoToShort);
      const temps = hourly.temperature_2m.slice(start, end);
      const precipitation = hourly.precipitation_probability.slice(start, end);

      Plotly.react("hourly-chart", [
        { x: times, y: temps, type: "scatter", mode: "lines+markers", name: "Temperature °C", line: { color: "#38bdf8", width: 3 }, marker: { size: 5 }, fill: "tozeroy", fillcolor: "rgba(56,189,248,.08)" },
        { x: times, y: precipitation, type: "bar", name: "Rain chance %", yaxis: "y2", marker: { color: "rgba(37,99,235,.55)" } }
      ], { ...chartLayout(), yaxis: { title: "°C", gridcolor: "rgba(148,163,184,.12)" }, yaxis2: { title: "%", overlaying: "y", side: "right", range: [0,100], showgrid:false }, margin: { l: 42, r: 42, t: 25, b: 44 } }, { responsive: true, displayModeBar: false });

      Plotly.react("temperature-chart", [{ x: times, y: temps, type: "scatter", mode: "lines+markers", line: { color: "#22d3ee", width: 3 }, marker:{ color:"#38bdf8" }, fill:"tozeroy", fillcolor:"rgba(34,211,238,.09)", hovertemplate:"%{x}<br>%{y:.1f}°C<extra></extra>" }], chartLayout(), { responsive: true, displayModeBar: false });
      Plotly.react("precipitation-chart", [{ x: times, y: precipitation, type: "bar", marker: { color: "#2563eb" }, hovertemplate:"%{x}<br>%{y}% probability<extra></extra>" }], { ...chartLayout(), yaxis: { title: "Probability (%)", range:[0,100], gridcolor:"rgba(148,163,184,.12)" } }, { responsive: true, displayModeBar: false });
    }

    async function runAnalysis() {
      if (!state.location) return;
      setLoading(true);
      clearError();
      try {
        const end = new Date();
        const start = new Date(end);
        start.setDate(start.getDate() - 30);
        const toDate = d => d.toISOString().slice(0, 10);
        const params = new URLSearchParams({
          latitude: state.location.latitude,
          longitude: state.location.longitude,
          start_date: toDate(start),
          end_date: toDate(end),
          daily: "temperature_2m_mean,temperature_2m_max,temperature_2m_min,precipitation_sum,rain_sum,wind_speed_10m_max,weather_code",
          timezone: "auto"
        });
        const data = await fetchJson(`https://archive-api.open-meteo.com/v1/archive?${params}`);
        const daily = data.daily;
        state.historyData = daily.time.map((date, i) => ({
          date,
          temperature: daily.temperature_2m_mean[i],
          high: daily.temperature_2m_max[i],
          low: daily.temperature_2m_min[i],
          precipitation: daily.precipitation_sum[i],
          wind: daily.wind_speed_10m_max[i],
          weatherCode: daily.weather_code[i]
        })).filter(row => Number.isFinite(row.temperature));
        renderAnalysis();
      } catch (error) {
        setError("Historical analysis could not be loaded for this location. The Open-Meteo archive may not cover the selected date or region.");
      } finally {
        setLoading(false);
      }
    }

    function average(values) { return values.reduce((sum, value) => sum + value, 0) / values.length; }
    function standardDeviation(values) {
      const mean = average(values);
      return Math.sqrt(average(values.map(value => (value - mean) ** 2)));
    }

    function renderAnalysis() {
      const rows = state.historyData;
      if (!rows.length) return;
      const temps = rows.map(r => r.temperature);
      const mean = average(temps);
      const std = standardDeviation(temps);
      const min = Math.min(...temps), max = Math.max(...temps);
      const last = temps[temps.length - 1];
      const z = std ? (last - mean) / std : 0;
      const prediction = last + (temps[temps.length - 1] - temps[0]) / Math.max(1, temps.length - 1);

      document.getElementById("stat-mean").textContent = `${number(mean, 1)}°C`;
      document.getElementById("stat-minmax").textContent = `${number(min, 1)}°–${number(max, 1)}°`;
      document.getElementById("stat-std").textContent = `${number(std, 1)}°C`;
      document.getElementById("stat-prediction").textContent = `${number(prediction, 1)}°C`;

      Plotly.react("historical-chart", [
        { x: rows.map(r => r.date), y: rows.map(r => r.temperature), type:"scatter", mode:"lines+markers", name:"Mean temp", line:{color:"#38bdf8", width:3}, marker:{size:5} },
        { x: rows.map(r => r.date), y: rows.map(r => r.precipitation), type:"bar", name:"Rainfall mm", yaxis:"y2", marker:{color:"rgba(37,99,235,.45)"} }
      ], { ...chartLayout(), yaxis:{title:"Temperature °C",gridcolor:"rgba(148,163,184,.12)"}, yaxis2:{title:"Rainfall mm",overlaying:"y",side:"right",showgrid:false} }, {responsive:true,displayModeBar:false});

      const anomalyBox = document.getElementById("anomaly-results");
      anomalyBox.innerHTML = "";
      const anomalyData = [
        ["Latest temperature", last, mean, z, "°C"],
        ["Maximum wind", rows[rows.length - 1].wind, average(rows.map(r => r.wind)), 0, "km/h"],
        ["Latest rainfall", rows[rows.length - 1].precipitation, average(rows.map(r => r.precipitation)), 0, "mm"]
      ];
      anomalyData.forEach(([label, observed, baseline, suppliedZ, unit]) => {
        const localStd = label === "Latest temperature" ? std : standardDeviation(label.includes("wind") ? rows.map(r=>r.wind) : rows.map(r=>r.precipitation));
        const score = suppliedZ || (localStd ? (observed - baseline) / localStd : 0);
        const status = Math.abs(score) >= 2.5 ? "EXTREME" : Math.abs(score) >= 1.5 ? "UNUSUAL" : Math.abs(score) >= 1 ? "MODERATE" : "NORMAL";
        const color = status === "NORMAL" ? "#22c55e" : status === "MODERATE" ? "#f59e0b" : "#ef4444";
        const el = document.createElement("div");
        el.className = "rounded-xl border border-slate-700/60 bg-slate-900/50 p-3";
        el.innerHTML = `<div class="flex justify-between gap-3"><span class="font-semibold">${label}</span><span style="color:${color}" class="font-bold">${status}</span></div><p class="mt-1 text-xs text-slate-400">Observed ${number(observed,1)}${unit} · historical average ${number(baseline,1)}${unit} · deviation ${number(score,2)} z-score</p>`;
        anomalyBox.appendChild(el);
      });

      const wind = rows.map(r => r.wind);
      const rain = rows.map(r => r.precipitation);
      const correlation = (a,b) => {
        const meanA=average(a),meanB=average(b);
        const numerator=a.reduce((sum,x,i)=>sum+(x-meanA)*(b[i]-meanB),0);
        const denom=Math.sqrt(a.reduce((sum,x)=>sum+(x-meanA)**2,0)*b.reduce((sum,x)=>sum+(x-meanB)**2,0));
        return denom ? numerator/denom : 0;
      };
      const matrix = [[1,correlation(temps,rain),correlation(temps,wind)],[correlation(rain,temps),1,correlation(rain,wind)],[correlation(wind,temps),correlation(wind,rain),1]];
      const labels = ["Temperature", "Rainfall", "Wind"];
      Plotly.react("correlation-chart", [{ z:matrix, x:labels, y:labels, type:"heatmap", zmin:-1,zmax:1, colorscale:[[0,"#2563eb"],[.5,"#111827"],[1,"#ef4444"]], text:matrix.map(row=>row.map(v=>v.toFixed(2))), texttemplate:"%{text}", hovertemplate:"%{x} / %{y}: %{z:.2f}<extra></extra>", colorbar:{title:"Correlation",tickfont:{color:"#94a3b8"}} }], { ...chartLayout(), margin:{l:95,r:40,t:20,b:55} }, {responsive:true,displayModeBar:false});
      const tempRain = matrix[0][1];
      const direction = tempRain > .25 ? "positive" : tempRain < -.25 ? "negative" : "weak";
      document.getElementById("correlation-insight").textContent = `Temperature and rainfall show a ${direction} correlation (${tempRain.toFixed(2)}) in this selected historical dataset. This is a calculated relationship, not a causal conclusion.`;
    }

    function addCurrentToComparisons() {
      if (!state.location || !state.weather) return;
      const exists = state.comparisons.some(item => item.location.name === state.location.name && item.location.country === state.location.country);
      if (!exists) state.comparisons.unshift({ location: {...state.location}, weather: state.weather });
      state.comparisons = state.comparisons.slice(0, 4);
      renderComparison();
    }

    function renderComparison() {
      const holder = document.getElementById("compare-cards");
      holder.innerHTML = "";
      state.comparisons.forEach(item => {
        const node = document.getElementById("comparison-card-template").content.cloneNode(true);
        const c = item.weather.current;
        node.querySelector(".comparison-name").textContent = item.location.name;
        node.querySelector(".comparison-country").textContent = item.location.country;
        node.querySelector(".comparison-icon").textContent = weatherInfo(c.weather_code)[1];
        node.querySelector(".comparison-temp").textContent = `${number(c.temperature_2m,1)}°C`;
        node.querySelector(".comparison-humidity").textContent = `${number(c.relative_humidity_2m)}%`;
        node.querySelector(".comparison-wind").textContent = `${number(c.wind_speed_10m)} km/h`;
        node.querySelector(".comparison-pressure").textContent = `${number(c.pressure_msl)} hPa`;
        const hour = new Date().getHours();
        node.querySelector(".comparison-uv").textContent = number(item.weather.hourly.uv_index[hour],1);
        holder.appendChild(node);
      });

      if (state.comparisons.length) {
        Plotly.react("comparison-chart", [
          { x: state.comparisons.map(i=>i.location.name), y: state.comparisons.map(i=>i.weather.current.temperature_2m), name:"Temperature °C", type:"bar", marker:{color:"#38bdf8"} },
          { x: state.comparisons.map(i=>i.location.name), y: state.comparisons.map(i=>i.weather.current.relative_humidity_2m), name:"Humidity %", type:"bar", marker:{color:"#2563eb"} }
        ], { ...chartLayout(), barmode:"group", yaxis:{gridcolor:"rgba(148,163,184,.12)"} }, {responsive:true,displayModeBar:false});
      }
    }

    function updateMap() {
      if (!state.location) return;
      if (!state.map) {
        state.map = L.map("weather-map", { scrollWheelZoom: false }).setView([state.location.latitude, state.location.longitude], 6);
        state.map.attributionControl.setPrefix(false);
        L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'
        }).addTo(state.map);
        state.mapLayer = L.layerGroup().addTo(state.map);
      }
      state.mapLayer.clearLayers();
      const locations = state.comparisons.length ? state.comparisons : [{location:state.location, weather:state.weather}];
      locations.forEach(item => {
        const current = item.weather.current;
        L.marker([item.location.latitude,item.location.longitude]).addTo(state.mapLayer).bindPopup(`<strong>${item.location.name}</strong><br>${number(current.temperature_2m,1)}°C · ${weatherInfo(current.weather_code)[0]}<br>Humidity: ${number(current.relative_humidity_2m)}%<br>Wind: ${number(current.wind_speed_10m)} km/h`);
      });
      state.map.setView([state.location.latitude, state.location.longitude], 6);
      setTimeout(() => state.map.invalidateSize(), 120);
    }

    async function saveSearch(location) {
      if (!state.dataReady) return;
      const result = await window.dataSdk.create({
        record_type: "search",
        location_name: location.name,
        country: location.country,
        latitude: location.latitude,
        longitude: location.longitude,
        searched_at: new Date().toISOString(),
        is_favorite: false
      });
      if (!result.isOk) setError("Weather loaded, but the location could not be saved to your Canva Sheet.");
    }

    function renderSavedLists() {
      const favorites = state.savedRecords.filter(r => r.is_favorite);
      const history = state.savedRecords.filter(r => r.record_type === "search").sort((a,b)=>new Date(b.searched_at)-new Date(a.searched_at)).slice(0,8);
      renderSavedCollection("favorites-list", favorites, "No favorite locations yet. Search a city, then select Add favorite.");
      renderSavedCollection("history-list", history, "Your successful location searches will appear here.");
    }

    function renderSavedCollection(id, records, emptyText) {
      const holder = document.getElementById(id);
      holder.innerHTML = "";
      if (!records.length) {
        const empty = document.createElement("p");
        empty.className = "py-5 text-sm text-slate-500";
        empty.textContent = emptyText;
        holder.appendChild(empty);
        return;
      }
      records.forEach(record => {
        const node = document.getElementById("saved-location-template").content.cloneNode(true);
        const root = node.querySelector(".saved-item");
        node.querySelector(".saved-name").textContent = `${record.is_favorite ? "★ " : ""}${record.location_name}`;
        node.querySelector(".saved-meta").textContent = `${record.country} · ${new Date(record.searched_at).toLocaleDateString()}`;
        node.querySelector(".saved-load").addEventListener("click", () => searchLocation(record.location_name));
        const favoriteButton = node.querySelector(".saved-favorite");
        favoriteButton.style.color = record.is_favorite ? "#fbbf24" : "#94a3b8";
        favoriteButton.addEventListener("click", () => toggleFavoriteRecord(record));
        root.dataset.id = record.__backendId;
        holder.appendChild(node);
      });
      lucide.createIcons();
    }

    async function toggleFavoriteRecord(record) {
      if (!state.dataReady) return;
      const result = await window.dataSdk.update({...record, is_favorite: !record.is_favorite, record_type: !record.is_favorite ? "favorite" : "search"});
      if (!result.isOk) setError("Unable to update this favorite in your Canva Sheet.");
    }

    async function favoriteCurrentLocation() {
      if (!state.location || !state.dataReady) return;
      const existing = state.savedRecords.find(r => r.location_name === state.location.name && r.country === state.location.country && r.is_favorite);
      if (existing) {
        await toggleFavoriteRecord(existing);
        return;
      }
      const button = document.getElementById("favorite-button");
      button.disabled = true;
      const result = await window.dataSdk.create({
        record_type: "favorite",
        location_name: state.location.name,
        country: state.location.country,
        latitude: state.location.latitude,
        longitude: state.location.longitude,
        searched_at: new Date().toISOString(),
        is_favorite: true
      });
      button.disabled = false;
      if (!result.isOk) setError("Unable to add this location to favorites.");
    }

    function exportCsv() {
      if (!state.historyData.length) {
        setError("Load historical analysis before exporting data.");
        return;
      }
      const header = "date,mean_temperature_c,max_temperature_c,min_temperature_c,precipitation_mm,wind_speed_kmh\n";
      const rows = state.historyData.map(r => `${r.date},${r.temperature},${r.high},${r.low},${r.precipitation},${r.wind}`).join("\n");
      const blob = new Blob([header + rows], {type:"text/csv"});
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${state.location.name.toLowerCase().replace(/\s+/g,"-")}-weather-history.csv`;
      link.click();
      URL.revokeObjectURL(url);
    }

    function setLoading(isLoading) {
      document.querySelector("main").classList.toggle("loading-shimmer", isLoading);
      document.getElementById("search-button").disabled = isLoading;
      document.getElementById("refresh-button").disabled = isLoading;
    }

    function activateView(viewName) {
      document.querySelectorAll(".view-panel").forEach(panel => panel.classList.remove("active"));
      document.querySelectorAll(".nav-button").forEach(button => button.classList.remove("active"));
      document.getElementById(`${viewName}-view`).classList.add("active");
      document.querySelector(`[data-view="${viewName}"]`).classList.add("active");
      if (viewName === "map" && state.map) setTimeout(() => state.map.invalidateSize(), 100);
    }

    document.getElementById("search-form").addEventListener("submit", event => {
      event.preventDefault();
      searchLocation(document.getElementById("city-search").value);
    });
    document.getElementById("refresh-button").addEventListener("click", () => {
      if (state.location) loadWeather(state.location).catch(() => setError("Unable to refresh weather data right now."));
    });
    document.getElementById("demo-button").addEventListener("click", loadDemoDataset);
    document.getElementById("analysis-button").addEventListener("click", runAnalysis);
    document.getElementById("export-button").addEventListener("click", exportCsv);
    document.getElementById("favorite-button").addEventListener("click", favoriteCurrentLocation);
    document.getElementById("compare-add-button").addEventListener("click", () => {
      addCurrentToComparisons();
      activateView("compare");
    });
    document.querySelectorAll(".nav-button").forEach(button => button.addEventListener("click", () => activateView(button.dataset.view)));

    async function initData() {
      const handler = {
        onDataChanged(data) {
          state.savedRecords = data;
          renderSavedLists();
        }
      };
      const result = await window.dataSdk.init(handler);
      state.dataReady = result.isOk;
      if (!result.isOk) setError("Saved locations are temporarily unavailable, but live weather features remain available.");
    }

    document.addEventListener("DOMContentLoaded", async () => {
      lucide.createIcons();
      initData();
      searchLocation("Bengaluru");
    });
  