"""
WeatherSense — Weather Data Analysis and Intelligence System
BCA Final Year Capstone Academic Project
Entry Point Application File (Streamlit UI Framework)
"""
import streamlit as st

# Set Streamlit Page Config MUST be the first Streamlit command
st.set_page_config(
    page_title="WeatherSense — Weather Data Intelligence & Analytics",
    page_icon="🌤️",
    layout="wide",
    initial_sidebar_state="expanded"
)

from config.config import Config
from database.database import DatabaseManager
from api.geocoding_api import GeocodingAPI
from api.weather_api import WeatherAPI
from utils.etl_pipeline import ETLPipeline
from components.styles import apply_custom_styles
from components.header import render_header
from components.sidebar import render_sidebar

# Import Dashboard View Pages
from dashboard.dashboard import render_main_dashboard
from dashboard.live_weather import render_live_weather_page
from dashboard.forecast import render_forecast_page
from dashboard.historical import render_historical_page
from dashboard.comparison import render_comparison_page
from dashboard.prediction import render_prediction_page
from dashboard.weather_map import render_weather_map_page
from dashboard.alerts import render_alerts_page
from dashboard.reports import render_reports_page
from dashboard.settings import render_settings_page

# Inject Modern Dark UI Theme Styles
apply_custom_styles()

@st.cache_resource
def get_database_manager():
    """Cached singleton database manager instance."""
    return DatabaseManager()

@st.cache_resource
def get_api_clients():
    """Cached singleton API client instances."""
    return GeocodingAPI(), WeatherAPI()

def main():
    """Main application execution router."""
    db = get_database_manager()
    geocoding_api, weather_api = get_api_clients()
    etl_pipeline = ETLPipeline(db)

    # Sidebar Navigation Menu
    selected_page = render_sidebar(db)

    # Top Header & Location Search
    search_query, is_submitted = render_header()

    # Session State Management for Selected City
    if "selected_city" not in st.session_state:
        st.session_state["selected_city"] = "Bangalore"

    if is_submitted and search_query and search_query.strip():
        st.session_state["selected_city"] = search_query.strip()

    active_city = st.session_state["selected_city"]

    # Execute ETL Pipeline for Active City
    etl_cache_key = f"etl_data_{active_city}"
    if is_submitted or etl_cache_key not in st.session_state:
        with st.spinner(f"Executing ETL Pipeline for '{active_city}'..."):
            try:
                etl_data = etl_pipeline.run_pipeline(active_city)
                st.session_state[etl_cache_key] = etl_data
            except ValueError as ve:
                st.error(f"⚠️ {ve}")
                st.info("Tip: Try searching for a major city like 'Bangalore', 'Mumbai', 'Delhi', 'London', or 'New York'.")
                return
            except RuntimeError as re:
                st.error(f"🌐 Connection Error: {re}")
                return
            except Exception as e:
                st.error(f"An unexpected error occurred while loading weather data: {e}")
                return

    etl_data = st.session_state.get(etl_cache_key)
    if not etl_data:
        st.warning("Unable to display weather data.")
        return

    # Route to Selected Dashboard View Page
    if selected_page == "🏠 Dashboard":
        render_main_dashboard(etl_data)
    elif selected_page == "🌡 Live Weather":
        render_live_weather_page(etl_data)
    elif selected_page == "📊 Historical Analysis":
        render_historical_page(etl_data, weather_api)
    elif selected_page == "📅 Forecast":
        render_forecast_page(etl_data)
    elif selected_page == "🆚 City Comparison":
        render_comparison_page(weather_api, geocoding_api)
    elif selected_page == "🤖 Prediction":
        render_prediction_page(etl_data, weather_api)
    elif selected_page == "🗺 Weather Map":
        render_weather_map_page(etl_data, geocoding_api, weather_api)
    elif selected_page == "⚠️ Alerts & Insights":
        render_alerts_page(etl_data)
    elif selected_page == "📄 Reports":
        render_reports_page(etl_data)
    elif selected_page in ["⭐ Favorites", "⚙️ Settings"]:
        render_settings_page(db)
    else:
        render_main_dashboard(etl_data)

if __name__ == "__main__":
    main()
