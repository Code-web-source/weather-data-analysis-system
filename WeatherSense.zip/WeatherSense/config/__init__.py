"""Configuration package for WeatherSense."""
from .config import Config

__all__ = ["Config"]
