import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file if available
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

class Config:
    """Application Configuration Settings."""

    APP_NAME: str = "WeatherSense"
    APP_SUBTITLE: str = "Weather Intelligence & Data Analytics Platform"
    APP_VERSION: str = "1.0.0"

    # Directory Paths
    BASE_DIR: Path = BASE_DIR
    DATA_DIR: Path = BASE_DIR / "data"
    RAW_DATA_DIR: Path = DATA_DIR / "raw"
    PROCESSED_DATA_DIR: Path = DATA_DIR / "processed"
    MODELS_DIR: Path = BASE_DIR / "models"
    REPORTS_DIR: Path = BASE_DIR / "reports"
    ASSETS_DIR: Path = BASE_DIR / "assets"

    # Database
    DATABASE_PATH: Path = DATA_DIR / "weather.db"
    DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite:///{DATABASE_PATH}")

    # API Endpoints
    OPEN_METEO_GEOCODING_URL: str = "https://geocoding-api.open-meteo.com/v1/search"
    OPEN_METEO_WEATHER_URL: str = "https://api.open-meteo.com/v1/forecast"
    OPEN_METEO_HISTORICAL_URL: str = "https://archive-api.open-meteo.com/v1/archive"

    # Secondary API (Optional)
    OPENWEATHER_API_KEY: str = os.getenv("OPENWEATHER_API_KEY", "")
    OPENWEATHER_BASE_URL: str = "https://api.openweathermap.org/data/2.5"

    # UI Theme Palette (Modern Dark Aesthetic)
    COLOR_PRIMARY_BG: str = "#0B1220"
    COLOR_CARD_BG: str = "#111827"
    COLOR_CARD_BORDER: str = "#1F2937"
    COLOR_PRIMARY_ACCENT: str = "#38BDF8"
    COLOR_SECONDARY_ACCENT: str = "#2563EB"
    COLOR_CYAN: str = "#22D3EE"
    COLOR_TEXT_MAIN: str = "#F8FAFC"
    COLOR_TEXT_MUTED: str = "#94A3B8"
    COLOR_SUCCESS: str = "#22C55E"
    COLOR_WARNING: str = "#F59E0B"
    COLOR_DANGER: str = "#EF4444"

    # Machine Learning Settings
    MODEL_FILE: Path = MODELS_DIR / "weather_model.pkl"
    DEFAULT_RANDOM_STATE: int = 42

    @classmethod
    def ensure_directories(cls):
        """Ensure all required directories exist."""
        for directory in [
            cls.DATA_DIR,
            cls.RAW_DATA_DIR,
            cls.PROCESSED_DATA_DIR,
            cls.MODELS_DIR,
            cls.REPORTS_DIR,
            cls.ASSETS_DIR,
        ]:
            directory.mkdir(parents=True, exist_ok=True)
