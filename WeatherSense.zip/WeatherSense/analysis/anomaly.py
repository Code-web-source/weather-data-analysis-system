"""Statistical Anomaly Detection Module using Z-Score and Interquartile Range (IQR)."""
import pandas as pd
import numpy as np
from typing import List, Dict, Any

DISCLAIMER = "Note: Anomaly thresholds are project-defined analytical rules calculated from dataset distributions and do not represent official meteorological warnings."

class WeatherAnomalyDetector:
    """Detects statistical anomalies in weather metrics."""

    @staticmethod
    def detect_zscore_anomalies(df: pd.DataFrame, col: str, threshold: float = 2.5) -> pd.DataFrame:
        """
        Detect anomalies using Z-score method (Z = (X - mean) / std).
        Identifies data points where |Z| > threshold.
        """
        if df.empty or col not in df.columns:
            return pd.DataFrame()

        df_clean = df.dropna(subset=[col]).copy()
        mean_val = df_clean[col].mean()
        std_val = df_clean[col].std()

        if std_val == 0 or np.isnan(std_val):
            df_clean["z_score"] = 0.0
            df_clean["is_anomaly"] = False
            df_clean["severity"] = "NORMAL"
            return df_clean

        df_clean["z_score"] = (df_clean[col] - mean_val) / std_val
        df_clean["is_anomaly"] = df_clean["z_score"].abs() > threshold

        def categorize_z(z: float) -> str:
            abs_z = abs(z)
            if abs_z < 1.5:
                return "NORMAL"
            elif abs_z < 2.5:
                return "MODERATE"
            elif abs_z < 3.5:
                return "UNUSUAL"
            else:
                return "EXTREME"

        df_clean["severity"] = df_clean["z_score"].apply(categorize_z)
        return df_clean

    @staticmethod
    def detect_iqr_anomalies(df: pd.DataFrame, col: str, factor: float = 1.5) -> pd.DataFrame:
        """
        Detect anomalies using Interquartile Range (IQR = Q3 - Q1).
        Outliers defined as X < (Q1 - factor*IQR) or X > (Q3 + factor*IQR).
        """
        if df.empty or col not in df.columns:
            return pd.DataFrame()

        df_clean = df.dropna(subset=[col]).copy()
        q1 = df_clean[col].quantile(0.25)
        q3 = df_clean[col].quantile(0.75)
        iqr = q3 - q1

        lower_bound = q1 - (factor * iqr)
        upper_bound = q3 + (factor * iqr)

        df_clean["lower_bound"] = lower_bound
        df_clean["upper_bound"] = upper_bound
        df_clean["is_anomaly"] = (df_clean[col] < lower_bound) | (df_clean[col] > upper_bound)
        return df_clean

    @staticmethod
    def analyze_single_observation(val: float, historical_series: pd.Series, metric_name: str = "Temperature") -> Dict[str, Any]:
        """
        Compare a single real-time observation against historical distribution.
        """
        if historical_series.empty or pd.isna(val):
            return {
                "observed": val,
                "mean": 0.0,
                "deviation": 0.0,
                "status": "NORMAL",
                "disclaimer": DISCLAIMER
            }

        hist_mean = historical_series.mean()
        hist_std = historical_series.std() if len(historical_series) > 1 else 1.0
        deviation = val - hist_mean
        z_score = deviation / hist_std if hist_std > 0 else 0.0

        if abs(z_score) < 1.5:
            status = "NORMAL"
            desc = f"Normal {metric_name.lower()}"
        elif abs(z_score) < 2.5:
            status = "MODERATE"
            desc = f"Slightly {'High' if deviation > 0 else 'Low'} {metric_name.lower()}"
        elif abs(z_score) < 3.5:
            status = "UNUSUAL"
            desc = f"Unusually {'High' if deviation > 0 else 'Low'} {metric_name.lower()}"
        else:
            status = "EXTREME"
            desc = f"Extremely {'High' if deviation > 0 else 'Low'} {metric_name.lower()}"

        return {
            "metric": metric_name,
            "observed": float(val),
            "mean": float(hist_mean),
            "deviation": float(deviation),
            "z_score": float(z_score),
            "status": status,
            "description": desc,
            "disclaimer": DISCLAIMER
        }
