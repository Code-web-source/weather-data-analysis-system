"""Climate trend analysis module fitting statistical regression lines."""
import pandas as pd
import numpy as np
from typing import Dict, Any

class ClimateTrendAnalysis:
    """Analyzes annual/monthly historical trends using linear regression."""

    @staticmethod
    def analyze_temperature_trend(df: pd.DataFrame, time_col: str = "time", temp_col: str = "temperature") -> Dict[str, Any]:
        """
        Calculates trend slope, direction, and statistics.
        Returns trend summary and regression line values.
        """
        if df.empty or temp_col not in df.columns or time_col not in df.columns:
            return {
                "slope": 0.0,
                "direction": "Insufficent Data",
                "summary": "Insufficient data to compute climate trend.",
                "r_squared": 0.0,
                "fitted_values": []
            }

        df_clean = df.dropna(subset=[time_col, temp_col]).copy()
        df_clean[time_col] = pd.to_datetime(df_clean[time_col])
        df_clean = df_clean.sort_values(time_col)

        if len(df_clean) < 5:
            return {
                "slope": 0.0,
                "direction": "Insufficient Data",
                "summary": "Need at least 5 observations to compute trend.",
                "r_squared": 0.0,
                "fitted_values": df_clean[temp_col].tolist()
            }

        # Convert datetime to ordinal number of days for linear regression
        x = (df_clean[time_col] - df_clean[time_col].min()).dt.total_seconds() / (24 * 3600)
        y = df_clean[temp_col].values

        # Linear fit: y = m*x + c
        slope, intercept = np.polyfit(x, y, 1)

        # R-squared calculation
        y_pred = slope * x + intercept
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        r_squared = float(1 - (ss_res / ss_tot)) if ss_tot > 0 else 0.0

        # Slope in °C per year (approx 365.25 days)
        annual_slope = slope * 365.25

        if annual_slope > 0.15:
            direction = "Increasing"
            summary = f"Data exhibits an increasing temperature trend (+{annual_slope:.2f}°C / year)."
        elif annual_slope < -0.15:
            direction = "Decreasing"
            summary = f"Data exhibits a decreasing temperature trend ({annual_slope:.2f}°C / year)."
        else:
            direction = "Stable"
            summary = "Data shows a relatively stable temperature trend with minimal drift."

        return {
            "slope": float(annual_slope),
            "intercept": float(intercept),
            "direction": direction,
            "summary": summary,
            "r_squared": float(r_squared),
            "fitted_values": y_pred.tolist(),
            "time_series": df_clean[time_col].dt.strftime("%Y-%m-%d").tolist()
        }
