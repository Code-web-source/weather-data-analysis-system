"""Custom Weather Comfort Score, Weather Risk Indicator, Outdoor Recommendations, and Weather Change Analysis."""
import pandas as pd
from typing import Dict, Any, List, Tuple

SCORE_DISCLAIMER = "This is a project-defined analytical score calculated from selected weather parameters and is not an official meteorological measurement."
RISK_DISCLAIMER = "This is an application-generated risk assessment based on dataset thresholds and does not replace official emergency agency warnings."

class WeatherIntelligence:
    """Computes comfort scores, risk indicators, outdoor activity guidance, and change analysis."""

    @staticmethod
    def calculate_comfort_score(
        temperature: float,
        humidity: float,
        wind_speed: float,
        precipitation_prob: float = 0.0,
        uv_index: float = 0.0
    ) -> Dict[str, Any]:
        """
        Calculate Weather Comfort Score (0 to 100).
        Ideal ranges: Temp 20-25°C, Humidity 40-60%, Wind <= 15 km/h, Rain Prob 0%, UV <= 4.
        """
        if temperature is None or humidity is None:
            return {"score": 50, "category": "Moderate", "disclaimer": SCORE_DISCLAIMER}

        score = 100.0

        # Temperature Penalty (Ideal 20-25°C)
        if temperature < 15:
            score -= (15 - temperature) * 3.0
        elif temperature > 25:
            score -= (temperature - 25) * 3.5

        # Humidity Penalty (Ideal 30-60%)
        if humidity < 30:
            score -= (30 - humidity) * 0.5
        elif humidity > 60:
            score -= (humidity - 60) * 0.8

        # Wind Speed Penalty (Ideal <= 15 km/h)
        if wind_speed > 15:
            score -= (wind_speed - 15) * 1.2

        # Rain Probability Penalty
        if precipitation_prob > 0:
            score -= (precipitation_prob * 0.4)

        # UV Index Penalty
        if uv_index > 6:
            score -= (uv_index - 6) * 4.0

        final_score = max(0, min(100, int(round(score))))

        if final_score >= 80:
            category = "Optimal / Very Comfortable"
        elif final_score >= 60:
            category = "Pleasant"
        elif final_score >= 40:
            category = "Moderate"
        elif final_score >= 20:
            category = "Uncomfortable"
        else:
            category = "Very Harsh / Uncomfortable"

        return {
            "score": final_score,
            "category": category,
            "disclaimer": SCORE_DISCLAIMER
        }

    @staticmethod
    def calculate_risk_indicator(
        temperature: float,
        precipitation: float,
        wind_speed: float,
        uv_index: float,
        humidity: float
    ) -> Dict[str, Any]:
        """
        Analyze severe weather factors to determine Weather Risk Level (LOW, MODERATE, HIGH, SEVERE).
        """
        risk_score = 0
        reasons = []

        if temperature is not None:
            if temperature > 40:
                risk_score += 3
                reasons.append("Extreme High Temperature (>40°C)")
            elif temperature > 35:
                risk_score += 2
                reasons.append("High Temperature (>35°C)")
            elif temperature < 0:
                risk_score += 2
                reasons.append("Freezing Temperature (<0°C)")

        if precipitation is not None and precipitation > 10.0:
            risk_score += 3
            reasons.append("Heavy Rainfall (>10mm/h)")
        elif precipitation is not None and precipitation > 2.5:
            risk_score += 1
            reasons.append("Moderate Precipitation")

        if wind_speed is not None and wind_speed > 50:
            risk_score += 3
            reasons.append("Gale Force Wind (>50 km/h)")
        elif wind_speed is not None and wind_speed > 30:
            risk_score += 2
            reasons.append("Strong Wind (>30 km/h)")

        if uv_index is not None and uv_index >= 10:
            risk_score += 2
            reasons.append("Extreme UV Radiation Index (>=10)")

        if humidity is not None and humidity > 90 and temperature is not None and temperature > 32:
            risk_score += 2
            reasons.append("Excessive Humidity & Heat Risk")

        if risk_score >= 5:
            level = "SEVERE"
            color = "#EF4444"
        elif risk_score >= 3:
            level = "HIGH"
            color = "#F97316"
        elif risk_score >= 1:
            level = "MODERATE"
            color = "#F59E0B"
        else:
            level = "LOW"
            color = "#22C55E"
            reasons.append("No significant environmental hazards detected.")

        return {
            "level": level,
            "color": color,
            "reasons": reasons,
            "disclaimer": RISK_DISCLAIMER
        }

    @staticmethod
    def get_outdoor_recommendation(
        temperature: float,
        precipitation_prob: float,
        uv_index: float,
        humidity: float,
        wind_speed: float
    ) -> Dict[str, Any]:
        """
        Generate rule-based recommendations for outdoor activities.
        """
        factors = []
        is_favorable = True

        if precipitation_prob > 40:
            is_favorable = False
            factors.append(f"High rain probability ({int(precipitation_prob)}%)")

        if temperature > 34:
            is_favorable = False
            factors.append(f"High ambient temperature ({temperature:.1f}°C)")
        elif temperature < 5:
            is_favorable = False
            factors.append(f"Very cold weather ({temperature:.1f}°C)")

        if uv_index > 7:
            factors.append(f"High UV index ({uv_index:.1f}) - sun protection required")

        if wind_speed > 35:
            is_favorable = False
            factors.append(f"High wind speed ({wind_speed:.1f} km/h)")

        if is_favorable:
            verdict = "Outdoor activity conditions are favorable."
            if not factors:
                factors.append("Temperatures, humidity, and wind levels are within ideal comfort zones.")
        else:
            verdict = "Outdoor activity conditions may be less favorable."

        return {
            "verdict": verdict,
            "is_favorable": is_favorable,
            "factors": factors,
            "disclaimer": "Analytical recommendation based on current weather parameters."
        }

    @staticmethod
    def find_best_outdoor_window(hourly_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Analyze hourly forecast to identify the best 2-3 hour outdoor window.
        """
        if hourly_df is None or hourly_df.empty:
            return {
                "window": "N/A",
                "comfort_score": 0,
                "rain_probability": 0,
                "uv_index": 0,
                "summary": "Hourly forecast unavailable."
            }

        df = hourly_df.copy()
        if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"])

        scores = []
        for idx, row in df.iterrows():
            temp = row.get("temperature_2m", row.get("temperature", 20))
            hum = row.get("relative_humidity_2m", row.get("humidity", 50))
            wind = row.get("wind_speed_10m", row.get("wind_speed", 10))
            rain_prob = row.get("precipitation_probability", 0)
            uv = row.get("uv_index", 0)

            c_info = WeatherIntelligence.calculate_comfort_score(temp, hum, wind, rain_prob, uv)
            scores.append(c_info["score"])

        df["comfort_score"] = scores

        # Rolling 3-hour average score
        df["rolling_score"] = df["comfort_score"].rolling(window=3, min_periods=1).mean()
        best_idx = df["rolling_score"].idxmax()

        best_row = df.loc[best_idx]
        start_time = pd.to_datetime(best_row["time"])
        end_time = start_time + pd.Timedelta(hours=2)

        start_str = start_time.strftime("%I:%M %p")
        end_str = end_time.strftime("%I:%M %p")

        return {
            "window": f"{start_str} – {end_str}",
            "comfort_score": int(best_row["rolling_score"]),
            "rain_probability": int(best_row.get("precipitation_probability", 0)),
            "uv_index": float(best_row.get("uv_index", 0.0)),
            "summary": f"Optimal window for outdoor exercise, walking, or sports."
        }

    @staticmethod
    def analyze_weather_change(current: Dict[str, Any], historical_mean: Dict[str, Any]) -> Dict[str, Any]:
        """
        Compare current weather values against recent historical baseline averages.
        Returns indicators with directions and formatted deltas.
        """
        changes = {}
        metrics = [
            ("temperature", "Temperature", "°C", 0.5),
            ("humidity", "Humidity", "%", 2.0),
            ("wind_speed", "Wind Speed", "km/h", 1.0),
            ("pressure", "Pressure", "hPa", 1.0)
        ]

        for key, name, unit, threshold in metrics:
            curr_val = current.get(key)
            hist_val = historical_mean.get(key)

            if curr_val is not None and hist_val is not None:
                diff = curr_val - hist_val
                if abs(diff) < threshold:
                    direction = "neutral"
                    symbol = "→"
                elif diff > 0:
                    direction = "up"
                    symbol = "↑"
                else:
                    direction = "down"
                    symbol = "↓"

                changes[key] = {
                    "metric": name,
                    "diff": diff,
                    "formatted": f"{symbol} {abs(diff):.1f}{unit}",
                    "direction": direction,
                    "current": curr_val,
                    "historical": hist_val
                }

        return changes
