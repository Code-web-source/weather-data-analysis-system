"""Statistical analysis module for WeatherSense weather datasets."""
import pandas as pd
import numpy as np
from typing import Dict, Any, List

class WeatherStatistics:
    """Calculates descriptive statistics, aggregations, and correlations."""

    @staticmethod
    def calculate_summary_stats(df: pd.DataFrame, col: str) -> Dict[str, float]:
        """
        Calculate Mean, Median, Min, Max, Standard Deviation, Range, and Percentiles (25th, 75th).
        """
        if df.empty or col not in df.columns or df[col].dropna().empty:
            return {
                "mean": 0.0, "median": 0.0, "min": 0.0, "max": 0.0,
                "std": 0.0, "range": 0.0, "p25": 0.0, "p75": 0.0, "count": 0
            }

        series = df[col].dropna()
        p25 = float(np.percentile(series, 25))
        p75 = float(np.percentile(series, 75))

        return {
            "mean": float(series.mean()),
            "median": float(series.median()),
            "min": float(series.min()),
            "max": float(series.max()),
            "std": float(series.std()) if len(series) > 1 else 0.0,
            "range": float(series.max() - series.min()),
            "p25": p25,
            "p75": p75,
            "count": int(len(series))
        }

    @staticmethod
    def compute_correlation_matrix(df: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
        """
        Compute Pearson correlation matrix across selected numeric weather attributes.
        """
        valid_cols = [c for c in columns if c in df.columns and pd.api.types.is_numeric_dtype(df[c])]
        if not valid_cols or len(df) < 2:
            return pd.DataFrame()
        return df[valid_cols].corr(method="pearson")

    @staticmethod
    def get_monthly_averages(df: pd.DataFrame, time_col: str = "time") -> pd.DataFrame:
        """Group and calculate monthly average weather metrics."""
        if df.empty or time_col not in df.columns:
            return pd.DataFrame()

        df_copy = df.copy()
        df_copy[time_col] = pd.to_datetime(df_copy[time_col])
        df_copy["month"] = df_copy[time_col].dt.strftime("%Y-%m")

        numeric_cols = df_copy.select_dtypes(include=[np.number]).columns.tolist()
        if "weather_code" in numeric_cols:
            numeric_cols.remove("weather_code")

        monthly = df_copy.groupby("month")[numeric_cols].mean().reset_index()
        return monthly
