"""Multi-city comparative analysis module."""
import pandas as pd
from typing import List, Dict, Any

class CityComparison:
    """Compares current & forecast weather metrics across multiple locations."""

    @staticmethod
    def compare_current_weather(cities_data: List[Dict[str, Any]]) -> pd.DataFrame:
        """
        Build comparative DataFrame for multiple cities.
        Each item in cities_data: {"city": str, "country": str, "current": dict}
        """
        rows = []
        for item in cities_data:
            city_name = item.get("city", "Unknown")
            curr = item.get("current", {})
            rows.append({
                "City": city_name,
                "Country": item.get("country", ""),
                "Temperature (°C)": curr.get("temperature"),
                "Feels Like (°C)": curr.get("feels_like"),
                "Humidity (%)": curr.get("humidity"),
                "Wind Speed (km/h)": curr.get("wind_speed"),
                "Pressure (hPa)": curr.get("pressure"),
                "UV Index": curr.get("uv_index"),
                "Visibility (km)": curr.get("visibility"),
                "Precipitation (mm)": curr.get("precipitation"),
                "Condition": curr.get("weather_desc")
            })

        df = pd.DataFrame(rows)
        return df

    @staticmethod
    def generate_analytical_contrast(df: pd.DataFrame) -> List[str]:
        """
        Generate factual analytical differences without subjective value judgments.
        """
        if df.empty or len(df) < 2:
            return ["Add at least two cities to view comparative analysis."]

        insights = []
        # Find warmest and coolest
        warmest_row = df.loc[df["Temperature (°C)"].idxmax()]
        coolest_row = df.loc[df["Temperature (°C)"].idxmin()]

        temp_diff = warmest_row["Temperature (°C)"] - coolest_row["Temperature (°C)"]
        insights.append(
            f"**Temperature Contrast**: {warmest_row['City']} is the warmest at {warmest_row['Temperature (°C)']}°C, "
            f"which is {temp_diff:.1f}°C higher than {coolest_row['City']} ({coolest_row['Temperature (°C)']}°C)."
        )

        # Find most humid
        humid_row = df.loc[df["Humidity (%)"].idxmax()]
        dry_row = df.loc[df["Humidity (%)"].idxmin()]
        humid_diff = humid_row["Humidity (%)"] - dry_row["Humidity (%)"]
        insights.append(
            f"**Humidity Variation**: {humid_row['City']} has the highest relative humidity at {int(humid_row['Humidity (%)'])}%, "
            f"compared to {dry_row['City']} at {int(dry_row['Humidity (%)'])}% ({int(humid_diff)}% variation)."
        )

        # Wind speed comparison
        windiest_row = df.loc[df["Wind Speed (km/h)"].idxmax()]
        insights.append(
            f"**Wind Activity**: {windiest_row['City']} records the highest wind speed at {windiest_row['Wind Speed (km/h)']} km/h."
        )

        return insights
