"""Formatting utilities for display values."""
from datetime import datetime
from typing import Union

def format_temp(val: Union[float, int, None], unit: str = "°C") -> str:
    """Format temperature value."""
    if val is None:
        return "N/A"
    return f"{val:.1f}{unit}"

def format_wind(val: Union[float, int, None], unit: str = "km/h") -> str:
    """Format wind speed value."""
    if val is None:
        return "N/A"
    return f"{val:.1f} {unit}"

def format_humidity(val: Union[float, int, None]) -> str:
    """Format humidity percentage."""
    if val is None:
        return "N/A"
    return f"{int(val)}%"

def format_pressure(val: Union[float, int, None]) -> str:
    """Format atmospheric pressure."""
    if val is None:
        return "N/A"
    return f"{val:.0f} hPa"

def format_uv(val: Union[float, int, None]) -> str:
    """Format UV Index with category label."""
    if val is None:
        return "N/A"
    category = "Low"
    if val >= 11:
        category = "Extreme"
    elif val >= 8:
        category = "Very High"
    elif val >= 6:
        category = "High"
    elif val >= 3:
        category = "Moderate"
    return f"{val:.1f} ({category})"

def format_timestamp(ts: Union[str, datetime, None]) -> str:
    """Format timestamp string into readable datetime."""
    if not ts:
        return "N/A"
    if isinstance(ts, str):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            return dt.strftime("%b %d, %Y %I:%M %p")
        except ValueError:
            return ts
    return ts.strftime("%b %d, %Y %I:%M %p")
