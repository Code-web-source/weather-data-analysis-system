"""ETL Pipeline module: Extract, Transform, Load weather data."""
import pandas as pd
from typing import Dict, Any, Tuple
from api.geocoding_api import GeocodingAPI
from api.weather_api import WeatherAPI
from database.database import DatabaseManager
from utils.helpers import get_logger

logger = get_logger("etl_pipeline")

class ETLPipeline:
    """Orchestrates Extract, Transform, and Load operations for weather analytics."""

    def __init__(self, db_manager: DatabaseManager):
        self.geocoding_api = GeocodingAPI()
        self.weather_api = WeatherAPI()
        self.db = db_manager

    def extract(self, city_name: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        EXTRACT: Fetch raw location geocoding and weather payload from external APIs.
        """
        logger.info(f"ETL Extract stage: Fetching geocoding for '{city_name}'")
        locations = self.geocoding_api.search_location(city_name, count=1)
        if not locations:
            raise ValueError(f"Location '{city_name}' not found.")

        location = locations[0]
        lat, lon = location["latitude"], location["longitude"]

        logger.info(f"ETL Extract stage: Fetching weather payload for lat={lat}, lon={lon}")
        weather_payload = self.weather_api.get_full_weather_data(lat, lon)

        return location, weather_payload

    def transform(self, location: Dict[str, Any], raw_payload: Dict[str, Any]) -> Tuple[Dict[str, Any], pd.DataFrame]:
        """
        TRANSFORM: Clean data, convert timestamps, fill missing values, format numeric types.
        """
        logger.info("ETL Transform stage: Cleaning and transforming raw payload.")
        current = raw_payload.get("current", {})
        hourly_df = raw_payload.get("hourly", pd.DataFrame())

        # Clean current metrics
        clean_current = {
            "temperature": float(current.get("temperature", 0.0)),
            "feels_like": float(current.get("feels_like", 0.0)),
            "humidity": float(current.get("humidity", 0.0)),
            "pressure": float(current.get("pressure", 1013.25)),
            "wind_speed": float(current.get("wind_speed", 0.0)),
            "wind_direction": float(current.get("wind_direction", 0.0)),
            "precipitation": float(current.get("precipitation", 0.0)),
            "rain": float(current.get("rain", 0.0)),
            "snowfall": float(current.get("snowfall", 0.0)),
            "cloud_cover": float(current.get("cloud_cover", 0.0)),
            "visibility": float(current.get("visibility", 10.0)),
            "uv_index": float(current.get("uv_index", 0.0)),
            "weather_code": int(current.get("weather_code", 0)),
            "weather_desc": current.get("weather_desc", "Clear"),
            "weather_icon": current.get("weather_icon", "☀️"),
            "sunrise": current.get("sunrise"),
            "sunset": current.get("sunset"),
            "is_day": current.get("is_day", 1)
        }

        # Transform hourly dataframe if present
        clean_hourly = pd.DataFrame()
        if not hourly_df.empty:
            clean_hourly = hourly_df.copy()
            # Rename columns to standardized schema
            rename_map = {
                "temperature_2m": "temperature",
                "relative_humidity_2m": "humidity",
                "apparent_temperature": "feels_like",
                "surface_pressure": "pressure",
                "wind_speed_10m": "wind_speed",
                "wind_direction_10m": "wind_direction",
                "precipitation_probability": "precipitation_probability"
            }
            clean_hourly.rename(columns=rename_map, inplace=True)

            # Ensure datetime type
            if "time" in clean_hourly.columns:
                clean_hourly["time"] = pd.to_datetime(clean_hourly["time"])

            # Fill missing values
            numeric_cols = clean_hourly.select_dtypes(include=["float64", "int64"]).columns
            clean_hourly[numeric_cols] = clean_hourly[numeric_cols].ffill().bfill()

        return clean_current, clean_hourly

    def load(self, location: Dict[str, Any], current: Dict[str, Any], hourly_df: pd.DataFrame) -> int:
        """
        LOAD: Persist clean data into SQLite database tables.
        """
        logger.info("ETL Load stage: Storing records into SQLite database.")
        city = location["city"]
        country = location.get("country", "")
        lat = location["latitude"]
        lon = location["longitude"]
        tz = location.get("timezone", "UTC")

        # Save location entity
        location_id = self.db.save_location(city, country, lat, lon, tz)

        # Save search history
        self.db.add_search_history(f"{city}, {country}".strip(", "))

        # Prepare single observation row for weather_data persistence
        now_df = pd.DataFrame([{
            "time": pd.Timestamp.now(),
            "temperature": current["temperature"],
            "feels_like": current["feels_like"],
            "humidity": current["humidity"],
            "pressure": current["pressure"],
            "precipitation": current["precipitation"],
            "rain": current["rain"],
            "wind_speed": current["wind_speed"],
            "wind_direction": current["wind_direction"],
            "cloud_cover": current["cloud_cover"],
            "visibility": current["visibility"],
            "uv_index": current["uv_index"],
            "weather_code": current["weather_code"]
        }])

        self.db.save_weather_data(location_id, now_df)
        return location_id

    def run_pipeline(self, city_name: str) -> Dict[str, Any]:
        """Execute full Extract -> Transform -> Load pipeline for a requested city."""
        location, raw_payload = self.extract(city_name)
        clean_current, clean_hourly = self.transform(location, raw_payload)
        location_id = self.load(location, clean_current, clean_hourly)

        return {
            "location_id": location_id,
            "location": location,
            "current": clean_current,
            "hourly": clean_hourly,
            "daily": raw_payload.get("daily", pd.DataFrame()),
            "timezone": raw_payload.get("timezone", "UTC")
        }
