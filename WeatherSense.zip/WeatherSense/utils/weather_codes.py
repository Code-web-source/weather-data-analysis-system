"""WMO Weather Code mappings and interpretation helpers."""

WMO_WEATHER_CODES = {
    0: {"description": "Clear Sky", "icon": "☀️", "category": "Clear"},
    1: {"description": "Mainly Clear", "icon": "🌤️", "category": "Clear"},
    2: {"description": "Partly Cloudy", "icon": "⛅", "category": "Cloudy"},
    3: {"description": "Overcast", "icon": "☁️", "category": "Cloudy"},
    45: {"description": "Fog", "icon": "🌫️", "category": "Fog"},
    48: {"description": "Depositing Rime Fog", "icon": "🌫️", "category": "Fog"},
    51: {"description": "Light Drizzle", "icon": "🌦️", "category": "Drizzle"},
    53: {"description": "Moderate Drizzle", "icon": "🌦️", "category": "Drizzle"},
    55: {"description": "Dense Drizzle", "icon": "🌧️", "category": "Drizzle"},
    56: {"description": "Light Freezing Drizzle", "icon": "🌧️", "category": "Drizzle"},
    57: {"description": "Dense Freezing Drizzle", "icon": "🌧️", "category": "Drizzle"},
    61: {"description": "Slight Rain", "icon": "🌧️", "category": "Rain"},
    63: {"description": "Moderate Rain", "icon": "🌧️", "category": "Rain"},
    65: {"description": "Heavy Rain", "icon": "🌧️", "category": "Rain"},
    66: {"description": "Light Freezing Rain", "icon": "🌧️", "category": "Rain"},
    67: {"description": "Heavy Freezing Rain", "icon": "🌧️", "category": "Rain"},
    71: {"description": "Slight Snow Fall", "icon": "🌨️", "category": "Snow"},
    73: {"description": "Moderate Snow Fall", "icon": "🌨️", "category": "Snow"},
    75: {"description": "Heavy Snow Fall", "icon": "❄️", "category": "Snow"},
    77: {"description": "Snow Grains", "icon": "❄️", "category": "Snow"},
    80: {"description": "Slight Rain Showers", "icon": "🌦️", "category": "Rain"},
    81: {"description": "Moderate Rain Showers", "icon": "🌧️", "category": "Rain"},
    82: {"description": "Violent Rain Showers", "icon": "⛈️", "category": "Rain"},
    85: {"description": "Slight Snow Showers", "icon": "🌨️", "category": "Snow"},
    86: {"description": "Heavy Snow Showers", "icon": "❄️", "category": "Snow"},
    95: {"description": "Thunderstorm", "icon": "⛈️", "category": "Thunderstorm"},
    96: {"description": "Thunderstorm with Slight Hail", "icon": "⛈️", "category": "Thunderstorm"},
    99: {"description": "Thunderstorm with Heavy Hail", "icon": "⛈️", "category": "Thunderstorm"},
}

def get_weather_info(code: int) -> dict:
    """Retrieve full info for a WMO weather code."""
    return WMO_WEATHER_CODES.get(code, {"description": "Unknown", "icon": "🌡️", "category": "Unknown"})

def get_weather_description(code: int) -> str:
    """Get textual description for WMO weather code."""
    return get_weather_info(code)["description"]

def get_weather_icon(code: int) -> str:
    """Get emoji/icon for WMO weather code."""
    return get_weather_info(code)["icon"]
