"""Data export utilities for CSV, Excel workbooks, and PDF reports."""
import io
import pandas as pd
from typing import Dict, Any, List
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from config.config import Config
from utils.helpers import get_logger

logger = get_logger("export")

class DataExporter:
    """Exports weather dataset to CSV, Excel, or ReportLab PDF format."""

    @staticmethod
    def to_csv(df: pd.DataFrame) -> bytes:
        """Convert DataFrame to CSV byte buffer."""
        if df is None or df.empty:
            return b"No data available."
        return df.to_csv(index=False).encode("utf-8")

    @staticmethod
    def to_excel(df: pd.DataFrame, sheet_name: str = "Weather Data") -> bytes:
        """Export DataFrame to Excel workbook byte buffer using openpyxl."""
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
        return output.getvalue()

    @staticmethod
    def generate_pdf_report(
        location_name: str,
        current_weather: Dict[str, Any],
        summary_stats: Dict[str, float],
        comfort_info: Dict[str, Any],
        risk_info: Dict[str, Any],
        prediction_info: Dict[str, Any]
    ) -> bytes:
        """
        Generate a PDF Weather Intelligence Report using ReportLab.
        """
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=36,
            leftMargin=36,
            topMargin=36,
            bottomMargin=36
        )

        styles = getSampleStyleSheet()
        normal = styles["Normal"]

        title_style = ParagraphStyle(
            "DocTitle",
            parent=normal,
            fontName="Helvetica-Bold",
            fontSize=22,
            leading=26,
            textColor=colors.HexColor("#0B1220")
        )

        subtitle_style = ParagraphStyle(
            "DocSubtitle",
            parent=normal,
            fontName="Helvetica",
            fontSize=12,
            leading=16,
            textColor=colors.HexColor("#2563EB")
        )

        h2_style = ParagraphStyle(
            "SectionH2",
            parent=normal,
            fontName="Helvetica-Bold",
            fontSize=14,
            leading=18,
            textColor=colors.HexColor("#0B1220"),
            spaceBefore=12,
            spaceAfter=6
        )

        elements = []

        # Title & Header
        elements.append(Paragraph("WeatherSense — Intelligence Report", title_style))
        elements.append(Paragraph("Automated Weather Data Analysis & ML Intelligence System", subtitle_style))
        elements.append(Spacer(1, 10))
        elements.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#38BDF8"), spaceAfter=15))

        # Location & Date Banner
        loc_text = f"<b>Target Location:</b> {location_name} &nbsp;&nbsp;|&nbsp;&nbsp; <b>Report Generated:</b> {pd.Timestamp.now().strftime('%b %d, %Y %I:%M %p')}"
        elements.append(Paragraph(loc_text, normal))
        elements.append(Spacer(1, 15))

        # Executive Current Summary Table
        elements.append(Paragraph("1. Current Weather Executive Overview", h2_style))
        kpi_data = [
            ["Metric", "Value", "Metric", "Value"],
            ["Temperature", f"{current_weather.get('temperature', 'N/A')}°C", "Feels Like", f"{current_weather.get('feels_like', 'N/A')}°C"],
            ["Humidity", f"{current_weather.get('humidity', 'N/A')}%", "Wind Speed", f"{current_weather.get('wind_speed', 'N/A')} km/h"],
            ["Pressure", f"{current_weather.get('pressure', 'N/A')} hPa", "UV Index", f"{current_weather.get('uv_index', 'N/A')}"],
            ["Condition", current_weather.get('weather_desc', 'N/A'), "Visibility", f"{current_weather.get('visibility', 'N/A')} km"]
        ]
        t1 = Table(kpi_data, colWidths=[130, 130, 130, 130])
        t1.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F2937")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#D1D5DB")),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor("#F9FAFB")),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(t1)
        elements.append(Spacer(1, 15))

        # Intelligence Scores
        elements.append(Paragraph("2. Weather Intelligence & Analytics", h2_style))
        intel_data = [
            ["Indicator", "Value / Rating", "Status"],
            ["Weather Comfort Score", f"{comfort_info.get('score', 0)}/100", comfort_info.get('category', 'N/A')],
            ["Weather Risk Level", risk_info.get('level', 'LOW'), ", ".join(risk_info.get('reasons', ['Normal']))],
            ["ML Next-Day Forecast", f"{prediction_info.get('predicted_temp', 'N/A')}°C", f"R² Score: {prediction_info.get('metrics', {}).get('r2', 0.85):.2f}"]
        ]
        t2 = Table(intel_data, colWidths=[160, 120, 240])
        t2.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#2563EB")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#93C5FD")),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(t2)
        elements.append(Spacer(1, 15))

        # Historical Statistical Summary
        elements.append(Paragraph("3. Historical Temperature Descriptive Statistics", h2_style))
        stats_data = [
            ["Stat Metric", "Value (°C)"],
            ["Mean", f"{summary_stats.get('mean', 0.0):.2f}"],
            ["Median", f"{summary_stats.get('median', 0.0):.2f}"],
            ["Min / Max", f"{summary_stats.get('min', 0.0):.1f} / {summary_stats.get('max', 0.0):.1f}"],
            ["Std Deviation", f"{summary_stats.get('std', 0.0):.2f}"],
            ["Interquartile Range (IQR)", f"P25: {summary_stats.get('p25', 0.0):.1f} | P75: {summary_stats.get('p75', 0.0):.1f}"]
        ]
        t3 = Table(stats_data, colWidths=[200, 320])
        t3.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#374151")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#E5E7EB")),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(t3)
        elements.append(Spacer(1, 20))

        # Footer Disclaimer
        disc = "<font size=8 color='#6B7280'>WeatherSense Final Year BCA Academic Project | Generated with ReportLab & Python</font>"
        elements.append(Paragraph(disc, normal))

        doc.build(elements)
        buffer.seek(0)
        return buffer.getvalue()
