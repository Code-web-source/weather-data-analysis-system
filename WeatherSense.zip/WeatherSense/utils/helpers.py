"""General helper functions for data manipulation, file generation, and system operations."""
import logging
from typing import Dict, Any

# Configure logging for application debugging & auditing
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("WeatherSense")

def get_logger(name: str):
    """Retrieve logger instance for a given module."""
    return logging.getLogger(f"WeatherSense.{name}")

def degrees_to_cardinal(d: float) -> str:
    """Convert wind direction in degrees (0-360) to compass direction."""
    if d is None:
        return "N/A"
    dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
            "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
    ix = int((d + 11.25) / 22.5)
    return dirs[ix % 16]
