"""Validation utility functions for locations, dates, and API inputs."""
from datetime import date, datetime
from typing import Tuple, Optional

def validate_location(city_name: str) -> Tuple[bool, Optional[str]]:
    """Validate city name string input."""
    if not city_name or not city_name.strip():
        return False, "City name cannot be empty."
    clean_name = city_name.strip()
    if len(clean_name) < 2:
        return False, "City name must be at least 2 characters long."
    return True, None

def validate_date_range(start_date: date, end_date: date) -> Tuple[bool, Optional[str]]:
    """Validate historical analysis date range."""
    today = date.today()
    if start_date > end_date:
        return False, "Start date cannot be after end date."
    if end_date > today:
        return False, "End date cannot be in the future for historical analysis."
    if (end_date - start_date).days < 1:
        return False, "Date range must be at least 1 day."
    if (end_date - start_date).days > 365 * 5:
        return False, "Historical queries are limited to 5 years maximum."
    return True, None

def validate_coordinates(lat: float, lon: float) -> bool:
    """Validate latitude and longitude ranges."""
    return -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0
