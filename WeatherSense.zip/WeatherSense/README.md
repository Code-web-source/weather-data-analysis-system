# WeatherSense — Weather Data Analysis and Intelligence System Using Python
**A Production-Grade Final-Year BCA Capstone Academic Project**

[![Python 3.11+](https://img.shields.io/badge/Python-3.11%2B-blue.svg)](https://www.python.org/)
[![Streamlit Framework](https://img.shields.io/badge/Streamlit-1.28%2B-red.svg)](https://streamlit.io/)
[![Database SQLite](https://img.shields.io/badge/Database-SQLite%20%2F%20SQLAlchemy-green.svg)](https://www.sqlite.org/)
[![ML Scikit-Learn](https://img.shields.io/badge/ML-Scikit--Learn-orange.svg)](https://scikit-learn.org/)
[![License Academic](https://img.shields.io/badge/License-Academic%20Final%20Year-purple.svg)]()

---

## 📌 1. PROJECT OVERVIEW
**WeatherSense** is a comprehensive Python-based Weather Data Analysis and Intelligence System engineered as a final-year BCA academic project. Unlike simple weather display applications, WeatherSense functions as a modular, enterprise-grade data intelligence platform. It collects real-time, forecast, and multi-year historical weather data, processes it via an Extract-Transform-Load (ETL) pipeline, persists observations in an SQLite database using SQLAlchemy ORM, performs statistical and anomaly analysis, computes proprietary comfort and risk indices, trains a Scikit-Learn Random Forest Regressor for next-day temperature forecasting, and presents insights through a modern dark-themed interactive Streamlit dashboard.

---

## ✨ 2. KEY FEATURES & SIGNATURE INTELLIGENCE
- **🎯 Real-Time & Forecast Center**: Live meteorological variables (Temperature, Feels-Like, Humidity, Pressure, Wind, Visibility, UV, Sunrise/Sunset) + 24-hour interactive hourly forecast & 7-day outlook.
- **📊 Historical Weather & Climate Analytics**: Custom date range filtering, descriptive statistics (Mean, Median, Min, Max, Std Dev, Range, Percentiles P25/P75), linear climate trend fitting, and Pearson correlation heatmaps.
- **⚠️ Statistical Anomaly Detection**: Automated outlier identification using Z-score ($|Z| > 2.0$) and Interquartile Range ($1.5 \times \text{IQR}$) algorithms.
- **🧠 Weather Intelligence Suite**:
  - **Weather Comfort Score (0–100)**: Multi-parameter comfort index.
  - **Weather Risk Indicator**: LOW, MODERATE, HIGH, SEVERE hazard assessment.
  - **Outdoor Activity Guidance**: Rule-based recommendation engine.
  - **Best Outdoor Time Window**: 3-hour rolling average window finder.
- **🆚 Multi-City Side-by-Side Comparison**: Contrast meteorological variables across global cities with grouped Plotly bar charts and factual analytical text.
- **🤖 Machine Learning Forecasting**: `RandomForestRegressor` model predicting next-day temperature with evaluation metrics (MAE, RMSE, $R^2$) and feature importance bar charts.
- **🗺️ Interactive Dark Weather Map**: Geographical visualization powered by Folium with interactive city markers and weather popups.
- **📄 Multi-Format Data Export**: Export CSV datasets, Excel workbooks (`openpyxl`), and generate ReportLab PDF summary reports.
- **⭐ Search Log & Favorites**: Persistent search history audit trail and user favorite locations stored in SQLite.

---

## 🛠️ 3. TECHNOLOGY STACK

| Category | Technology / Library |
| :--- | :--- |
| **Language** | Python 3.11+ |
| **Dashboard / UI** | Streamlit 1.28+, Custom CSS |
| **Data Processing** | Pandas 2.0+, NumPy 1.24+ |
| **Data Visualization** | Plotly 5.17+ |
| **Database & ORM** | SQLite, SQLAlchemy 2.0+ |
| **APIs** | Open-Meteo REST APIs (Geocoding, Forecast, Archive) |
| **Machine Learning** | Scikit-learn 1.3+ (`RandomForestRegressor`), Joblib |
| **Geographic Mapping** | Folium 0.14+, `streamlit-folium` |
| **Report Generation** | ReportLab 4.0+, OpenPyXL 3.1+ |
| **Testing Framework** | pytest 7.4+ |

---

## 📁 4. PROJECT ARCHITECTURE & DIRECTORY STRUCTURE

```
WeatherSense/
│
├── app.py                      # Main Streamlit application router & entry point
├── requirements.txt            # Project Python dependencies
├── README.md                   # Comprehensive project documentation
├── .env.example                # Environment variables template
├── .gitignore                  # Git ignore rules
│
├── config/                     # Configuration management
│   ├── __init__.py
│   └── config.py               # Paths, API endpoints, UI theme tokens
│
├── api/                        # REST API clients
│   ├── __init__.py
│   ├── weather_api.py          # Open-Meteo weather endpoint wrapper
│   └── geocoding_api.py        # Location search geocoding API
│
├── database/                   # SQLite persistence layer
│   ├── __init__.py
│   ├── database.py             # Connection manager & CRUD operations
│   └── models.py               # SQLAlchemy ORM table schema definitions
│
├── analysis/                   # Analytics engine
│   ├── __init__.py
│   ├── statistics.py           # Descriptive stats & correlation
│   ├── trends.py               # Linear regression climate trends
│   ├── anomaly.py              # Z-score & IQR outlier detection
│   ├── comparison.py           # Multi-city contrast logic
│   └── weather_score.py        # Comfort score, risk indicator, outdoor rules
│
├── ml/                         # Machine learning forecasting module
│   ├── __init__.py
│   ├── preprocessing.py        # Time-series feature engineering (lags, rolling)
│   ├── train_model.py          # RandomForestRegressor training pipeline
│   ├── prediction.py           # Inference predictor engine
│   └── model_evaluation.py     # MAE, RMSE, R2 & feature importances
│
├── dashboard/                  # UI view pages
│   ├── __init__.py
│   ├── dashboard.py            # Main executive overview page
│   ├── live_weather.py         # Detailed live observations
│   ├── historical.py           # Historical trends & statistics
│   ├── forecast.py             # 24h & 7-day interactive forecast
│   ├── comparison.py           # Multi-city side-by-side comparison
│   ├── prediction.py           # ML temperature prediction dashboard
│   ├── weather_map.py          # Interactive Folium map view
│   ├── alerts.py               # Anomaly & intelligence engine
│   ├── reports.py              # CSV, Excel, & PDF report exports
│   └── settings.py             # Favorites & search history manager
│
├── components/                 # Reusable UI widgets & themes
│   ├── __init__.py
│   ├── styles.py               # Centralized CSS stylesheet injector
│   ├── header.py               # App title & search bar
│   ├── sidebar.py              # Navigation menu widget
│   ├── cards.py                # KPI metric & summary cards
│   └── charts.py               # Plotly figure builders
│
├── utils/                      # Helper utilities
│   ├── __init__.py
│   ├── helpers.py              # General helper functions & logging
│   ├── etl_pipeline.py         # Extract-Transform-Load pipeline
│   ├── export.py               # CSV, Excel, & ReportLab PDF generators
│   ├── weather_codes.py        # WMO weather code mapping & icons
│   ├── validators.py           # Input & date range validation
│   └── formatting.py           # Value formatting helpers
│
├── data/                       # Data storage directory
│   ├── raw/
│   ├── processed/
│   └── weather.db              # SQLite relational database file
│
├── models/                     # Trained ML model weights
│   └── weather_model.pkl
│
├── docs/                       # Project documentation & viva guide
│   ├── project_documentation.md # Detailed 23-section academic report
│   └── viva_questions.md        # 50 BCA viva Q&A guide
│
└── tests/                      # Automated pytest test suite
    ├── test_api.py             # API response structure tests
    ├── test_analysis.py        # Statistics & anomaly tests
    ├── test_database.py        # SQLite CRUD & schema tests
    └── test_prediction.py      # ML feature engineering & training tests
```

---

## ⚡ 5. INSTALLATION & SETUP GUIDE

### Prerequisites
- Python 3.11 or higher installed on Windows/macOS/Linux.

### Step 1: Clone or Navigate to Directory
```bash
cd WeatherSense
```

### Step 2: Create a Virtual Environment (Optional but Recommended)
```bash
python -m venv venv
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

---

## 🚀 6. HOW TO RUN THE APPLICATION

Launch the Streamlit web dashboard:
```bash
streamlit run app.py
```

The application will open automatically in your browser at `http://localhost:8501`.

---

## 🧪 7. RUNNING AUTOMATED UNIT TESTS

To verify backend logic, database schema, API integration, and machine learning pipelines:
```bash
python -m pytest tests/
```

Expected Output:
```text
13 passed in 19.47s
```

---

## 📄 8. DOCUMENTATION & VIVA PREPARATION
- **Full Project Documentation**: See `docs/project_documentation.md` for complete system requirements, architecture diagrams, data flow diagrams, ETL descriptions, and statistical methodologies.
- **BCA Viva Preparation Guide**: See `docs/viva_questions.md` for 50 detailed questions and answers covering Python, Pandas, NumPy, APIs, SQLite, ETL, Statistics, Machine Learning, and Streamlit.

---

## 🎓 9. AUTHOR & ACKNOWLEDGMENTS
- **Author**: BCA Final Year Student
- **Project Title**: WeatherSense — Weather Data Analysis and Intelligence System Using Python
- **Primary API Provider**: Open-Meteo (https://open-meteo.com/)
