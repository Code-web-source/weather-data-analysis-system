"""Database connection and session manager for WeatherSense using SQLAlchemy."""
import pandas as pd
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy import create_engine, func
from sqlalchemy.orm import sessionmaker, Session
from config.config import Config
from database.models import Base, Location, WeatherData, ForecastData, SearchHistory, Favorite
from utils.helpers import get_logger

logger = get_logger("database")

class DatabaseManager:
    """Manages SQLite database creation, sessions, and CRUD operations."""

    def __init__(self, db_url: Optional[str] = None):
        Config.ensure_directories()
        self.db_url = db_url or Config.DATABASE_URL
        self.engine = create_engine(self.db_url, connect_args={"check_same_thread": False})
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        self.init_db()

    def init_db(self):
        """Create database tables if they do not exist."""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("Database schema initialized successfully.")
        except Exception as e:
            logger.error(f"Error initializing database schema: {e}")

    def get_session(self) -> Session:
        """Provide a database session context."""
        return self.SessionLocal()

    # --- Search History Operations ---
    def add_search_history(self, location_name: str):
        """Record a location query in search history."""
        session = self.get_session()
        try:
            entry = SearchHistory(location=location_name, searched_at=datetime.utcnow())
            session.add(entry)
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Error adding search history: {e}")
        finally:
            session.close()

    def get_search_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve recent search history entries with visit counts."""
        session = self.get_session()
        try:
            # Query location, latest searched_at, and count of searches
            results = (
                session.query(
                    SearchHistory.location,
                    func.max(SearchHistory.searched_at).label("last_searched"),
                    func.count(SearchHistory.id).label("visit_count")
                )
                .group_by(SearchHistory.location)
                .order_by(func.max(SearchHistory.searched_at).desc())
                .limit(limit)
                .all()
            )
            return [
                {
                    "location": row.location,
                    "searched_at": row.last_searched,
                    "visit_count": row.visit_count
                }
                for row in results
            ]
        finally:
            session.close()

    def clear_search_history(self):
        """Clear all search history records."""
        session = self.get_session()
        try:
            session.query(SearchHistory).delete()
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Error clearing search history: {e}")
        finally:
            session.close()

    # --- Favorites Operations ---
    def add_favorite(self, location_name: str) -> bool:
        """Add location to favorites list."""
        session = self.get_session()
        try:
            existing = session.query(Favorite).filter(Favorite.location == location_name).first()
            if not existing:
                fav = Favorite(location=location_name, added_at=datetime.utcnow())
                session.add(fav)
                session.commit()
            return True
        except Exception as e:
            session.rollback()
            logger.error(f"Error adding favorite: {e}")
            return False
        finally:
            session.close()

    def remove_favorite(self, location_name: str) -> bool:
        """Remove location from favorites list."""
        session = self.get_session()
        try:
            session.query(Favorite).filter(Favorite.location == location_name).delete()
            session.commit()
            return True
        except Exception as e:
            session.rollback()
            logger.error(f"Error removing favorite: {e}")
            return False
        finally:
            session.close()

    def get_favorites(self) -> List[str]:
        """Retrieve list of favorite location names."""
        session = self.get_session()
        try:
            favs = session.query(Favorite.location).order_by(Favorite.added_at.desc()).all()
            return [f.location for f in favs]
        finally:
            session.close()

    def is_favorite(self, location_name: str) -> bool:
        """Check if a location is currently favorited."""
        session = self.get_session()
        try:
            count = session.query(Favorite).filter(Favorite.location == location_name).count()
            return count > 0
        finally:
            session.close()

    # --- Location & Weather Records Persistence (ETL Load) ---
    def save_location(self, city: str, country: str, lat: float, lon: float, tz: str = "UTC") -> int:
        """Save or retrieve a location entity, returning its ID."""
        session = self.get_session()
        try:
            loc = session.query(Location).filter(
                Location.city == city,
                Location.latitude == lat,
                Location.longitude == lon
            ).first()

            if not loc:
                loc = Location(
                    city=city,
                    country=country,
                    latitude=lat,
                    longitude=lon,
                    timezone=tz
                )
                session.add(loc)
                session.commit()
                session.refresh(loc)
            return loc.id
        except Exception as e:
            session.rollback()
            logger.error(f"Error saving location: {e}")
            raise
        finally:
            session.close()

    def save_weather_data(self, location_id: int, df: pd.DataFrame):
        """Save cleaned weather observations DataFrame into database (ETL Load stage)."""
        if df is None or df.empty:
            return
        session = self.get_session()
        try:
            records = []
            for _, row in df.iterrows():
                ts = row["time"] if isinstance(row["time"], datetime) else pd.to_datetime(row["time"]).to_pydatetime()
                # Check for existing record to avoid duplicate timestamp entry
                existing = session.query(WeatherData).filter(
                    WeatherData.location_id == location_id,
                    WeatherData.timestamp == ts
                ).first()

                if not existing:
                    rec = WeatherData(
                        location_id=location_id,
                        timestamp=ts,
                        temperature=row.get("temperature"),
                        feels_like=row.get("feels_like"),
                        humidity=row.get("humidity"),
                        pressure=row.get("pressure"),
                        precipitation=row.get("precipitation"),
                        rain=row.get("rain"),
                        wind_speed=row.get("wind_speed"),
                        wind_direction=row.get("wind_direction"),
                        cloud_cover=row.get("cloud_cover"),
                        visibility=row.get("visibility"),
                        uv_index=row.get("uv_index"),
                        weather_code=row.get("weather_code")
                    )
                    records.append(rec)
            if records:
                session.bulk_save_objects(records)
                session.commit()
                logger.info(f"Saved {len(records)} weather records for location ID {location_id}.")
        except Exception as e:
            session.rollback()
            logger.error(f"Error saving weather data: {e}")
        finally:
            session.close()

    def get_weather_history(self, location_id: int) -> pd.DataFrame:
        """Fetch all stored weather records for a location as a DataFrame."""
        session = self.get_session()
        try:
            records = session.query(WeatherData).filter(WeatherData.location_id == location_id).all()
            if not records:
                return pd.DataFrame()
            data = [
                {
                    "timestamp": r.timestamp,
                    "temperature": r.temperature,
                    "feels_like": r.feels_like,
                    "humidity": r.humidity,
                    "pressure": r.pressure,
                    "precipitation": r.precipitation,
                    "rain": r.rain,
                    "wind_speed": r.wind_speed,
                    "wind_direction": r.wind_direction,
                    "cloud_cover": r.cloud_cover,
                    "visibility": r.visibility,
                    "uv_index": r.uv_index,
                    "weather_code": r.weather_code
                }
                for r in records
            ]
            return pd.DataFrame(data)
        finally:
            session.close()
