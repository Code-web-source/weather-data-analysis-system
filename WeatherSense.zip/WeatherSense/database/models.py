"""SQLAlchemy models for WeatherSense database tables."""
from datetime import datetime
from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class Location(Base):
    """Stored location entity."""
    __tablename__ = "locations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    city = Column(String(100), nullable=False)
    country = Column(String(100), nullable=True)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    timezone = Column(String(50), default="UTC")
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    weather_records = relationship("WeatherData", back_populates="location", cascade="all, delete-orphan")
    forecast_records = relationship("ForecastData", back_populates="location", cascade="all, delete-orphan")

class WeatherData(Base):
    """Recorded historical and real-time weather observations."""
    __tablename__ = "weather_data"

    id = Column(Integer, primary_key=True, autoincrement=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    temperature = Column(Float, nullable=True)
    feels_like = Column(Float, nullable=True)
    humidity = Column(Float, nullable=True)
    pressure = Column(Float, nullable=True)
    precipitation = Column(Float, nullable=True)
    rain = Column(Float, nullable=True)
    wind_speed = Column(Float, nullable=True)
    wind_direction = Column(Float, nullable=True)
    cloud_cover = Column(Float, nullable=True)
    visibility = Column(Float, nullable=True)
    uv_index = Column(Float, nullable=True)
    weather_code = Column(Integer, nullable=True)

    location = relationship("Location", back_populates="weather_records")

class ForecastData(Base):
    """Stored forecast snapshots."""
    __tablename__ = "forecast_data"

    id = Column(Integer, primary_key=True, autoincrement=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    forecast_time = Column(DateTime, nullable=False)
    temperature = Column(Float, nullable=True)
    humidity = Column(Float, nullable=True)
    precipitation_probability = Column(Float, nullable=True)
    wind_speed = Column(Float, nullable=True)
    weather_code = Column(Integer, nullable=True)

    location = relationship("Location", back_populates="forecast_records")

class SearchHistory(Base):
    """User search history persistence."""
    __tablename__ = "search_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    location = Column(String(150), nullable=False)
    searched_at = Column(DateTime, default=datetime.utcnow)

class Favorite(Base):
    """User favorite locations."""
    __tablename__ = "favorites"

    id = Column(Integer, primary_key=True, autoincrement=True)
    location = Column(String(150), nullable=False, unique=True)
    added_at = Column(DateTime, default=datetime.utcnow)
